import { QueryClient, QueryClientProvider } from "@tanstack/react-query";
import { BrowserRouter, Route, Routes } from "react-router-dom";
import { Toaster as Sonner } from "@/components/ui/sonner";
import { Toaster } from "@/components/ui/toaster";
import { TooltipProvider } from "@/components/ui/tooltip";
import { ThemeProvider } from "@/components/ThemeProvider";
import { AuthProvider } from "@/hooks/useAuth";
import Index from "./pages/Index";
import PesquisaPage from "./pages/PesquisaPage";
import ArticlePage from "./pages/ArticlePage";
import OpinionArticlePage from "./pages/OpinionArticlePage";
import SobrePage from "./pages/SobrePage";
import FAQPage from "./pages/FAQPage";
import ConteudoPage from "./pages/ConteudoPage";
import EquipePage from "./pages/EquipePage";
import AvaliacaoPage from "./pages/AvaliacaoPage";
import LoginPage from "./pages/LoginPage";
import PainelPage from "./pages/PainelPage";
import TratamentoPage from "./pages/TratamentoPage";
import CalculadoraPage from "./pages/CalculadoraPage";
import ResetPasswordPage from "./pages/ResetPasswordPage";
import NotFound from "./pages/NotFound";

const queryClient = new QueryClient();

const App = () => (
  <QueryClientProvider client={queryClient}>
    <ThemeProvider>
      <AuthProvider>
        <TooltipProvider>
          <Toaster />
          <Sonner />
          <BrowserRouter>
            <Routes>
              <Route path="/" element={<Index />} />
              <Route path="/sobre" element={<SobrePage />} />
              <Route path="/faq" element={<FAQPage />} />
              <Route path="/conteudo" element={<ConteudoPage />} />
              <Route path="/conteudo/artigo/:id" element={<OpinionArticlePage />} />
              <Route path="/pesquisa" element={<PesquisaPage />} />
              <Route path="/pesquisa/:id" element={<ArticlePage />} />
              <Route path="/equipe" element={<EquipePage />} />
              <Route path="/avaliacao" element={<AvaliacaoPage />} />
              <Route path="/tratamento" element={<TratamentoPage />} />
              <Route path="/calculadora" element={<CalculadoraPage />} />
              <Route path="/login" element={<LoginPage />} />
              <Route path="/reset-password" element={<ResetPasswordPage />} />
              <Route path="/painel" element={<PainelPage />} />
              <Route path="*" element={<NotFound />} />
            </Routes>
          </BrowserRouter>
        </TooltipProvider>
      </AuthProvider>
    </ThemeProvider>
  </QueryClientProvider>
);

export default App;
