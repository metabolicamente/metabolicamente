import { useParams, Link } from "react-router-dom";
import { useState } from "react";
import { motion } from "framer-motion";
import { ArrowLeft, ExternalLink, MessageSquare, Send, Calendar, BookOpen } from "lucide-react";
import Layout from "@/components/Layout";
import { articles } from "@/data/research";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Textarea } from "@/components/ui/textarea";
import { Input } from "@/components/ui/input";

interface Comment {
  id: number;
  name: string;
  text: string;
  date: string;
}

const ArticlePage = () => {
  const { id } = useParams<{ id: string }>();
  const article = articles.find((a) => a.id === id);

  const [comments, setComments] = useState<Comment[]>([
    { id: 1, name: "Dr. Lucas Mendes", text: "Artigo excelente. Os dados do estudo de Stanford reforçam o que vemos na prática clínica — intervenções metabólicas bem conduzidas podem transformar prognósticos.", date: "12 Mar 2026" },
  ]);
  const [newName, setNewName] = useState("");
  const [newComment, setNewComment] = useState("");

  if (!article) {
    return (
      <Layout>
        <div className="container py-20 text-center">
          <h1 className="text-2xl font-bold text-foreground mb-4">Artigo não encontrado</h1>
          <Link to="/pesquisa" className="text-primary hover:underline">← Voltar à pesquisa</Link>
        </div>
      </Layout>
    );
  }

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newName.trim() || !newComment.trim()) return;
    setComments((prev) => [
      ...prev,
      { id: Date.now(), name: newName.trim(), text: newComment.trim(), date: new Date().toLocaleDateString("pt-BR", { day: "2-digit", month: "short", year: "numeric" }) },
    ]);
    setNewName("");
    setNewComment("");
  };

  return (
    <Layout>
      <div className={`bg-gradient-to-br ${article.imageGradient} py-16 md:py-24`}>
        <div className="container max-w-3xl">
          <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: 0.7 }}>
            <Link to="/pesquisa" className="inline-flex items-center gap-1.5 text-white/70 hover:text-white text-sm mb-6 transition-colors">
              <ArrowLeft className="h-4 w-4" /> Voltar à pesquisa
            </Link>
            <h1 className="text-2xl md:text-4xl font-bold text-white mb-4 leading-tight" style={{ fontFamily: "'Playfair Display', serif" }}>
              {article.title}
            </h1>
            <p className="text-white/80 text-sm mb-4">{article.authors}</p>
            <div className="flex flex-wrap items-center gap-3 text-white/70 text-xs">
              <span className="flex items-center gap-1"><BookOpen className="h-3.5 w-3.5" /> {article.journal}</span>
              <span className="flex items-center gap-1"><Calendar className="h-3.5 w-3.5" /> {article.year}</span>
              <a href={article.url} target="_blank" rel="noopener noreferrer" className="flex items-center gap-1 hover:text-white transition-colors">
                <ExternalLink className="h-3.5 w-3.5" /> DOI: {article.doi}
              </a>
            </div>
          </motion.div>
        </div>
      </div>

      <article className="py-12 md:py-16 bg-background">
        <div className="container max-w-3xl">
          <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} transition={{ duration: 0.5, delay: 0.3 }}>
            <div className="flex flex-wrap gap-2 mb-8">
              {article.tags.map((tag) => (
                <Badge key={tag} variant="secondary" className="bg-muted text-muted-foreground">{tag}</Badge>
              ))}
            </div>

            <div className="bg-muted/50 border border-border rounded-xl p-6 mb-10">
              <h2 className="text-sm font-semibold text-primary uppercase tracking-wider mb-3">Resumo</h2>
              <p className="text-foreground/80 leading-relaxed">{article.abstract}</p>
            </div>

            <div className="prose-custom">
              {article.fullText.split("\n").map((line, i) => {
                const trimmed = line.trim();
                if (!trimmed) return <div key={i} className="h-4" />;
                if (trimmed.startsWith("## "))
                  return <h2 key={i} className="text-xl md:text-2xl font-bold text-foreground mt-10 mb-4">{trimmed.slice(3)}</h2>;
                if (trimmed.startsWith("### "))
                  return <h3 key={i} className="text-lg font-semibold text-foreground mt-6 mb-3">{trimmed.slice(4)}</h3>;
                if (trimmed.startsWith("- **"))
                  return <li key={i} className="text-foreground/80 leading-relaxed ml-4 mb-1 list-disc" dangerouslySetInnerHTML={{ __html: trimmed.slice(2).replace(/\*\*(.*?)\*\*/g, '<strong class="text-foreground">$1</strong>') }} />;
                if (trimmed.startsWith("- "))
                  return <li key={i} className="text-foreground/80 leading-relaxed ml-4 mb-1 list-disc">{trimmed.slice(2)}</li>;
                if (trimmed.startsWith("---"))
                  return <hr key={i} className="border-border my-8" />;
                if (trimmed.startsWith("1. ") || trimmed.startsWith("2. ") || trimmed.startsWith("3. ") || trimmed.startsWith("4. "))
                  return <li key={i} className="text-foreground/80 leading-relaxed ml-4 mb-1 list-decimal" dangerouslySetInnerHTML={{ __html: trimmed.slice(3).replace(/\*\*(.*?)\*\*/g, '<strong class="text-foreground">$1</strong>') }} />;
                return <p key={i} className="text-foreground/80 leading-relaxed mb-3" dangerouslySetInnerHTML={{ __html: trimmed.replace(/\*\*(.*?)\*\*/g, '<strong class="text-foreground">$1</strong>') }} />;
              })}
            </div>

            <div className="mt-10 pt-8 border-t border-border">
              <a href={article.url} target="_blank" rel="noopener noreferrer" className="inline-flex items-center gap-2 text-primary hover:underline font-medium">
                <ExternalLink className="h-4 w-4" /> Acessar artigo original
              </a>
            </div>
          </motion.div>

          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.6 }}
            className="mt-16 pt-10 border-t border-border"
          >
            <div className="flex items-center gap-2 mb-8">
              <MessageSquare className="h-5 w-5 text-primary" />
              <h2 className="text-xl font-bold text-foreground">Comentários ({comments.length})</h2>
            </div>

            <div className="space-y-6 mb-10">
              {comments.map((c) => (
                <div key={c.id} className="bg-muted/30 border border-border rounded-lg p-5">
                  <div className="flex items-center justify-between mb-2">
                    <span className="font-medium text-foreground text-sm">{c.name}</span>
                    <span className="text-xs text-muted-foreground">{c.date}</span>
                  </div>
                  <p className="text-foreground/80 text-sm leading-relaxed">{c.text}</p>
                </div>
              ))}
            </div>

            <form onSubmit={handleSubmit} className="bg-card border border-border rounded-xl p-6">
              <h3 className="text-sm font-semibold text-foreground mb-4">Deixe seu comentário</h3>
              <Input value={newName} onChange={(e) => setNewName(e.target.value)} placeholder="Seu nome" className="mb-3" required />
              <Textarea value={newComment} onChange={(e) => setNewComment(e.target.value)} placeholder="Escreva seu comentário..." rows={4} className="mb-4 resize-none" required />
              <Button type="submit" size="sm" className="gap-2">
                <Send className="h-3.5 w-3.5" /> Enviar comentário
              </Button>
            </form>
          </motion.div>
        </div>
      </article>
    </Layout>
  );
};

export default ArticlePage;
