import { useState, useEffect } from "react";
import { Link, useNavigate } from "react-router-dom";
import { motion } from "framer-motion";
import { Brain, LogIn, Mail, Lock, Eye, EyeOff, UserPlus } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { useToast } from "@/hooks/use-toast";
import { supabase } from "@/integrations/supabase/client";
import { lovable } from "@/integrations/lovable";
import { useAuth } from "@/hooks/useAuth";
import SEO from "@/components/SEO";

type Mode = "signin" | "signup" | "forgot";

const LoginPage = () => {
  const [mode, setMode] = useState<Mode>("signin");
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [name, setName] = useState("");
  const [showPassword, setShowPassword] = useState(false);
  const [loading, setLoading] = useState(false);
  const navigate = useNavigate();
  const { toast } = useToast();
  const { session } = useAuth();

  useEffect(() => {
    if (session) navigate("/painel", { replace: true });
  }, [session, navigate]);

  const submit = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);
    try {
      if (mode === "signin") {
        const { error } = await supabase.auth.signInWithPassword({ email: email.trim(), password });
        if (error) throw error;
        toast({ title: "Bem-vindo de volta!" });
        navigate("/painel");
      } else if (mode === "signup") {
        const { error } = await supabase.auth.signUp({
          email: email.trim(),
          password,
          options: {
            emailRedirectTo: `${window.location.origin}/painel`,
            data: { display_name: name.trim() || email.split("@")[0] },
          },
        });
        if (error) throw error;
        toast({ title: "Conta criada!", description: "Você já pode acessar o painel." });
        navigate("/painel");
      } else {
        const { error } = await supabase.auth.resetPasswordForEmail(email.trim(), {
          redirectTo: `${window.location.origin}/reset-password`,
        });
        if (error) throw error;
        toast({ title: "E-mail enviado", description: "Verifique sua caixa de entrada para redefinir a senha." });
        setMode("signin");
      }
    } catch (err: unknown) {
      const message = err instanceof Error ? err.message : "Erro desconhecido";
      toast({ title: "Não foi possível continuar", description: message, variant: "destructive" });
    } finally {
      setLoading(false);
    }
  };

  const signInWithGoogle = async () => {
    const result = await lovable.auth.signInWithOAuth("google", {
      redirect_uri: `${window.location.origin}/painel`,
    });
    if (result?.error) toast({ title: "Erro Google", description: result.error.message, variant: "destructive" });
  };

  const titleByMode = {
    signin: "Entre no seu painel",
    signup: "Crie sua conta",
    forgot: "Recuperar senha",
  }[mode];

  return (
    <div className="min-h-screen bg-background flex items-center justify-center p-4">
      <SEO title={`${titleByMode} | Metabolicamente`} description="Acesse seu painel da Clínica Metabolicamente: acompanhamento, exames e plano nutricional personalizados." />

      <div className="fixed inset-0 overflow-hidden pointer-events-none">
        <div className="absolute -top-40 -right-40 w-[500px] h-[500px] rounded-full bg-primary/5 blur-3xl" />
        <div className="absolute -bottom-40 -left-40 w-[400px] h-[400px] rounded-full bg-secondary/5 blur-3xl" />
      </div>

      <motion.div
        initial={{ opacity: 0, y: 30 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.6 }}
        className="w-full max-w-md relative z-10"
      >
        <div className="text-center mb-8">
          <Link to="/" className="inline-flex items-center gap-2 mb-4 group">
            <Brain className="h-8 w-8 text-primary transition-transform group-hover:scale-110" />
            <span className="text-2xl font-bold text-primary" style={{ fontFamily: "'Montserrat', sans-serif" }}>
              Metabolicamente
            </span>
          </Link>
          <h1 className="text-xl font-semibold text-foreground">{titleByMode}</h1>
        </div>

        <div className="mb-6 rounded-2xl border border-border/60 bg-muted/30 p-4 text-xs text-muted-foreground">
          <p className="font-semibold text-foreground mb-2 text-sm">Acesso único para todos os perfis</p>
          <p className="mb-2">Use o mesmo login, independentemente do seu vínculo com a clínica. O painel se adapta automaticamente ao seu perfil:</p>
          <ul className="space-y-1 pl-1">
            <li><span className="font-medium text-foreground">👩‍⚕️ Médico(a):</span> prontuários, teleconsulta e prescrições.</li>
            <li><span className="font-medium text-foreground">🥗 Nutricionista:</span> planos alimentares e evolução do paciente.</li>
            <li><span className="font-medium text-foreground">🧑 Paciente:</span> exames, cardápio e acompanhamento.</li>
          </ul>
          <p className="mt-2 text-[11px]">Primeiro acesso? Crie sua conta abaixo — a equipe da clínica ativa seu perfil profissional em seguida.</p>
        </div>

        <div className="bg-card border border-border rounded-2xl p-8 shadow-lg">
          <Button
            type="button"
            variant="outline"
            onClick={signInWithGoogle}
            className="w-full h-12 rounded-xl mb-4 gap-2"
          >
            <svg className="h-4 w-4" viewBox="0 0 24 24" fill="currentColor">
              <path d="M22.56 12.25c0-.78-.07-1.53-.2-2.25H12v4.26h5.92c-.26 1.37-1.04 2.53-2.21 3.31v2.77h3.57c2.08-1.92 3.28-4.74 3.28-8.09z" fill="#4285F4"/>
              <path d="M12 23c2.97 0 5.46-.98 7.28-2.66l-3.57-2.77c-.98.66-2.23 1.06-3.71 1.06-2.86 0-5.29-1.93-6.16-4.53H2.18v2.84C3.99 20.53 7.7 23 12 23z" fill="#34A853"/>
              <path d="M5.84 14.09c-.22-.66-.35-1.36-.35-2.09s.13-1.43.35-2.09V7.07H2.18C1.43 8.55 1 10.22 1 12s.43 3.45 1.18 4.93l2.85-2.22.81-.62z" fill="#FBBC05"/>
              <path d="M12 5.38c1.62 0 3.06.56 4.21 1.64l3.15-3.15C17.45 2.09 14.97 1 12 1 7.7 1 3.99 3.47 2.18 7.07l3.66 2.84c.87-2.6 3.3-4.53 6.16-4.53z" fill="#EA4335"/>
            </svg>
            Continuar com Google
          </Button>

          <div className="relative my-4">
            <div className="absolute inset-0 flex items-center"><div className="w-full border-t border-border"></div></div>
            <div className="relative flex justify-center text-xs uppercase"><span className="bg-card px-2 text-muted-foreground">ou</span></div>
          </div>

          <form onSubmit={submit} className="space-y-4">
            {mode === "signup" && (
              <div className="space-y-2">
                <label className="text-sm font-medium text-foreground">Nome</label>
                <Input value={name} onChange={(e) => setName(e.target.value)} placeholder="Seu nome" className="h-12 rounded-xl bg-muted/50" />
              </div>
            )}

            <div className="space-y-2">
              <label className="text-sm font-medium text-foreground">E-mail</label>
              <div className="relative">
                <Mail className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
                <Input
                  type="email"
                  placeholder="seu@email.com"
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  className="pl-10 h-12 rounded-xl bg-muted/50 border-border focus:bg-card"
                  required
                />
              </div>
            </div>

            {mode !== "forgot" && (
              <div className="space-y-2">
                <label className="text-sm font-medium text-foreground">Senha</label>
                <div className="relative">
                  <Lock className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
                  <Input
                    type={showPassword ? "text" : "password"}
                    placeholder="••••••••"
                    value={password}
                    onChange={(e) => setPassword(e.target.value)}
                    minLength={6}
                    className="pl-10 pr-10 h-12 rounded-xl bg-muted/50 border-border focus:bg-card"
                    required
                  />
                  <button
                    type="button"
                    onClick={() => setShowPassword(!showPassword)}
                    className="absolute right-3 top-1/2 -translate-y-1/2 text-muted-foreground hover:text-foreground transition-colors"
                  >
                    {showPassword ? <EyeOff className="h-4 w-4" /> : <Eye className="h-4 w-4" />}
                  </button>
                </div>
              </div>
            )}

            <Button
              type="submit"
              disabled={loading}
              className="w-full h-12 rounded-xl bg-primary text-primary-foreground hover:bg-primary/90 text-base font-semibold transition-all"
            >
              {loading ? (
                <motion.div
                  animate={{ rotate: 360 }}
                  transition={{ repeat: Infinity, duration: 1, ease: "linear" }}
                  className="h-5 w-5 border-2 border-primary-foreground/30 border-t-primary-foreground rounded-full"
                />
              ) : mode === "signin" ? (
                <><LogIn className="h-4 w-4 mr-2" /> Entrar</>
              ) : mode === "signup" ? (
                <><UserPlus className="h-4 w-4 mr-2" /> Criar conta</>
              ) : (
                <>Enviar link de recuperação</>
              )}
            </Button>
          </form>

          <div className="mt-6 flex flex-col items-center gap-2 text-xs text-muted-foreground">
            {mode === "signin" && (
              <>
                <button onClick={() => setMode("forgot")} className="hover:text-primary">Esqueceu a senha?</button>
                <button onClick={() => setMode("signup")} className="hover:text-primary">Não tem conta? <span className="font-semibold text-foreground">Cadastre-se</span></button>
              </>
            )}
            {mode === "signup" && (
              <button onClick={() => setMode("signin")} className="hover:text-primary">Já tem conta? <span className="font-semibold text-foreground">Entrar</span></button>
            )}
            {mode === "forgot" && (
              <button onClick={() => setMode("signin")} className="hover:text-primary">Voltar para o login</button>
            )}
          </div>
        </div>

        <p className="text-center text-xs text-muted-foreground mt-6">
          Ao continuar, você concorda com nossos Termos de Uso.
        </p>
      </motion.div>
    </div>
  );
};

export default LoginPage;
