import Layout from "@/components/Layout";
import { motion } from "framer-motion";
import brainVintage from "@/assets/brain-vintage.png";
import doctor1 from "@/assets/doctor-1.jpg";
import doctor2 from "@/assets/doctor-2.jpg";
import doctor3 from "@/assets/doctor-3.jpg";
import doctor4 from "@/assets/doctor-4.jpg";
import WaveDivider from "@/components/shared/WaveDivider";
import StandardHero from "@/components/shared/StandardHero";

const SobrePage = () => (
  <Layout>
    <StandardHero
      variant="default"
      eyebrow="Nossa Missão"
      title="Sobre Nós"
      description="Conheça a história, a ciência e a missão por trás da Metabolicamente."
    />

    <WaveDivider fillColor="hsl(var(--muted))" />

    {/* Nossa História */}
    <section className="py-20 md:py-28 bg-muted">
      <div className="container max-w-5xl">
        <motion.div
          className="text-center mb-16"
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.7 }}
        >
          <h2 className="text-3xl md:text-4xl font-bold text-primary">
            Nossa História
          </h2>
        </motion.div>

        <motion.div
          className="rounded-2xl border border-border bg-background overflow-hidden"
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.6 }}
        >
          <div className="grid md:grid-cols-2">
            <div className="relative aspect-[4/3] md:aspect-auto bg-muted overflow-hidden">
              <div className="grid grid-cols-2 h-full">
                {[doctor1, doctor2, doctor3, doctor4].map((photo, i) => (
                  <img key={i} src={photo} alt="Equipe médica" className="w-full h-full object-cover" loading="lazy" />
                ))}
              </div>
            </div>
            <div className="p-8 md:p-10 flex flex-col justify-center">
              <p className="text-muted-foreground leading-relaxed mb-4">
                Este espaço é reservado para a história da sua clínica ou projeto.
                Conte como surgiu o interesse pela psiquiatria metabólica, os desafios
                enfrentados, as conquistas e a visão de futuro.
              </p>
              <p className="text-muted-foreground/60 text-sm italic">
                Edite este texto diretamente no código para personalizar com a sua narrativa.
              </p>
            </div>
          </div>
        </motion.div>
      </div>
    </section>

    <WaveDivider fillColor="hsl(var(--background))" />

    {/* O Propósito */}
    <section className="py-20 md:py-28 bg-background">
      <div className="container max-w-5xl">
        <div className="grid md:grid-cols-2 gap-12 lg:gap-20 items-center">
          <motion.div
            initial={{ opacity: 0, x: -30 }}
            whileInView={{ opacity: 1, x: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.7 }}
          >
            <h2 className="text-3xl md:text-4xl font-bold text-primary mb-6" style={{ fontFamily: "'Montserrat', sans-serif" }}>
              O Propósito da Metabolicamente
            </h2>
            <div className="space-y-4">
              <p className="text-muted-foreground leading-relaxed text-lg">
                Adicionar texto sobre o propósito da clínica. Descreva a visão, a missão
                e como a psiquiatria metabólica pode transformar vidas.
              </p>
              <p className="text-muted-foreground/60 text-sm italic">
                Edite este texto para personalizar com a sua narrativa.
              </p>
            </div>
          </motion.div>
        </div>
      </div>
    </section>
  </Layout>
);

export default SobrePage;
