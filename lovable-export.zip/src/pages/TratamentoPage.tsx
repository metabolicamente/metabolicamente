import { motion } from "framer-motion";
import { Link } from "react-router-dom";
import {
  ClipboardCheck, Microscope, Brain, Salad, Activity, ArrowRight, CheckCircle2,
} from "lucide-react";
import Layout from "@/components/Layout";
import StandardHero from "@/components/shared/StandardHero";
import WaveDivider from "@/components/shared/WaveDivider";
import { Button } from "@/components/ui/button";

const steps = [
  {
    n: "01",
    icon: ClipboardCheck,
    title: "Avaliação inicial",
    desc: "Você preenche uma triagem detalhada sobre histórico clínico, sintomas, hábitos alimentares e estilo de vida. A primeira consulta acontece em até 5 dias.",
    points: ["Triagem on-line de 10 min", "Anamnese completa com psiquiatra", "Definição de objetivos clínicos"],
  },
  {
    n: "02",
    icon: Microscope,
    title: "Investigação metabólica",
    desc: "Solicitamos exames laboratoriais específicos para mapear marcadores inflamatórios, glicêmicos, hormonais e nutricionais relevantes para a saúde mental.",
    points: ["Painel metabólico completo", "Vitaminas, minerais e ômega-3", "Marcadores inflamatórios (PCR, homocisteína)"],
  },
  {
    n: "03",
    icon: Brain,
    title: "Plano terapêutico personalizado",
    desc: "Combinamos intervenções metabólicas, nutricionais e, quando indicado, ajustes farmacológicos para tratar a raiz do desequilíbrio — não apenas os sintomas.",
    points: ["Protocolo individualizado", "Cardápio guiado pela nutricionista", "Acompanhamento medicamentoso"],
  },
  {
    n: "04",
    icon: Salad,
    title: "Nutrição clínica contínua",
    desc: "A nutricionista funcional acompanha você semanalmente, ajustando o plano conforme exames, sintomas e adesão. Tudo no painel do paciente.",
    points: ["Cardápios atualizados quinzenalmente", "Chat direto com a nutricionista", "Receitas e listas de compra"],
  },
  {
    n: "05",
    icon: Activity,
    title: "Acompanhamento e evolução",
    desc: "A cada 30–60 dias, reavaliamos exames e métricas subjetivas (humor, energia, sono). Você acompanha o progresso visualmente no painel.",
    points: ["Dashboard de evolução", "Relatórios de exames comparativos", "Check-ins semanais guiados"],
  },
];

const fade = { initial: { opacity: 0, y: 24 }, whileInView: { opacity: 1, y: 0 }, viewport: { once: true } };

const TratamentoPage = () => (
  <Layout>
    <StandardHero
      variant="organic"
      eyebrow="Como funciona"
      title="A jornada do tratamento"
      description="Um processo clínico estruturado em 5 etapas — da primeira avaliação ao acompanhamento contínuo da sua saúde metabólica e mental."
    />

    <WaveDivider fillColor="hsl(var(--background))" />

    <section className="py-20 md:py-28">
      <div className="container max-w-5xl">
        <div className="relative">
          {/* Vertical line */}
          <div className="absolute left-6 md:left-1/2 top-0 bottom-0 w-px bg-border md:-translate-x-1/2" aria-hidden />

          <div className="space-y-16 md:space-y-24">
            {steps.map((step, i) => {
              const Icon = step.icon;
              const isLeft = i % 2 === 0;
              return (
                <motion.div
                  key={step.n}
                  {...fade}
                  transition={{ duration: 0.6, delay: i * 0.05 }}
                  className={`relative grid md:grid-cols-2 gap-8 items-center ${isLeft ? "" : "md:[&>*:first-child]:order-2"}`}
                >
                  {/* Number bubble */}
                  <div className="absolute left-6 md:left-1/2 -translate-x-1/2 top-0 z-10">
                    <div className="h-12 w-12 rounded-full bg-primary text-primary-foreground flex items-center justify-center font-bold text-sm border-4 border-background shadow-lg" style={{ fontFamily: "'Montserrat', sans-serif" }}>
                      {step.n}
                    </div>
                  </div>

                  <div className={`pl-20 md:pl-0 ${isLeft ? "md:pr-12 md:text-right" : "md:pl-12"}`}>
                    <div className={`inline-flex items-center gap-2 mb-3 ${isLeft ? "md:flex-row-reverse" : ""}`}>
                      <div className="h-10 w-10 rounded-xl bg-secondary/10 flex items-center justify-center">
                        <Icon className="h-5 w-5 text-secondary" />
                      </div>
                    </div>
                    <h3 className="text-2xl md:text-3xl font-bold text-primary mb-3" style={{ fontFamily: "'Playfair Display', serif" }}>
                      {step.title}
                    </h3>
                    <p className="text-foreground/80 leading-relaxed">{step.desc}</p>
                  </div>

                  <div className="pl-20 md:pl-0">
                    <div className={`bg-card border border-border rounded-2xl p-6 shadow-sm ${isLeft ? "md:ml-12" : "md:mr-12"}`}>
                      <ul className="space-y-3">
                        {step.points.map((p) => (
                          <li key={p} className="flex items-start gap-3">
                            <CheckCircle2 className="h-5 w-5 text-secondary shrink-0 mt-0.5" />
                            <span className="text-sm text-foreground/85">{p}</span>
                          </li>
                        ))}
                      </ul>
                    </div>
                  </div>
                </motion.div>
              );
            })}
          </div>
        </div>

        {/* CTA */}
        <motion.div {...fade} transition={{ duration: 0.6, delay: 0.2 }} className="mt-24 text-center bg-gradient-to-br from-primary to-primary/85 text-primary-foreground rounded-3xl p-10 md:p-14 relative overflow-hidden">
          <div className="absolute -right-12 -top-12 w-48 h-48 rounded-full bg-secondary/20" aria-hidden />
          <div className="absolute -left-16 -bottom-16 w-56 h-56 rounded-full bg-primary-foreground/5" aria-hidden />
          <div className="relative">
            <h3 className="text-2xl md:text-4xl font-bold mb-4" style={{ fontFamily: "'Playfair Display', serif" }}>
              Pronto para começar a sua jornada?
            </h3>
            <p className="text-primary-foreground/85 max-w-xl mx-auto mb-8">
              Faça uma avaliação inicial gratuita e descubra se a abordagem metabólica é indicada para você.
            </p>
            <div className="flex flex-col sm:flex-row gap-3 justify-center">
              <Button asChild size="lg" className="bg-secondary text-secondary-foreground hover:bg-secondary/90 rounded-full px-8 gap-2">
                <Link to="/avaliacao">Iniciar avaliação <ArrowRight className="h-4 w-4" /></Link>
              </Button>
              <Button asChild size="lg" variant="outline" className="rounded-full px-8 bg-transparent border-primary-foreground/30 text-primary-foreground hover:bg-primary-foreground/10">
                <Link to="/calculadora">Calcular meu risco metabólico</Link>
              </Button>
            </div>
          </div>
        </motion.div>
      </div>
    </section>
  </Layout>
);

export default TratamentoPage;
