import { useState, useCallback } from "react";
import { Link } from "react-router-dom";
import { motion, AnimatePresence } from "framer-motion";
import { ArrowLeft, ArrowRight, Phone, Heart, Send, CheckCircle, Brain } from "lucide-react";
import { Button } from "@/components/ui/button";

import doctor1 from "@/assets/doctor-1.jpg";
import doctor2 from "@/assets/doctor-2.jpg";
import doctor3 from "@/assets/doctor-3.jpg";
import doctor4 from "@/assets/doctor-4.jpg";

const TOTAL_STEPS = 7;

const stepVariants = {
  enter: (dir: number) => ({ x: dir > 0 ? 80 : -80, opacity: 0 }),
  center: { x: 0, opacity: 1 },
  exit: (dir: number) => ({ x: dir > 0 ? -80 : 80, opacity: 0 }),
};

/* ─── Reusable selector pill ─── */
const Pill = ({ label, selected, onClick }: { label: string; selected: boolean; onClick: () => void }) => (
  <button
    type="button"
    onClick={onClick}
    className={`px-6 py-3.5 rounded-2xl text-sm font-medium border transition-all duration-300 w-full text-left ${
      selected
        ? "bg-primary text-primary-foreground border-primary shadow-sm"
        : "bg-card text-foreground border-border hover:border-primary/40 hover:bg-card/80"
    }`}
  >
    {label}
  </button>
);

/* ─── Toggle card ─── */
const ToggleCard = ({ label, value, onChange }: { label: string; value: string; onChange: (v: string) => void }) => (
  <div className="flex flex-col gap-2">
    <p className="text-sm font-medium text-foreground">{label}</p>
    <div className="flex gap-2">
      {["Sim", "Não"].map((opt) => (
        <button
          key={opt}
          type="button"
          onClick={() => onChange(opt)}
          className={`flex-1 py-3 rounded-xl text-sm font-medium border transition-all duration-300 ${
            value === opt
              ? "bg-primary text-primary-foreground border-primary"
              : "bg-card text-muted-foreground border-border hover:border-primary/40"
          }`}
        >
          {opt}
        </button>
      ))}
    </div>
  </div>
);

/* ─── Energy slider ─── */
const EnergySlider = ({ value, onChange }: { value: number; onChange: (v: number) => void }) => (
  <div className="space-y-3">
    <div className="flex justify-between text-xs text-muted-foreground">
      <span>Sem energia</span>
      <span>Energia plena</span>
    </div>
    <input
      type="range"
      min={0}
      max={10}
      value={value}
      onChange={(e) => onChange(Number(e.target.value))}
      className="w-full h-2 rounded-full appearance-none cursor-pointer accent-primary bg-border"
    />
    <p className="text-center text-2xl font-bold text-primary" style={{ fontFamily: "'Playfair Display', serif" }}>
      {value}<span className="text-sm font-normal text-muted-foreground">/10</span>
    </p>
  </div>
);

/* ─── Brazilian states ─── */
const STATES = [
  "AC","AL","AP","AM","BA","CE","DF","ES","GO","MA","MT","MS","MG","PA",
  "PB","PR","PE","PI","RJ","RN","RS","RO","RR","SC","SP","SE","TO",
];

/* ─── Form data type ─── */
interface FormData {
  concern: string;
  duration: string;
  hasPsychiatrist: string;
  hasTherapy: string;
  usesMedication: string;
  healthConditions: string;
  dietStrategy: string;
  energy: number;
  feeling: string;
  riskIndicators: string[];
  availability: string[];
  name: string;
  email: string;
  phone: string;
  city: string;
  state: string;
}

const initialData: FormData = {
  concern: "",
  duration: "",
  hasPsychiatrist: "",
  hasTherapy: "",
  usesMedication: "",
  healthConditions: "",
  dietStrategy: "",
  energy: 5,
  feeling: "",
  riskIndicators: [],
  availability: [],
  name: "",
  email: "",
  phone: "",
  city: "",
  state: "",
};

const RISK_PHRASES = [
  "Penso em desistir de tudo",
  "Sinto que nada vale a pena",
  "Tenho pensamentos de me machucar",
  "Não consigo ver saída",
];

const AvaliacaoPage = () => {
  const [step, setStep] = useState(1);
  const [dir, setDir] = useState(1);
  const [data, setData] = useState<FormData>(initialData);
  const [showRiskAlert, setShowRiskAlert] = useState(false);
  const [submitted, setSubmitted] = useState(false);

  const update = useCallback(<K extends keyof FormData>(key: K, value: FormData[K]) => {
    setData((prev) => ({ ...prev, [key]: value }));
  }, []);

  const toggleArrayItem = useCallback((key: "riskIndicators" | "availability", item: string) => {
    setData((prev) => ({
      ...prev,
      [key]: prev[key].includes(item) ? prev[key].filter((i) => i !== item) : [...prev[key], item],
    }));
  }, []);

  const next = () => {
    if (step === 4 && data.riskIndicators.length > 0) {
      setShowRiskAlert(true);
    }
    if (step < TOTAL_STEPS) { setDir(1); setStep((s) => s + 1); }
    if (step === TOTAL_STEPS) { setSubmitted(true); }
  };

  const prev = () => {
    if (step > 1) { setDir(-1); setStep((s) => s - 1); }
  };

  const progress = ((step - 1) / (TOTAL_STEPS - 1)) * 100;

  return (
    <div className="min-h-screen bg-background flex flex-col">
      {/* Branded top bar */}
      <header className="bg-primary py-4">
        <div className="container flex items-center justify-center">
          <Link to="/" className="inline-flex items-center gap-2 group">
            <Brain className="h-6 w-6 text-primary-foreground transition-transform group-hover:scale-110" />
            <span className="text-lg font-bold text-primary-foreground" style={{ fontFamily: "'Montserrat', sans-serif" }}>
              Metabolicamente
            </span>
          </Link>
        </div>
      </header>

      {/* Subtle wave transition */}
      <div className="relative -mt-px">
        <svg viewBox="0 0 1440 40" preserveAspectRatio="none" className="w-full h-5 md:h-7 block">
          <path d="M0,0 C360,40 1080,40 1440,0 L1440,40 L0,40 Z" fill="hsl(var(--background))" />
        </svg>
      </div>

      {/* Form area */}
      <section className="flex-1 bg-background pb-20">
        {/* Progress bar */}
        <div className="container max-w-2xl pt-6">
          <div className="h-1 bg-border rounded-full overflow-hidden mb-2">
            <motion.div
              className="h-full rounded-full bg-primary"
              animate={{ width: `${progress}%` }}
              transition={{ duration: 0.5, ease: "easeInOut" }}
            />
          </div>
          <p className="text-xs text-muted-foreground text-right mb-10">
            {step} de {TOTAL_STEPS}
          </p>
        </div>

        <div className="container max-w-2xl">
          <AnimatePresence mode="wait" custom={dir}>
            {!submitted ? (
              <motion.div
                key={step}
                custom={dir}
                variants={stepVariants}
                initial="enter"
                animate="center"
                exit="exit"
                transition={{ duration: 0.35, ease: "easeInOut" }}
              >
                {step === 1 && <Step1 data={data} update={update} />}
                {step === 2 && <Step2 data={data} update={update} />}
                {step === 3 && <Step3 data={data} update={update} />}
                {step === 4 && <Step4 data={data} update={update} toggleArrayItem={toggleArrayItem} showRiskAlert={showRiskAlert} />}
                {step === 5 && <Step5 data={data} toggleArrayItem={toggleArrayItem} />}
                {step === 6 && <Step6 data={data} update={update} />}
                {step === 7 && <Step7 />}
              </motion.div>
            ) : (
              <ConfirmationScreen />
            )}
          </AnimatePresence>

          {/* Navigation */}
          {!submitted && (
            <div className="flex justify-between items-center mt-12">
              <Button
                variant="ghost"
                onClick={prev}
                disabled={step === 1}
                className="text-muted-foreground hover:text-foreground gap-2"
              >
                <ArrowLeft className="h-4 w-4" /> Voltar
              </Button>
              <Button
                onClick={next}
                className="bg-primary text-primary-foreground hover:bg-primary/90 rounded-full px-8 py-6 gap-2"
              >
                {step === TOTAL_STEPS ? (
                  <>Enviar <Send className="h-4 w-4" /></>
                ) : (
                  <>Continuar <ArrowRight className="h-4 w-4" /></>
                )}
              </Button>
            </div>
          )}
        </div>
      </section>
    </div>
  );
};

/* ─── STEP COMPONENTS ─── */

const SectionTitle = ({ children }: { children: React.ReactNode }) => (
  <h2 className="text-2xl md:text-3xl font-bold text-foreground mb-2" style={{ fontFamily: "'Playfair Display', serif" }}>
    {children}
  </h2>
);

const SectionSubtitle = ({ children }: { children: React.ReactNode }) => (
  <p className="text-muted-foreground mb-8 leading-relaxed">{children}</p>
);

/* Step 1 — Context */
const Step1 = ({ data, update }: { data: FormData; update: <K extends keyof FormData>(k: K, v: FormData[K]) => void }) => (
  <div className="space-y-8">
    <div>
      <SectionTitle>Em que podemos te ajudar?</SectionTitle>
      <SectionSubtitle>Descreva brevemente o que te trouxe até aqui.</SectionSubtitle>
      <textarea
        value={data.concern}
        onChange={(e) => update("concern", e.target.value)}
        placeholder="Conte-nos um pouco sobre o que você está vivenciando..."
        rows={4}
        className="w-full bg-card border border-border rounded-2xl px-5 py-4 text-sm text-foreground placeholder:text-muted-foreground/50 focus:outline-none focus:ring-2 focus:ring-primary/30 resize-none"
      />
    </div>
    <div>
      <p className="text-sm font-medium text-foreground mb-3">Há quanto tempo isso ocorre?</p>
      <div className="grid gap-3">
        {["Menos de 6 meses", "6 meses a 2 anos", "Mais de 2 anos"].map((opt) => (
          <Pill key={opt} label={opt} selected={data.duration === opt} onClick={() => update("duration", opt)} />
        ))}
      </div>
    </div>
  </div>
);

/* Step 2 — Current Care */
const Step2 = ({ data, update }: { data: FormData; update: <K extends keyof FormData>(k: K, v: FormData[K]) => void }) => (
  <div className="space-y-8">
    <div>
      <SectionTitle>Como está seu acompanhamento hoje?</SectionTitle>
      <SectionSubtitle>Nos ajude a entender seu cuidado atual.</SectionSubtitle>
    </div>
    <div className="space-y-5">
      <ToggleCard label="Tem psiquiatra?" value={data.hasPsychiatrist} onChange={(v) => update("hasPsychiatrist", v)} />
      <ToggleCard label="Faz terapia?" value={data.hasTherapy} onChange={(v) => update("hasTherapy", v)} />
      <ToggleCard label="Usa medicações?" value={data.usesMedication} onChange={(v) => update("usesMedication", v)} />
    </div>
  </div>
);

/* Step 3 — Metabolic Health */
const Step3 = ({ data, update }: { data: FormData; update: <K extends keyof FormData>(k: K, v: FormData[K]) => void }) => (
  <div className="space-y-8">
    <div>
      <SectionTitle>Sinais do Corpo</SectionTitle>
      <SectionSubtitle>Informações sobre sua saúde física nos ajudam a montar um plano integrado.</SectionSubtitle>
    </div>
    <div className="space-y-5">
      <div>
        <label className="text-sm font-medium text-foreground mb-2 block">Quadro de saúde (diabetes, hipertensão, etc.)</label>
        <input
          type="text"
          value={data.healthConditions}
          onChange={(e) => update("healthConditions", e.target.value)}
          placeholder="Ex: diabetes tipo 2, hipotireoidismo..."
          className="w-full bg-card border border-border rounded-2xl px-5 py-3.5 text-sm text-foreground placeholder:text-muted-foreground/50 focus:outline-none focus:ring-2 focus:ring-primary/30"
        />
      </div>
      <div>
        <label className="text-sm font-medium text-foreground mb-2 block">Já tentou alguma estratégia alimentar?</label>
        <input
          type="text"
          value={data.dietStrategy}
          onChange={(e) => update("dietStrategy", e.target.value)}
          placeholder="Ex: dieta cetogênica, low carb, jejum intermitente..."
          className="w-full bg-card border border-border rounded-2xl px-5 py-3.5 text-sm text-foreground placeholder:text-muted-foreground/50 focus:outline-none focus:ring-2 focus:ring-primary/30"
        />
      </div>
      <div>
        <label className="text-sm font-medium text-foreground mb-2 block">Como está sua energia diária?</label>
        <EnergySlider value={data.energy} onChange={(v) => update("energy", v)} />
      </div>
    </div>
  </div>
);

/* Step 4 — Safety & Wellbeing */
const Step4 = ({
  data,
  update,
  toggleArrayItem,
  showRiskAlert,
}: {
  data: FormData;
  update: <K extends keyof FormData>(k: K, v: FormData[K]) => void;
  toggleArrayItem: (key: "riskIndicators" | "availability", item: string) => void;
  showRiskAlert: boolean;
}) => (
  <div className="space-y-8">
    <div>
      <SectionTitle>Como você está se sentindo agora?</SectionTitle>
      <SectionSubtitle>Suas respostas são confidenciais e nos ajudam a oferecer o melhor acolhimento.</SectionSubtitle>
    </div>
    <div>
      <p className="text-sm font-medium text-foreground mb-3">Como descreveria seu estado emocional?</p>
      <div className="grid gap-3">
        {["Estou bem, buscando prevenção", "Estou com dificuldades, mas funcional", "Estou em sofrimento significativo", "Estou em crise"].map((opt) => (
          <Pill key={opt} label={opt} selected={data.feeling === opt} onClick={() => update("feeling", opt)} />
        ))}
      </div>
    </div>
    <div>
      <p className="text-sm font-medium text-foreground mb-3">Você se identifica com alguma dessas frases?</p>
      <div className="grid gap-3">
        {RISK_PHRASES.map((phrase) => (
          <Pill
            key={phrase}
            label={phrase}
            selected={data.riskIndicators.includes(phrase)}
            onClick={() => toggleArrayItem("riskIndicators", phrase)}
          />
        ))}
      </div>
      <Pill
        label="Nenhuma das opções acima"
        selected={data.riskIndicators.length === 0}
        onClick={() => update("riskIndicators", [])}
      />
    </div>

    {/* Risk alert — discreet and supportive */}
    {(showRiskAlert || data.riskIndicators.length > 0) && (
      <motion.div
        initial={{ opacity: 0, y: 10 }}
        animate={{ opacity: 1, y: 0 }}
        className="bg-card border border-primary/20 rounded-2xl p-6 space-y-3"
      >
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 rounded-full bg-primary/10 flex items-center justify-center flex-shrink-0">
            <Heart className="h-5 w-5 text-primary" />
          </div>
          <p className="text-sm font-medium text-foreground">Você não está sozinho(a)</p>
        </div>
        <p className="text-sm text-muted-foreground leading-relaxed">
          Se você está passando por um momento difícil, saiba que há pessoas prontas para te ouvir agora mesmo.
        </p>
        <a
          href="tel:188"
          className="inline-flex items-center gap-2 bg-primary text-primary-foreground px-5 py-3 rounded-xl text-sm font-medium hover:bg-primary/90 transition-colors"
        >
          <Phone className="h-4 w-4" />
          Ligue 188 — CVV (24h)
        </a>
        <p className="text-xs text-muted-foreground">Centro de Valorização da Vida — ligação gratuita, sigilo total.</p>
      </motion.div>
    )}
  </div>
);

/* Step 5 — Availability */
const Step5 = ({ data, toggleArrayItem }: { data: FormData; toggleArrayItem: (key: "riskIndicators" | "availability", item: string) => void }) => (
  <div className="space-y-8">
    <div>
      <SectionTitle>Sua disponibilidade</SectionTitle>
      <SectionSubtitle>Qual o melhor horário para uma conversa inicial?</SectionSubtitle>
    </div>
    <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
      {[
        { label: "Manhã", sub: "8h — 12h", icon: "☀️" },
        { label: "Tarde", sub: "12h — 18h", icon: "🌤️" },
        { label: "Noite", sub: "18h — 21h", icon: "🌙" },
      ].map((slot) => (
        <button
          key={slot.label}
          type="button"
          onClick={() => toggleArrayItem("availability", slot.label)}
          className={`flex flex-col items-center gap-2 py-8 rounded-2xl border text-center transition-all duration-300 ${
            data.availability.includes(slot.label)
              ? "bg-primary text-primary-foreground border-primary shadow-sm"
              : "bg-card text-foreground border-border hover:border-primary/40"
          }`}
        >
          <span className="text-2xl">{slot.icon}</span>
          <span className="font-medium">{slot.label}</span>
          <span className={`text-xs ${data.availability.includes(slot.label) ? "text-primary-foreground/70" : "text-muted-foreground"}`}>
            {slot.sub}
          </span>
        </button>
      ))}
    </div>
  </div>
);

/* Step 6 — Identification */
const Step6 = ({ data, update }: { data: FormData; update: <K extends keyof FormData>(k: K, v: FormData[K]) => void }) => {
  const inputClass =
    "w-full bg-card border border-border rounded-2xl px-5 py-3.5 text-sm text-foreground placeholder:text-muted-foreground/50 focus:outline-none focus:ring-2 focus:ring-primary/30";

  return (
    <div className="space-y-8">
      <div>
        <SectionTitle>Seus dados</SectionTitle>
        <SectionSubtitle>Precisamos de algumas informações para entrar em contato.</SectionSubtitle>
      </div>
      <div className="space-y-4">
        <div>
          <label className="text-sm font-medium text-foreground mb-2 block">Nome completo</label>
          <input type="text" value={data.name} onChange={(e) => update("name", e.target.value)} placeholder="Seu nome" className={inputClass} />
        </div>
        <div>
          <label className="text-sm font-medium text-foreground mb-2 block">E-mail</label>
          <input type="email" value={data.email} onChange={(e) => update("email", e.target.value)} placeholder="seu@email.com" className={inputClass} />
        </div>
        <div>
          <label className="text-sm font-medium text-foreground mb-2 block">Celular com DDD</label>
          <input type="tel" value={data.phone} onChange={(e) => update("phone", e.target.value)} placeholder="(11) 99999-9999" className={inputClass} />
        </div>
        <div className="grid grid-cols-2 gap-4">
          <div>
            <label className="text-sm font-medium text-foreground mb-2 block">Cidade</label>
            <input type="text" value={data.city} onChange={(e) => update("city", e.target.value)} placeholder="Sua cidade" className={inputClass} />
          </div>
          <div>
            <label className="text-sm font-medium text-foreground mb-2 block">Estado</label>
            <select
              value={data.state}
              onChange={(e) => update("state", e.target.value)}
              className={`${inputClass} appearance-none`}
            >
              <option value="">UF</option>
              {STATES.map((s) => (
                <option key={s} value={s}>{s}</option>
              ))}
            </select>
          </div>
        </div>
      </div>
    </div>
  );
};

/* Step 7 — Review */
const Step7 = () => (
  <div className="space-y-6 text-center">
    <SectionTitle>Quase lá</SectionTitle>
    <SectionSubtitle>Revise suas informações e clique em Enviar para finalizar.</SectionSubtitle>
    <div className="flex items-center justify-center">
      <div className="w-16 h-16 rounded-full bg-primary/10 flex items-center justify-center">
        <Send className="h-7 w-7 text-primary" />
      </div>
    </div>
    <p className="text-sm text-muted-foreground max-w-md mx-auto">
      Ao enviar, você concorda com o uso dessas informações exclusivamente para fins de triagem e acolhimento pela nossa equipe clínica.
    </p>
  </div>
);

/* ─── Confirmation Screen ─── */
const ConfirmationScreen = () => (
  <motion.div
    initial={{ opacity: 0, scale: 0.97 }}
    animate={{ opacity: 1, scale: 1 }}
    transition={{ duration: 0.6, ease: "easeOut" }}
    className="relative overflow-hidden rounded-3xl"
  >
    {/* Blurred team mosaic */}
    <div className="grid grid-cols-2 gap-1 absolute inset-0">
      {[doctor1, doctor2, doctor3, doctor4].map((src, i) => (
        <img key={i} src={src} alt="" className="w-full h-full object-cover blur-md brightness-50" />
      ))}
    </div>

    {/* Overlay content */}
    <div className="relative z-10 py-20 md:py-28 px-6 text-center">
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.3, duration: 0.6 }}
        className="space-y-6"
      >
        <div className="w-16 h-16 rounded-full bg-primary-foreground/20 backdrop-blur-sm flex items-center justify-center mx-auto">
          <CheckCircle className="h-8 w-8 text-primary-foreground" />
        </div>
        <h2
          className="text-3xl md:text-4xl font-bold text-primary-foreground"
          style={{ fontFamily: "'Playfair Display', serif" }}
        >
          Recebemos suas informações
        </h2>
        <p className="text-primary-foreground/80 max-w-md mx-auto leading-relaxed">
          Nossa equipe analisará seu formulário com cuidado e entrará em contato em breve para agendar sua conversa inicial.
        </p>
        <p className="text-primary-foreground/50 text-sm">
          Fique tranquilo(a) — suas informações estão seguras conosco.
        </p>
      </motion.div>
    </div>
  </motion.div>
);

export default AvaliacaoPage;
