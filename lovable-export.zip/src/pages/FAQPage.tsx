import Layout from "@/components/Layout";
import { motion } from "framer-motion";
import { useState } from "react";
import { Search, MessageCircle, Send, Bot, Brain, Pill, Apple, Moon } from "lucide-react";
import { Button } from "@/components/ui/button";
import StandardHero from "@/components/shared/StandardHero";
import WaveDivider from "@/components/shared/WaveDivider";

const faqCategories = [
  {
    icon: Brain,
    label: "Geral",
    faqs: [
      { q: "O que é psiquiatria metabólica?", a: "É uma abordagem que investiga e trata as causas biológicas e metabólicas por trás dos transtornos mentais — como disfunção mitocondrial, inflamação crônica, resistência à insulina e desequilíbrios nutricionais — em vez de focar apenas nos sintomas." },
      { q: "É necessário parar com a medicação atual?", a: "Não necessariamente. O tratamento é complementar e focado na redução progressiva sob supervisão médica. Nosso objetivo é alcançar estabilidade biológica para que, quando possível, a carga medicamentosa possa ser ajustada com segurança." },
      { q: "Quanto tempo para ver os primeiros resultados?", a: "Os primeiros sinais de melhora costumam ser percebidos entre 4 a 8 semanas, dependendo do quadro clínico e da adesão ao plano de intervenção. Mudanças no sono, energia e clareza mental geralmente são os primeiros indicadores." },
      { q: "A psiquiatria metabólica substitui a psiquiatria tradicional?", a: "Não. Ela complementa e amplia a abordagem tradicional, adicionando ferramentas de investigação e intervenção que atuam nas raízes biológicas do sofrimento mental. O objetivo é uma psiquiatria mais completa e personalizada." },
    ],
  },
  {
    icon: Apple,
    label: "Nutrição",
    faqs: [
      { q: "Preciso seguir uma dieta cetogênica?", a: "Não obrigatoriamente. A dieta cetogênica é uma das intervenções com maior evidência científica na psiquiatria metabólica, mas o plano alimentar é sempre individualizado. Algumas pessoas se beneficiam de abordagens low-carb, mediterrânea ou de eliminação." },
      { q: "Suplementos são necessários?", a: "Depende do caso. Após avaliação laboratorial detalhada, podem ser indicados suplementos como magnésio, ômega-3, vitamina D, zinco ou outros micronutrientes que estejam em deficiência e impactem a saúde mental." },
      { q: "Como a alimentação afeta o cérebro?", a: "O cérebro consome cerca de 20% da energia do corpo. Quando há disfunção no metabolismo energético — causada por dieta inadequada, resistência à insulina ou deficiências nutricionais — a função cerebral é diretamente comprometida, podendo gerar ou agravar sintomas psiquiátricos." },
    ],
  },
  {
    icon: Pill,
    label: "Tratamento",
    faqs: [
      { q: "O que é inflamação cerebral?", a: "É um processo inflamatório crônico no sistema nervoso central que pode afetar a função dos neurotransmissores e a saúde das células cerebrais. Fatores como dieta inadequada, sedentarismo, estresse crônico e distúrbios metabólicos podem contribuir para esse quadro." },
      { q: "Quais transtornos podem ser tratados?", a: "A abordagem metabólica tem mostrado resultados promissores em depressão resistente, transtorno bipolar, esquizofrenia, transtornos de ansiedade, TDAH e até transtornos alimentares. A resposta varia conforme o caso e os marcadores metabólicos individuais." },
      { q: "Como funciona o acompanhamento?", a: "O tratamento inclui avaliação inicial detalhada com exames laboratoriais, consultas de acompanhamento regulares, monitoramento de marcadores metabólicos e ajustes contínuos no plano terapêutico. Utilizamos métricas objetivas para medir o progresso." },
    ],
  },
  {
    icon: Moon,
    label: "Estilo de vida",
    faqs: [
      { q: "O sono realmente impacta a saúde mental?", a: "Sim, profundamente. O sono é quando o cérebro realiza processos de limpeza metabólica, consolidação de memória e regeneração celular. Distúrbios de sono estão diretamente associados a piora de praticamente todos os transtornos psiquiátricos." },
      { q: "Exercício físico faz parte do tratamento?", a: "Sim. O exercício é uma das intervenções com maior evidência em saúde mental: melhora a sensibilidade à insulina, reduz inflamação, aumenta BDNF (fator neurotrófico) e melhora a função mitocondrial. O tipo e intensidade são personalizados." },
      { q: "Estresse crônico é um fator metabólico?", a: "Absolutamente. O estresse crônico eleva cortisol de forma persistente, o que causa resistência à insulina, inflamação sistêmica, dano ao hipocampo e disfunção mitocondrial — todos fatores metabólicos que agravam transtornos mentais." },
    ],
  },
];

const FAQItem = ({ q, a, index }: { q: string; a: string; index: number }) => {
  const [open, setOpen] = useState(false);

  return (
    <motion.div
      className="border-b border-border"
      initial={{ opacity: 0, y: 15 }}
      whileInView={{ opacity: 1, y: 0 }}
      viewport={{ once: true }}
      transition={{ duration: 0.4, delay: index * 0.05 }}
    >
      <button className="w-full flex items-center justify-between py-5 text-left group" onClick={() => setOpen(!open)}>
        <span className="text-base md:text-lg font-medium text-foreground pr-4">{q}</span>
        <span className="relative flex-shrink-0 w-7 h-7 flex items-center justify-center">
          <motion.span className="absolute w-4 h-[1.5px] bg-primary rounded-full" animate={{ rotate: open ? 45 : 0 }} transition={{ duration: 0.3 }} />
          <motion.span className="absolute w-4 h-[1.5px] bg-primary rounded-full" animate={{ rotate: open ? -45 : 90 }} transition={{ duration: 0.3 }} />
        </span>
      </button>
      <motion.div className="overflow-hidden" initial={false} animate={{ height: open ? "auto" : 0, opacity: open ? 1 : 0 }} transition={{ duration: 0.3 }}>
        <p className="pb-5 text-muted-foreground leading-relaxed max-w-2xl">{a}</p>
      </motion.div>
    </motion.div>
  );
};

const ChatPlaceholder = () => {
  const [message, setMessage] = useState("");
  const [messages, setMessages] = useState<{ role: string; text: string }[]>([
    { role: "bot", text: "Olá! Sou o assistente virtual da Psiquiatria Metabólica. Posso ajudar a esclarecer dúvidas gerais sobre a abordagem metabólica em saúde mental. Lembrando que não substituo uma consulta médica. Como posso ajudar?" },
  ]);

  const handleSend = () => {
    if (!message.trim()) return;
    setMessages((prev) => [
      ...prev,
      { role: "user", text: message },
      { role: "bot", text: "Obrigado pela pergunta! Este recurso de IA ainda está em desenvolvimento. Em breve, poderei responder suas dúvidas com base na literatura científica sobre psiquiatria metabólica. Por enquanto, consulte as perguntas frequentes acima ou entre em contato com nossa equipe." },
    ]);
    setMessage("");
  };

  return (
    <div className="bg-background rounded-2xl border border-border overflow-hidden max-w-2xl mx-auto">
      <div className="bg-primary px-6 py-4 flex items-center gap-3">
        <div className="w-9 h-9 rounded-full bg-primary-foreground/20 flex items-center justify-center">
          <Bot className="h-5 w-5 text-primary-foreground" />
        </div>
        <div>
          <p className="text-sm font-semibold text-primary-foreground">Assistente IA</p>
          <p className="text-xs text-primary-foreground/60">Psiquiatria Metabólica</p>
        </div>
        <span className="ml-auto text-xs bg-primary-foreground/20 text-primary-foreground px-2 py-0.5 rounded-full">Beta</span>
      </div>
      <div className="h-72 overflow-y-auto p-5 space-y-4">
        {messages.map((msg, i) => (
          <div key={i} className={`flex ${msg.role === "user" ? "justify-end" : "justify-start"}`}>
            <div className={`max-w-[80%] px-4 py-3 rounded-2xl text-sm leading-relaxed ${msg.role === "user" ? "bg-primary text-primary-foreground rounded-br-md" : "bg-muted text-foreground rounded-bl-md"}`}>
              {msg.text}
            </div>
          </div>
        ))}
      </div>
      <div className="border-t border-border p-4 flex gap-3">
        <input
          type="text"
          value={message}
          onChange={(e) => setMessage(e.target.value)}
          onKeyDown={(e) => e.key === "Enter" && handleSend()}
          placeholder="Digite sua dúvida..."
          className="flex-1 bg-muted/50 border border-border rounded-xl px-4 py-2.5 text-sm text-foreground placeholder:text-muted-foreground/60 focus:outline-none focus:ring-2 focus:ring-primary/30"
        />
        <Button onClick={handleSend} size="icon" className="bg-primary text-primary-foreground hover:bg-primary/90 rounded-xl h-10 w-10">
          <Send className="h-4 w-4" />
        </Button>
      </div>
    </div>
  );
};

const FAQPage = () => {
  const [activeCategory, setActiveCategory] = useState(0);
  const [searchTerm, setSearchTerm] = useState("");

  const currentFaqs = faqCategories[activeCategory].faqs.filter(
    (faq) => !searchTerm || faq.q.toLowerCase().includes(searchTerm.toLowerCase()) || faq.a.toLowerCase().includes(searchTerm.toLowerCase())
  );

  return (
    <Layout>
      <StandardHero
        variant="default"
        eyebrow="Central de Ajuda"
        title="Dúvidas Frequentes"
        description="Tudo o que você precisa saber sobre psiquiatria metabólica, tratamento e estilo de vida."
      >
        <div className="relative max-w-lg mx-auto">
          <Search className="absolute left-4 top-1/2 -translate-y-1/2 h-5 w-5 text-muted-foreground" />
          <input
            type="text"
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            placeholder="Buscar uma dúvida..."
            className="w-full bg-background rounded-xl pl-12 pr-4 py-3.5 text-sm text-foreground placeholder:text-muted-foreground/60 focus:outline-none focus:ring-2 focus:ring-secondary/50 border border-border"
          />
        </div>
      </StandardHero>

      <WaveDivider fillColor="hsl(var(--background))" heightClass="h-6 md:h-8" />

      {/* Categories + FAQs — light section */}
      <section className="py-20 md:py-28 bg-background">
        <div className="container max-w-4xl">
          <motion.div
            className="flex flex-wrap justify-center gap-3 mb-14"
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.5 }}
          >
            {faqCategories.map((cat, i) => (
              <button
                key={i}
                onClick={() => setActiveCategory(i)}
                className={`flex items-center gap-2 px-5 py-2.5 rounded-full text-sm font-medium border transition-all duration-300 ${
                  activeCategory === i
                    ? "bg-card text-foreground border-border shadow-sm"
                    : "bg-card/60 text-muted-foreground border-border hover:text-foreground hover:bg-card"
                }`}
              >
                <cat.icon className="h-4 w-4" />
                {cat.label}
              </button>
            ))}
          </motion.div>

          <div>
            {currentFaqs.length > 0 ? (
              currentFaqs.map((faq, i) => (
                <motion.div
                  key={`${activeCategory}-${i}`}
                  className="border-b border-border/80"
                  initial={{ opacity: 0, y: 15 }}
                  whileInView={{ opacity: 1, y: 0 }}
                  viewport={{ once: true }}
                  transition={{ duration: 0.4, delay: i * 0.05 }}
                >
                  <FAQItem q={faq.q} a={faq.a} index={i} />
                </motion.div>
              ))
            ) : (
              <p className="text-center text-muted-foreground py-10">Nenhuma dúvida encontrada para "{searchTerm}".</p>
            )}
          </div>
        </div>
      </section>

      {/* Wave before AI section */}
      <WaveDivider fillColor="hsl(var(--muted))" heightClass="h-6 md:h-8" />

      {/* AI Chatbot — light section */}
      <section className="py-20 md:py-28 bg-muted">
        <div className="container max-w-4xl">
          <motion.div
            className="text-center mb-12"
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.7 }}
          >
            <div className="inline-flex items-center gap-2 bg-primary/10 text-primary text-sm font-medium px-4 py-1.5 rounded-full mb-4">
              <MessageCircle className="h-4 w-4" />
              Em breve
            </div>
            <h2 className="text-3xl md:text-4xl font-bold text-primary mb-4">Assistente Inteligente</h2>
            <p className="text-muted-foreground max-w-xl mx-auto">
              Tire suas dúvidas com nossa IA treinada em literatura científica sobre psiquiatria metabólica. Sem recomendações médicas — apenas informação de qualidade.
            </p>
          </motion.div>

          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.6, delay: 0.2 }}
          >
            <ChatPlaceholder />
          </motion.div>
        </div>
      </section>
    </Layout>
  );
};

// Dark-themed FAQ item for use on dark backgrounds
const FAQItemDark = ({ q, a, index }: { q: string; a: string; index: number }) => {
  const [open, setOpen] = useState(false);

  return (
    <>
      <button className="w-full flex items-center justify-between py-5 text-left group" onClick={() => setOpen(!open)}>
        <span className="text-base md:text-lg font-medium text-primary-foreground pr-4">{q}</span>
        <span className="relative flex-shrink-0 w-7 h-7 flex items-center justify-center">
          <motion.span className="absolute w-4 h-[1.5px] bg-primary-foreground/60 rounded-full" animate={{ rotate: open ? 45 : 0 }} transition={{ duration: 0.3 }} />
          <motion.span className="absolute w-4 h-[1.5px] bg-primary-foreground/60 rounded-full" animate={{ rotate: open ? -45 : 90 }} transition={{ duration: 0.3 }} />
        </span>
      </button>
      <motion.div className="overflow-hidden" initial={false} animate={{ height: open ? "auto" : 0, opacity: open ? 1 : 0 }} transition={{ duration: 0.3 }}>
        <p className="pb-5 text-primary-foreground/60 leading-relaxed max-w-2xl">{a}</p>
      </motion.div>
    </>
  );
};

export default FAQPage;
