import Layout from "@/components/Layout";
import SEO from "@/components/SEO";
import HeroSection from "@/components/HeroSection";
import PyramidsSection from "@/components/PyramidsSection";
import BrainMetabolicSection from "@/components/BrainMetabolicSection";
import HowItWorksSection from "@/components/HowItWorksSection";
import ResultsSection from "@/components/ResultsSection";
import WhyMetabolismSection from "@/components/WhyMetabolismSection";
import FAQSection from "@/components/FAQSection";

const Index = () => (
  <Layout>
    <SEO
      title="Metabolicamente — Psiquiatria metabólica e nutrição funcional"
      description="Cuidamos da sua mente cuidando do seu metabolismo. Acompanhamento integrado entre psiquiatra e nutricionista, baseado em ciência."
      jsonLd={{
        "@context": "https://schema.org",
        "@type": "MedicalOrganization",
        name: "Clínica Metabolicamente",
        medicalSpecialty: ["Psychiatry", "Nutrition"],
        url: typeof window !== "undefined" ? window.location.origin : undefined,
      }}
    />
    <HeroSection />
    <PyramidsSection />
    <BrainMetabolicSection />
    <HowItWorksSection />
    <ResultsSection />
    <WhyMetabolismSection />
    <FAQSection />
  </Layout>
);

export default Index;

