import { useState } from "react";
import { motion } from "framer-motion";
import { Brain, Mail, CheckCircle, X } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import Layout from "@/components/Layout";
import StandardHero from "@/components/shared/StandardHero";
import WaveDivider from "@/components/shared/WaveDivider";

import doctor1 from "@/assets/doctor-1.jpg";
import doctor2 from "@/assets/doctor-2.jpg";
import doctor3 from "@/assets/doctor-3.jpg";
import doctor4 from "@/assets/doctor-4.jpg";

const specialists = [
  {
    name: "Dr. Ricardo Mendes",
    role: "Psiquiatra — Diretor Clínico",
    crm: "CRM/SP 142.587",
    photo: doctor1,
    bio: "Formado pela Faculdade de Medicina da USP, com residência em Psiquiatria no Hospital das Clínicas. Especialização em Psiquiatria Metabólica pela Harvard Medical School. Mais de 18 anos de experiência clínica integrando intervenções nutricionais, metabólicas e farmacológicas no tratamento de transtornos mentais graves.",
    highlights: ["Psiquiatria Metabólica", "Transtornos de Humor", "Dieta Cetogênica Terapêutica"]
  },
  {
    name: "Dra. Camila Ferreira",
    role: "Psiquiatra — Neurometabolismo",
    crm: "CRM/SP 158.203",
    photo: doctor2,
    bio: "Graduada pela UNIFESP com fellowship em Neuropsiquiatria e Metabolismo Cerebral. Pesquisadora ativa com publicações em periódicos internacionais sobre a relação entre disfunção mitocondrial e doenças psiquiátricas. Atua com foco em esquizofrenia, transtorno bipolar e depressão resistente ao tratamento.",
    highlights: ["Neurometabolismo", "Depressão Resistente", "Pesquisa Clínica"]
  },
  {
    name: "Dr. Lucas Tavares",
    role: "Nutrólogo — Nutrição Funcional",
    crm: "CRM/RJ 098.412",
    photo: doctor3,
    bio: "Médico nutrólogo com formação pela UERJ e pós-graduação em Nutrição Clínica Funcional pelo Instituto VP. Especialista em protocolos nutricionais personalizados para otimização da saúde mental, incluindo dietas terapêuticas, suplementação baseada em evidências e manejo de resistência à insulina.",
    highlights: ["Nutrição Funcional", "Suplementação Baseada em Evidências", "Saúde Metabólica"]
  },
  {
    name: "Dra. Beatriz Linhares",
    role: "Psicóloga Clínica — TCC e Mudança Comportamental",
    crp: "CRP 05/67.891",
    photo: doctor4,
    bio: "Psicóloga clínica com mestrado em Psicologia da Saúde pela PUC-Rio. Especialista em Terapia Cognitivo-Comportamental com foco em adesão a mudanças de estilo de vida. Trabalha de forma integrada com a equipe médica para garantir que as intervenções metabólicas sejam sustentáveis e centradas no paciente.",
    highlights: ["Mudança de Estilo de Vida", "Psicoeducação"]
  }
];

const fadeUp = {
  hidden: { opacity: 0, y: 40 },
  visible: (i: number) => ({
    opacity: 1, y: 0,
    transition: { duration: 0.7, delay: i * 0.15, ease: [0.25, 0.46, 0.45, 0.94] as [number, number, number, number] }
  })
};

const EquipePage = () => {
  const [formOpen, setFormOpen] = useState(false);
  const [submitted, setSubmitted] = useState(false);
  const [formData, setFormData] = useState({ nome: "", email: "", formacao: "", especialidade: "", abordagem: "", disponibilidade: "", info: "" });
  const [errors, setErrors] = useState<Record<string, string>>({});

  const validate = () => {
    const newErrors: Record<string, string> = {};
    if (!formData.nome.trim()) newErrors.nome = "Nome é obrigatório";
    if (!formData.email.trim() || !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(formData.email)) newErrors.email = "E-mail inválido";
    if (!formData.formacao.trim()) newErrors.formacao = "Formação é obrigatória";
    if (!formData.especialidade.trim()) newErrors.especialidade = "Selecione uma especialidade";
    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };

  const handleSubmit = (e: React.FormEvent) => { e.preventDefault(); if (validate()) setSubmitted(true); };
  const resetForm = () => { setFormOpen(false); setSubmitted(false); setFormData({ nome: "", email: "", formacao: "", especialidade: "", abordagem: "", disponibilidade: "", info: "" }); setErrors({}); };

  return (
    <Layout>
      <StandardHero
        variant="aurora"
        eyebrow="Excelência em Psiquiatria Metabólica"
        title="Corpo Clínico"
        description="Profissionais unidos pela missão de transformar a saúde mental através da abordagem metabólica."
      />

      <WaveDivider fillColor="hsl(var(--background))" heightClass="h-6 md:h-8" />

      {/* Specialists Gallery */}
      <section className="py-20 md:py-28 bg-background">
        <div className="container max-w-6xl">
          {/* Mobile */}
          <div className="grid grid-cols-2 gap-x-4 gap-y-12 md:hidden">
            {specialists.map((doc, i) => (
              <motion.div key={doc.name} custom={i} initial="hidden" whileInView="visible" viewport={{ once: true, margin: "-40px" }} variants={fadeUp} className="flex flex-col">
                <img src={doc.photo} alt={`Foto de ${doc.name}`} className="w-full aspect-[3/4] object-cover rounded-lg shadow-md mb-4" loading="lazy" />
                <p className="text-[10px] uppercase tracking-[0.2em] text-muted-foreground mb-1" style={{ fontFamily: "'Montserrat', sans-serif" }}>{doc.crm || doc.crp}</p>
                <h2 className="text-base font-bold text-foreground mb-0.5" style={{ fontFamily: "'Montserrat', sans-serif" }}>{doc.name}</h2>
                <p className="text-primary font-medium text-xs mb-3" style={{ fontFamily: "'Montserrat', sans-serif" }}>{doc.role}</p>
                <p className="text-muted-foreground leading-relaxed text-xs">{doc.bio}</p>
              </motion.div>
            ))}
          </div>

          {/* Desktop */}
          <div className="hidden md:block">
            {specialists.map((doc, i) => {
              const isEven = i % 2 === 0;
              return (
                <motion.div key={doc.name} custom={i} initial="hidden" whileInView="visible" viewport={{ once: true, margin: "-80px" }} variants={fadeUp}
                  className={`flex ${isEven ? "md:flex-row" : "md:flex-row-reverse"} gap-16 items-center mb-28 last:mb-0`}>
                  <div className="w-5/12 shrink-0">
                    <div className="relative group">
                      <div className="absolute -inset-3 rounded-2xl opacity-0 group-hover:opacity-100 transition-opacity duration-500"
                        style={{ background: "linear-gradient(135deg, hsl(var(--primary) / 0.15), hsl(var(--accent) / 0.1))" }} />
                      <img src={doc.photo} alt={`Foto de ${doc.name}`} className="relative w-full aspect-[4/5] object-cover rounded-xl shadow-lg" loading="lazy" />
                    </div>
                  </div>
                  <div className="w-7/12">
                    <p className="text-xs uppercase tracking-[0.25em] text-muted-foreground mb-2" style={{ fontFamily: "'Montserrat', sans-serif" }}>{doc.crm || doc.crp}</p>
                    <h2 className="text-4xl font-bold text-foreground mb-1" style={{ fontFamily: "'Montserrat', sans-serif" }}>{doc.name}</h2>
                    <p className="text-primary font-medium text-lg mb-6" style={{ fontFamily: "'Montserrat', sans-serif" }}>{doc.role}</p>
                    <p className="text-muted-foreground leading-[1.8] text-base">{doc.bio}</p>
                  </div>
                </motion.div>
              );
            })}
          </div>
        </div>
      </section>

      <WaveDivider fillColor="hsl(var(--muted))" />

      {/* Recruitment CTA */}
      <section className="py-20 md:py-28 bg-muted">
        <div className="container max-w-3xl text-center">
          <motion.div initial={{ opacity: 0, y: 30 }} whileInView={{ opacity: 1, y: 0 }} viewport={{ once: true }} transition={{ duration: 0.7 }}>
            <p className="text-xs uppercase tracking-[0.3em] text-muted-foreground mb-3" style={{ fontFamily: "'Montserrat', sans-serif" }}>Oportunidades</p>
            <h2 className="text-3xl md:text-4xl font-bold text-foreground mb-4" style={{ fontFamily: "'Montserrat', sans-serif" }}>Faça parte da nossa equipe</h2>
            <p className="text-muted-foreground leading-relaxed mb-8 max-w-xl mx-auto">
              Buscamos profissionais que compartilham da nossa visão integrativa e desejam fazer parte de uma clínica que está redefinindo o cuidado em saúde mental.
            </p>
            <Button onClick={() => { setFormOpen(true); setSubmitted(false); }}
              className="bg-primary text-primary-foreground hover:bg-primary/90 px-8 py-3 h-auto text-base hover:shadow-lg hover:shadow-primary/20 transition-all duration-300"
              style={{ fontFamily: "'Montserrat', sans-serif" }}>
              <Mail className="h-4 w-4 mr-2" /> Quero trabalhar com vocês
            </Button>
          </motion.div>
        </div>
      </section>

      {/* Application Modal */}
      {formOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4">
          <div className="absolute inset-0 bg-foreground/40 backdrop-blur-sm" onClick={resetForm} />
          <motion.div initial={{ opacity: 0, scale: 0.95, y: 20 }} animate={{ opacity: 1, scale: 1, y: 0 }} transition={{ duration: 0.3 }}
            className="relative w-full max-w-lg max-h-[90vh] overflow-y-auto rounded-2xl border border-border bg-background shadow-2xl p-6 md:p-8">
            <button onClick={resetForm} className="absolute top-4 right-4 text-muted-foreground hover:text-foreground transition-colors" aria-label="Fechar">
              <X className="h-5 w-5" />
            </button>

            {!submitted ? (
              <>
                <div className="mb-6">
                  <h3 className="text-2xl font-bold text-foreground" style={{ fontFamily: "'Montserrat', sans-serif" }}>Candidatura</h3>
                  <p className="text-sm text-muted-foreground mt-1">Preencha seus dados e entraremos em contato.</p>
                </div>
                <form onSubmit={handleSubmit} className="space-y-4">
                  <div><Label htmlFor="nome">Nome completo *</Label><Input id="nome" value={formData.nome} onChange={(e) => setFormData({ ...formData, nome: e.target.value })} className={errors.nome ? "border-destructive" : ""} maxLength={100} />{errors.nome && <p className="text-xs text-destructive mt-1">{errors.nome}</p>}</div>
                  <div><Label htmlFor="email">E-mail *</Label><Input id="email" type="email" value={formData.email} onChange={(e) => setFormData({ ...formData, email: e.target.value })} className={errors.email ? "border-destructive" : ""} maxLength={255} />{errors.email && <p className="text-xs text-destructive mt-1">{errors.email}</p>}</div>
                  <div><Label htmlFor="formacao">Formação acadêmica *</Label><Input id="formacao" value={formData.formacao} onChange={(e) => setFormData({ ...formData, formacao: e.target.value })} className={errors.formacao ? "border-destructive" : ""} placeholder="Ex: Medicina — USP, 2015" maxLength={200} />{errors.formacao && <p className="text-xs text-destructive mt-1">{errors.formacao}</p>}</div>
                  <div>
                    <Label>Especialidade *</Label>
                    <Select value={formData.especialidade} onValueChange={(v) => setFormData({ ...formData, especialidade: v })}>
                      <SelectTrigger className={errors.especialidade ? "border-destructive" : ""}><SelectValue placeholder="Selecione" /></SelectTrigger>
                      <SelectContent>
                        <SelectItem value="psiquiatria">Psiquiatria</SelectItem>
                        <SelectItem value="nutrologia">Nutrologia</SelectItem>
                        <SelectItem value="psicologia">Psicologia</SelectItem>
                        <SelectItem value="neurologia">Neurologia</SelectItem>
                        <SelectItem value="endocrinologia">Endocrinologia</SelectItem>
                        <SelectItem value="outra">Outra</SelectItem>
                      </SelectContent>
                    </Select>
                    {errors.especialidade && <p className="text-xs text-destructive mt-1">{errors.especialidade}</p>}
                  </div>
                  <div><Label htmlFor="abordagem">Abordagem terapêutica</Label><Input id="abordagem" value={formData.abordagem} onChange={(e) => setFormData({ ...formData, abordagem: e.target.value })} placeholder="Ex: TCC, Psiquiatria Metabólica, Nutrição Funcional" maxLength={200} /></div>
                  <div>
                    <Label>Disponibilidade</Label>
                    <Select value={formData.disponibilidade} onValueChange={(v) => setFormData({ ...formData, disponibilidade: v })}>
                      <SelectTrigger><SelectValue placeholder="Selecione" /></SelectTrigger>
                      <SelectContent>
                        <SelectItem value="integral">Integral</SelectItem>
                        <SelectItem value="parcial">Parcial</SelectItem>
                        <SelectItem value="turnos">Por turnos</SelectItem>
                        <SelectItem value="negociar">A negociar</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                  <div><Label htmlFor="info">Informações adicionais</Label><Textarea id="info" value={formData.info} onChange={(e) => setFormData({ ...formData, info: e.target.value })} placeholder="Conte-nos sobre sua motivação, experiência ou qualquer informação relevante." rows={3} maxLength={1000} /></div>
                  <Button type="submit" className="w-full bg-primary text-primary-foreground hover:bg-primary/90 h-11 text-base mt-2" style={{ fontFamily: "'Montserrat', sans-serif" }}>Enviar candidatura</Button>
                </form>
              </>
            ) : (
              <div className="text-center py-8">
                <motion.div initial={{ scale: 0 }} animate={{ scale: 1 }} transition={{ type: "spring", stiffness: 200, damping: 15 }}>
                  <CheckCircle className="h-16 w-16 text-primary mx-auto mb-6" />
                </motion.div>
                <div className="flex items-center justify-center gap-2 mb-4">
                  <Brain className="h-6 w-6 text-primary" />
                  <span className="text-lg font-bold text-primary" style={{ fontFamily: "'Montserrat', sans-serif" }}><span className="text-lg font-bold text-primary" style={{ fontFamily: "'Montserrat', sans-serif" }}>Metabolicamente</span></span>
                </div>
                <h3 className="text-2xl font-bold text-foreground mb-3" style={{ fontFamily: "'Montserrat', sans-serif" }}>Obrigado, {formData.nome.split(" ")[0]}!</h3>
                <p className="text-muted-foreground leading-relaxed max-w-sm mx-auto mb-6">
                  Recebemos sua candidatura com sucesso. Nossa equipe analisará seu perfil e entrará em contato em breve.
                </p>
                <Button onClick={resetForm} variant="outline" className="rounded-full">Fechar</Button>
              </div>
            )}
          </motion.div>
        </div>
      )}
    </Layout>
  );
};

export default EquipePage;
