import { useState, useMemo } from "react";
import { Link } from "react-router-dom";
import Layout from "@/components/Layout";
import { motion } from "framer-motion";
import { Play, FileText, Youtube, Search, ArrowRight } from "lucide-react";
import StandardHero from "@/components/shared/StandardHero";
import WaveDivider from "@/components/shared/WaveDivider";
import { opinionArticles } from "@/data/opinion-articles";

const videos = [
  {
    title: "A Dieta Cetogênica é Mais Eficaz que Antidepressivos?",
    channel: "Roundabout Productions",
    guest: "Dr. Régis Chachamovich",
    thumbnail: "https://img.youtube.com/vi/dI0CztCzjbc/hqdefault.jpg",
    url: "https://www.youtube.com/watch?v=dI0CztCzjbc",
    description: "Dr. Régis Chachamovich explica por que o uso crescente de antidepressivos não está melhorando a saúde mental e apresenta a dieta cetogênica como intervenção terapêutica eficaz.",
  },
  {
    title: "Alimente seu Cérebro: Como a Dieta Pode Ser a Chave para Saúde Mental",
    channel: "Modo Primal Podcast",
    guest: "Dr. Régis Chachamovich",
    thumbnail: "https://img.youtube.com/vi/sWiJ679ZWFE/hqdefault.jpg",
    url: "https://www.youtube.com/watch?v=sWiJ679ZWFE",
    description: "Conversa sobre alimentação ancestral, saúde metabólica e como a nutrição impacta diretamente o funcionamento cerebral e a saúde mental.",
  },
  {
    title: "Esse Método Cura a Depressão?",
    channel: "Antonio Kraychete",
    guest: "Dr. Régis Chachamovich",
    thumbnail: "https://img.youtube.com/vi/LcFeODsiXI4/hqdefault.jpg",
    url: "https://www.youtube.com/watch?v=LcFeODsiXI4",
    description: "Entrevista sobre abordagens metabólicas para o tratamento da depressão, explorando alternativas além da medicação tradicional.",
  },
  {
    title: "Como o Metabolismo Pode Salvar Sua Saúde Mental",
    channel: "Lutz Podcast",
    guest: "Dr. Régis Chachamovich",
    thumbnail: "https://img.youtube.com/vi/927R9WQL9ps/hqdefault.jpg",
    url: "https://www.youtube.com/watch?v=927R9WQL9ps",
    description: "Dr. Régis Chachamovich, pioneiro em psiquiatria metabólica no Brasil, revela a relação entre doenças metabólicas, dieta cetogênica e transtornos mentais.",
  },
  {
    title: "Somos Viciados em Carboidratos?",
    channel: "Roundabout Productions",
    guest: "Dr. Juan Pablo Roig",
    thumbnail: "https://img.youtube.com/vi/q5IBHaYKKJc/hqdefault.jpg",
    url: "https://www.youtube.com/watch?v=q5IBHaYKKJc",
    description: "Dr. Juan Pablo Roig explora a compulsão alimentar, o vício em carboidratos e o papel da inflamação, dopamina e resistência à insulina na saúde mental.",
  },
  {
    title: "Médico Curou o Fígado e a Depressão com Dieta Carnívora",
    channel: "Modo Primal Podcast",
    guest: "Dr. Juan Pablo Roig",
    thumbnail: "https://img.youtube.com/vi/IpLo1B4fhF0/hqdefault.jpg",
    url: "https://www.youtube.com/watch?v=IpLo1B4fhF0",
    description: "Episódio sobre alimentação ancestral, saúde metabólica e psiquiatria metabólica, com relato de experiência pessoal e prática clínica.",
  },
];

const fadeUp = {
  initial: { opacity: 0, y: 20 },
  whileInView: { opacity: 1, y: 0 },
  viewport: { once: true },
};

const ConteudoPage = () => {
  const [searchTerm, setSearchTerm] = useState("");
  const [activeTag, setActiveTag] = useState<string>("Todos");
  const lowerSearch = searchTerm.toLowerCase();

  const allTags = useMemo(() => {
    const channels = Array.from(new Set(videos.map(v => v.channel)));
    return ["Todos", ...channels];
  }, []);

  const filteredVideos = videos.filter(v => {
    const matchesSearch = !searchTerm || v.title.toLowerCase().includes(lowerSearch) || v.channel.toLowerCase().includes(lowerSearch) || v.description.toLowerCase().includes(lowerSearch);
    const matchesTag = activeTag === "Todos" || v.channel === activeTag;
    return matchesSearch && matchesTag;
  });
  const filteredArticles = opinionArticles.filter(a =>
    !searchTerm || a.title.toLowerCase().includes(lowerSearch) || a.source.toLowerCase().includes(lowerSearch)
  );

  return (
    <Layout>
      <StandardHero
        variant="organic"
        eyebrow="Biblioteca de Conhecimento"
        title="Conteúdo"
        description="Vídeos, artigos e podcasts sobre psiquiatria metabólica e saúde mental baseada em evidências."
      >
        <div className="relative max-w-md mx-auto">
          <Search className="absolute left-4 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
          <input
            type="text"
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            placeholder="Buscar vídeos, artigos ou podcasts..."
            className="w-full bg-background rounded-xl pl-11 pr-4 py-3.5 text-sm text-foreground placeholder:text-muted-foreground/60 focus:outline-none focus:ring-2 focus:ring-secondary/50 border border-border"
          />
        </div>

        <div className="flex flex-wrap gap-2 justify-center mt-5">
          {allTags.map(tag => (
            <button
              key={tag}
              onClick={() => setActiveTag(tag)}
              className={`text-xs px-3 py-1.5 rounded-full border transition-all ${
                activeTag === tag
                  ? "bg-secondary text-secondary-foreground border-secondary"
                  : "bg-background/70 text-foreground/70 border-border hover:border-secondary/50"
              }`}
            >
              {tag}
            </button>
          ))}
        </div>
      </StandardHero>

      <WaveDivider fillColor="hsl(var(--muted))" />

      {/* Videos — light/muted section */}
      <section className="py-20 md:py-28 bg-muted">
        <div className="container max-w-6xl">
          <motion.div className="flex items-center gap-3 mb-10" {...fadeUp} transition={{ duration: 0.5 }}>
            <div className="w-10 h-10 rounded-xl bg-primary/10 flex items-center justify-center">
              <Youtube className="h-5 w-5 text-primary" />
            </div>
            <h2 className="text-2xl md:text-3xl font-bold text-foreground">Vídeos e Podcasts</h2>
          </motion.div>

          <div className="grid grid-cols-2 lg:grid-cols-3 gap-4 md:gap-6">
            {filteredVideos.map((video, i) => (
              <motion.a
                key={i}
                href={video.url}
                target="_blank"
                rel="noopener noreferrer"
                className="group rounded-2xl overflow-hidden border border-border bg-background hover:shadow-xl transition-all duration-300"
                {...fadeUp}
                transition={{ duration: 0.4, delay: i * 0.06 }}
              >
                <div className="relative aspect-video overflow-hidden">
                  <img src={video.thumbnail} alt={video.title} className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500" loading="lazy" />
                  <div className="absolute inset-0 bg-foreground/0 group-hover:bg-foreground/20 transition-colors duration-300 flex items-center justify-center">
                    <div className="w-12 h-12 md:w-14 md:h-14 rounded-full bg-primary/90 flex items-center justify-center opacity-0 group-hover:opacity-100 transition-opacity duration-300 shadow-lg">
                      <Play className="h-5 w-5 md:h-6 md:w-6 text-primary-foreground ml-1" />
                    </div>
                  </div>
                </div>
                <div className="p-4 md:p-5">
                  <p className="text-[10px] md:text-xs text-muted-foreground mb-1 font-medium">{video.channel}{video.guest ? ` · ${video.guest}` : ''}</p>
                  <h3 className="text-xs md:text-sm font-bold text-foreground mb-1 md:mb-2 line-clamp-2 group-hover:text-primary transition-colors">{video.title}</h3>
                  <p className="text-[10px] md:text-xs text-muted-foreground/70 leading-relaxed line-clamp-2 hidden sm:block">{video.description}</p>
                </div>
              </motion.a>
            ))}
          </div>
          {filteredVideos.length === 0 && <p className="text-center text-muted-foreground py-12">Nenhum vídeo encontrado para "{searchTerm}".</p>}
        </div>
      </section>

      <WaveDivider fillColor="hsl(var(--hero-bg))" />

      {/* Articles — dark section */}
      <section className="py-20 md:py-28" style={{ background: "hsl(var(--hero-bg))" }}>
        <div className="container max-w-6xl">
          <motion.div className="flex items-center gap-3 mb-10" {...fadeUp} transition={{ duration: 0.5 }}>
            <div className="w-10 h-10 rounded-xl bg-white/10 flex items-center justify-center">
              <FileText className="h-5 w-5 text-primary-foreground/80" />
            </div>
            <h2 className="text-2xl md:text-3xl font-bold text-primary-foreground">Artigos de Opinião</h2>
          </motion.div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-5">
            {filteredArticles.map((article, i) => (
              <motion.div key={article.id} {...fadeUp} transition={{ duration: 0.4, delay: i * 0.08 }}>
                <Link
                  to={`/conteudo/artigo/${article.id}`}
                  className="group flex gap-5 p-5 rounded-2xl border border-white/10 bg-white/[0.03] hover:bg-white/[0.06] hover:shadow-lg transition-all duration-300"
                >
                  {/* Generic elegant image placeholder */}
                  <div className="hidden sm:block flex-shrink-0 w-24 h-24 md:w-28 md:h-28 rounded-xl overflow-hidden bg-gradient-to-br from-primary/30 to-secondary/20">
                    <div className="w-full h-full flex items-center justify-center">
                      <FileText className="h-8 w-8 text-primary-foreground/30" />
                    </div>
                  </div>
                  <div className="flex-1 min-w-0">
                    <p className="text-xs text-primary-foreground/50 mb-1 font-medium">{article.source}</p>
                    <h3 className="text-sm md:text-base font-bold text-primary-foreground mb-2 line-clamp-2 group-hover:text-secondary transition-colors">{article.title}</h3>
                    <p className="text-xs text-primary-foreground/40 leading-relaxed line-clamp-2">{article.excerpt}</p>
                    <span className="inline-flex items-center gap-1 text-xs font-medium text-secondary mt-3 group-hover:gap-2 transition-all">
                      Ler artigo <ArrowRight className="h-3 w-3" />
                    </span>
                  </div>
                </Link>
              </motion.div>
            ))}
          </div>
          {filteredArticles.length === 0 && <p className="text-center text-primary-foreground/50 py-12">Nenhum artigo encontrado para "{searchTerm}".</p>}
        </div>
      </section>

    </Layout>
  );
};

export default ConteudoPage;
