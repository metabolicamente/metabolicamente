import { useParams, Link } from "react-router-dom";
import { useState } from "react";
import { motion } from "framer-motion";
import { ArrowLeft, ExternalLink, MessageSquare, Send } from "lucide-react";
import Layout from "@/components/Layout";
import { opinionArticles } from "@/data/opinion-articles";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import { Input } from "@/components/ui/input";
import WaveDivider from "@/components/shared/WaveDivider";

interface Comment {
  id: number;
  name: string;
  text: string;
  date: string;
}

const OpinionArticlePage = () => {
  const { id } = useParams<{ id: string }>();
  const article = opinionArticles.find((a) => a.id === id);

  const [comments, setComments] = useState<Comment[]>([]);
  const [newName, setNewName] = useState("");
  const [newComment, setNewComment] = useState("");

  if (!article) {
    return (
      <Layout>
        <div className="container py-20 text-center">
          <h1 className="text-2xl font-bold text-foreground mb-4">Artigo não encontrado</h1>
          <Link to="/conteudo" className="text-primary hover:underline">← Voltar ao conteúdo</Link>
        </div>
      </Layout>
    );
  }

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newName.trim() || !newComment.trim()) return;
    setComments((prev) => [
      ...prev,
      { id: Date.now(), name: newName.trim(), text: newComment.trim(), date: new Date().toLocaleDateString("pt-BR", { day: "2-digit", month: "short", year: "numeric" }) },
    ]);
    setNewName("");
    setNewComment("");
  };

  return (
    <Layout>
      {/* Header */}
      <section className="py-16 md:py-24" style={{ background: "hsl(var(--hero-bg))" }}>
        <div className="container max-w-3xl">
          <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: 0.7 }}>
            <Link to="/conteudo" className="inline-flex items-center gap-1.5 text-primary-foreground/70 hover:text-primary-foreground text-sm mb-6 transition-colors">
              <ArrowLeft className="h-4 w-4" /> Voltar ao conteúdo
            </Link>
            <h1 className="text-2xl md:text-4xl font-bold text-primary-foreground mb-4 leading-tight" style={{ fontFamily: "'Montserrat', sans-serif" }}>
              {article.title}
            </h1>
            <p className="text-primary-foreground/60 text-sm">Por {article.author} · {article.source}</p>
          </motion.div>
        </div>
      </section>

      <WaveDivider fillColor="hsl(var(--background))" />

      {/* Content */}
      <article className="py-12 md:py-16 bg-background">
        <div className="container max-w-3xl">
          <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} transition={{ duration: 0.5, delay: 0.3 }}>
            <div className="prose-custom">
              {article.fullText.split("\n").map((line, i) => {
                const trimmed = line.trim();
                if (!trimmed) return <div key={i} className="h-4" />;
                if (trimmed.startsWith("## "))
                  return <h2 key={i} className="text-xl md:text-2xl font-bold text-foreground mt-10 mb-4">{trimmed.slice(3)}</h2>;
                if (trimmed.startsWith("### "))
                  return <h3 key={i} className="text-lg font-semibold text-foreground mt-6 mb-3">{trimmed.slice(4)}</h3>;
                if (trimmed.startsWith("- **"))
                  return <li key={i} className="text-foreground/80 leading-relaxed ml-4 mb-1 list-disc" dangerouslySetInnerHTML={{ __html: trimmed.slice(2).replace(/\*\*(.*?)\*\*/g, '<strong class="text-foreground">$1</strong>') }} />;
                if (trimmed.startsWith("- "))
                  return <li key={i} className="text-foreground/80 leading-relaxed ml-4 mb-1 list-disc">{trimmed.slice(2)}</li>;
                if (trimmed.startsWith("---"))
                  return <hr key={i} className="border-border my-8" />;
                return <p key={i} className="text-foreground/80 leading-relaxed mb-3" dangerouslySetInnerHTML={{ __html: trimmed.replace(/\*\*(.*?)\*\*/g, '<strong class="text-foreground">$1</strong>') }} />;
              })}
            </div>

            <div className="mt-10 pt-8 border-t border-border">
              <a href={article.externalUrl} target="_blank" rel="noopener noreferrer" className="inline-flex items-center gap-2 text-primary hover:underline font-medium">
                <ExternalLink className="h-4 w-4" /> Ler artigo original
              </a>
            </div>
          </motion.div>

          {/* Comments */}
          <motion.div initial={{ opacity: 0, y: 20 }} whileInView={{ opacity: 1, y: 0 }} viewport={{ once: true }} transition={{ duration: 0.6 }} className="mt-16 pt-10 border-t border-border">
            <div className="flex items-center gap-2 mb-8">
              <MessageSquare className="h-5 w-5 text-primary" />
              <h2 className="text-xl font-bold text-foreground">Comentários ({comments.length})</h2>
            </div>

            {comments.length > 0 && (
              <div className="space-y-6 mb-10">
                {comments.map((c) => (
                  <div key={c.id} className="bg-muted/30 border border-border rounded-lg p-5">
                    <div className="flex items-center justify-between mb-2">
                      <span className="font-medium text-foreground text-sm">{c.name}</span>
                      <span className="text-xs text-muted-foreground">{c.date}</span>
                    </div>
                    <p className="text-foreground/80 text-sm leading-relaxed">{c.text}</p>
                  </div>
                ))}
              </div>
            )}

            <form onSubmit={handleSubmit} className="bg-card border border-border rounded-xl p-6">
              <h3 className="text-sm font-semibold text-foreground mb-4">Deixe seu comentário</h3>
              <Input value={newName} onChange={(e) => setNewName(e.target.value)} placeholder="Seu nome" className="mb-3" required />
              <Textarea value={newComment} onChange={(e) => setNewComment(e.target.value)} placeholder="Escreva seu comentário..." rows={4} className="mb-4 resize-none" required />
              <Button type="submit" size="sm" className="gap-2">
                <Send className="h-3.5 w-3.5" /> Enviar comentário
              </Button>
            </form>
          </motion.div>
        </div>
      </article>
    </Layout>
  );
};

export default OpinionArticlePage;
