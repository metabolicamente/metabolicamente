import { Navigate } from "react-router-dom";
import { useAuth } from "@/hooks/useAuth";
import MedicoDashboard from "./dashboard/MedicoDashboard";
import NutriDashboard from "./dashboard/NutriDashboard";
import ClienteDashboard from "./dashboard/ClienteDashboard";

const PainelPage = () => {
  const { session, role, loading } = useAuth();
  // Fallback to legacy demo mode (no Supabase login)
  const legacyRole = typeof window !== "undefined" ? localStorage.getItem("mm_role") : null;

  if (loading) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-background">
        <div className="h-8 w-8 border-2 border-primary/30 border-t-primary rounded-full animate-spin" />
      </div>
    );
  }

  if (!session && !legacyRole) return <Navigate to="/login" replace />;

  const effectiveRole = role ?? (legacyRole as "medico" | "nutri" | "cliente" | null);

  switch (effectiveRole) {
    case "medico":
      return <MedicoDashboard />;
    case "nutri":
      return <NutriDashboard />;
    case "cliente":
    default:
      return <ClienteDashboard />;
  }
};

export default PainelPage;
