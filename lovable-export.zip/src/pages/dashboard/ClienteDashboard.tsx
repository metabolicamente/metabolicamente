import { useState, useMemo } from "react";
import { motion, AnimatePresence } from "framer-motion";
import {
  Home, Utensils, FileText, Users, Calendar, Activity,
  MessageCircle, Video, CheckCircle2, Circle, Sparkles,
  Stethoscope, Apple, Sun, Moon, Coffee, ClipboardList, UserCircle,
} from "lucide-react";
import { Button } from "@/components/ui/button";
import DashboardShell, { DashboardSection } from "@/components/dashboard/DashboardShell";
import SectionHeader from "@/components/dashboard/SectionHeader";
import ChatPanel from "@/components/dashboard/ChatPanel";
import VideoCall from "@/components/dashboard/VideoCall";
import TriagemSection from "@/components/dashboard/TriagemSection";
import PerfilSection from "@/components/dashboard/PerfilSection";
import EvolutionCharts from "@/components/dashboard/EvolutionCharts";
import AIChat from "@/components/dashboard/AIChat";

import doctor1 from "@/assets/doctor-1.jpg";
import doctor2 from "@/assets/doctor-2.jpg";

const team = [
  { name: "Dr. Rafael Mendes", role: "Psiquiatra Metabólico", img: doctor1, icon: Stethoscope, video: true },
  { name: "Dra. Camila Torres", role: "Nutricionista Funcional", img: doctor2, icon: Apple, video: false },
];

const exams = [
  { label: "Glicemia de jejum", value: "112 mg/dL", status: "Elevado" },
  { label: "HbA1c", value: "5.8%", status: "Alerta" },
  { label: "Vitamina D", value: "18 ng/mL", status: "Baixo" },
  { label: "Colesterol LDL", value: "145 mg/dL", status: "Elevado" },
];

const mealPlan = [
  { time: "Café da manhã", icon: Coffee, items: ["Ovos mexidos com abacate", "Chá verde", "1 fruta vermelha"] },
  { time: "Almoço", icon: Sun, items: ["Salmão grelhado", "Quinoa com legumes", "Salada verde com azeite"] },
  { time: "Jantar", icon: Moon, items: ["Sopa de abóbora", "Frango assado", "Brócolis no vapor"] },
];

const missions = [
  { id: 1, label: "Beber 2L de água", done: true },
  { id: 2, label: "Caminhada de 30 min ao sol", done: true },
  { id: 3, label: "Registrar humor antes de dormir", done: false },
  { id: 4, label: "Sem ultraprocessados hoje", done: false },
];



const notifications = [
  { id: 1, title: "Nova mensagem", description: "Dr. Rafael Mendes respondeu seu chat", time: "há 5 min", unread: true },
  { id: 2, title: "Teleconsulta amanhã", description: "Lembrete: 18/03 às 10:00", time: "há 2h", unread: true },
  { id: 3, title: "Plano alimentar atualizado", description: "Dra. Camila enviou novas receitas", time: "ontem" },
];

const ClienteDashboard = () => {
  const [section, setSection] = useState("inicio");
  const [chatContact, setChatContact] = useState<string | null>(null);
  const [videoOpen, setVideoOpen] = useState(false);
  const [aiOpen, setAiOpen] = useState(false);
  const [missionState, setMissionState] = useState(missions);

  const userName = localStorage.getItem("mm_user") || "João Silva";
  const firstName = userName.split(" ")[0];

  const sections: DashboardSection[] = [
    { id: "inicio", label: "Início", icon: Home },
    { id: "checkin", label: "Check-in", icon: ClipboardList },
    { id: "plano", label: "Plano", icon: Utensils },
    { id: "exames", label: "Exames", icon: FileText },
    { id: "agenda", label: "Agenda", icon: Calendar },
    { id: "equipe", label: "Equipe", icon: Users },
    { id: "perfil", label: "Perfil", icon: UserCircle },
  ];

  const completedMissions = useMemo(() => missionState.filter(m => m.done).length, [missionState]);

  const toggleMission = (id: number) => {
    setMissionState(prev => prev.map(m => m.id === id ? { ...m, done: !m.done } : m));
  };

  const renderInicio = () => (
    <>
      <SectionHeader title={`Olá, ${firstName} 👋`} subtitle="Seu espaço de acompanhamento metabólico" />

      {/* Hero card */}
      <div className="bg-gradient-to-br from-primary to-primary/80 text-primary-foreground rounded-2xl p-6 mb-5 relative overflow-hidden">
        <div className="absolute -right-10 -top-10 w-40 h-40 rounded-full bg-primary-foreground/5" />
        <div className="absolute -right-20 top-20 w-32 h-32 rounded-full bg-primary-foreground/5" />
        <div className="relative">
          <p className="text-xs uppercase tracking-wider opacity-80 mb-2">Sua jornada hoje</p>
          <p className="text-2xl font-bold mb-1" style={{ fontFamily: "'Montserrat', sans-serif" }}>
            {completedMissions} de {missionState.length} missões
          </p>
          <p className="text-sm opacity-90">
            {completedMissions === missionState.length
              ? "Dia completo! Excelente."
              : "Continue, você está indo bem."}
          </p>
          <div className="mt-4 h-2 rounded-full bg-primary-foreground/20 overflow-hidden">
            <motion.div
              className="h-full bg-secondary rounded-full"
              initial={{ width: 0 }}
              animate={{ width: `${(completedMissions / missionState.length) * 100}%` }}
              transition={{ duration: 0.8 }}
            />
          </div>
        </div>
      </div>

      {/* Próxima teleconsulta */}
      <div className="bg-card border border-border rounded-2xl p-5 mb-5 flex flex-col sm:flex-row items-center gap-4">
        <div className="h-12 w-12 rounded-full bg-primary/10 flex items-center justify-center shrink-0">
          <Calendar className="h-5 w-5 text-primary" />
        </div>
        <div className="flex-1 text-center sm:text-left">
          <p className="font-semibold text-foreground text-sm">Próxima teleconsulta</p>
          <p className="text-xs text-muted-foreground">Dr. Rafael Mendes · 18/03/2026 às 10:00</p>
        </div>
        <Button onClick={() => setVideoOpen(true)} size="sm" className="rounded-xl gap-2 bg-primary text-primary-foreground">
          <Video className="h-4 w-4" /> Acessar
        </Button>
      </div>

      {/* Missões diárias */}
      <h2 className="text-lg font-semibold text-foreground mb-3 flex items-center gap-2">
        <Sparkles className="h-4 w-4 text-secondary" /> Missões de hoje
      </h2>
      <div className="bg-card border border-border rounded-2xl p-2 mb-5">
        {missionState.map((m) => (
          <button
            key={m.id}
            onClick={() => toggleMission(m.id)}
            className="w-full flex items-center gap-3 p-3 rounded-xl hover:bg-muted/50 transition-colors text-left"
          >
            {m.done ? (
              <CheckCircle2 className="h-5 w-5 text-secondary shrink-0" />
            ) : (
              <Circle className="h-5 w-5 text-muted-foreground shrink-0" />
            )}
            <span className={`text-sm flex-1 ${m.done ? "line-through text-muted-foreground" : "text-foreground"}`}>
              {m.label}
            </span>
          </button>
        ))}
      </div>

      {/* Evolução com Recharts */}
      <h2 className="text-lg font-semibold text-foreground mb-3 flex items-center gap-2">
        <Activity className="h-4 w-4 text-primary" /> Sua evolução
      </h2>
      <EvolutionCharts />
    </>
  );

  const renderPlano = () => (
    <>
      <SectionHeader title="Plano alimentar" subtitle="Cardápio sugerido para hoje, 17/03/2026" />
      <div className="space-y-4">
        {mealPlan.map((meal) => {
          const Icon = meal.icon;
          return (
            <div key={meal.time} className="bg-card border border-border rounded-2xl p-5">
              <div className="flex items-center gap-3 mb-3">
                <div className="h-10 w-10 rounded-full bg-secondary/10 flex items-center justify-center">
                  <Icon className="h-4 w-4 text-secondary" />
                </div>
                <p className="font-semibold text-foreground">{meal.time}</p>
              </div>
              <ul className="space-y-2 ml-13">
                {meal.items.map((item) => (
                  <li key={item} className="flex items-start gap-2 text-sm text-foreground/80">
                    <span className="h-1.5 w-1.5 rounded-full bg-primary mt-2 shrink-0" />
                    {item}
                  </li>
                ))}
              </ul>
            </div>
          );
        })}
      </div>
    </>
  );

  const renderExames = () => (
    <>
      <SectionHeader title="Meus exames" subtitle="Última coleta: 05/03/2026" />
      <div className="bg-card border border-border rounded-2xl p-5">
        <div className="grid grid-cols-2 gap-3">
          {exams.map((exam) => (
            <div key={exam.label} className="p-3 rounded-xl bg-muted/50 border border-border">
              <p className="text-[11px] text-muted-foreground">{exam.label}</p>
              <p className="text-sm font-semibold text-foreground mt-0.5">{exam.value}</p>
              <span className={`text-[10px] font-medium mt-1 inline-block ${
                exam.status === "Baixo" || exam.status === "Elevado" ? "text-destructive" : "text-amber-600"
              }`}>
                {exam.status}
              </span>
            </div>
          ))}
        </div>
      </div>
    </>
  );

  const renderAgenda = () => (
    <>
      <SectionHeader title="Minha agenda" subtitle="Próximos compromissos" />
      <div className="space-y-3">
        {[
          { date: "18/03", time: "10:00", who: "Dr. Rafael Mendes", type: "Teleconsulta", action: () => setVideoOpen(true) },
          { date: "25/03", time: "14:30", who: "Dra. Camila Torres", type: "Nutrição (presencial)" },
          { date: "02/04", time: "09:00", who: "Dr. Rafael Mendes", type: "Retorno" },
        ].map((apt, i) => (
          <div key={i} className="bg-card border border-border rounded-2xl p-4 flex items-center gap-4">
            <div className="text-center shrink-0 px-3 py-2 rounded-xl bg-primary/5">
              <p className="text-[10px] uppercase text-muted-foreground">Data</p>
              <p className="text-sm font-bold text-primary">{apt.date}</p>
              <p className="text-[10px] text-muted-foreground">{apt.time}</p>
            </div>
            <div className="flex-1 min-w-0">
              <p className="font-semibold text-sm text-foreground truncate">{apt.who}</p>
              <p className="text-xs text-muted-foreground">{apt.type}</p>
            </div>
            {apt.action && (
              <Button onClick={apt.action} size="sm" variant="outline" className="rounded-xl gap-1 text-xs">
                <Video className="h-3.5 w-3.5" /> Entrar
              </Button>
            )}
          </div>
        ))}
      </div>
    </>
  );

  const renderEquipe = () => (
    <>
      <SectionHeader title="Minha equipe" subtitle="Profissionais que cuidam de você" />
      <div className="grid sm:grid-cols-2 gap-4">
        {team.map((member) => (
          <div key={member.name} className="bg-card border border-border rounded-2xl p-5 flex flex-col items-center text-center">
            <img src={member.img} alt={member.name} className="h-20 w-20 rounded-full object-cover mb-3 border-2 border-primary/20" />
            <p className="font-semibold text-foreground text-sm">{member.name}</p>
            <p className="text-xs text-muted-foreground mb-4">{member.role}</p>
            <div className="flex gap-2 w-full">
              <Button onClick={() => setChatContact(member.name)} variant="outline" size="sm" className="flex-1 rounded-xl gap-1 text-xs">
                <MessageCircle className="h-3.5 w-3.5" /> Chat
              </Button>
              {member.video && (
                <Button onClick={() => setVideoOpen(true)} size="sm" className="flex-1 rounded-xl gap-1 text-xs bg-primary text-primary-foreground">
                  <Video className="h-3.5 w-3.5" /> Vídeo
                </Button>
              )}
            </div>
          </div>
        ))}
      </div>
    </>
  );

  return (
    <DashboardShell
      userName={userName}
      role="cliente"
      sections={sections}
      currentSection={section}
      onSectionChange={setSection}
      notifications={notifications}
    >
      {section === "inicio" && renderInicio()}
      {section === "checkin" && <TriagemSection />}
      {section === "plano" && renderPlano()}
      {section === "exames" && renderExames()}
      {section === "agenda" && renderAgenda()}
      {section === "equipe" && renderEquipe()}
      {section === "perfil" && <PerfilSection defaultName={userName} />}

      <AnimatePresence>
        {chatContact && <ChatPanel contactName={chatContact} onClose={() => setChatContact(null)} />}
        {videoOpen && <VideoCall contactName="Dr. Rafael Mendes" onClose={() => setVideoOpen(false)} />}
        {aiOpen && <AIChat role="cliente" title="Assistente do paciente" subtitle="Tire dúvidas sobre seu tratamento" onClose={() => setAiOpen(false)} />}
      </AnimatePresence>

      {/* Floating AI button */}
      {!aiOpen && (
        <button
          onClick={() => setAiOpen(true)}
          className="fixed bottom-20 lg:bottom-6 right-4 z-30 h-14 w-14 rounded-full bg-secondary text-secondary-foreground shadow-2xl flex items-center justify-center hover:scale-110 transition-transform"
          aria-label="Abrir assistente IA"
        >
          <Sparkles className="h-5 w-5" />
        </button>
      )}
    </DashboardShell>
  );
};

export default ClienteDashboard;
