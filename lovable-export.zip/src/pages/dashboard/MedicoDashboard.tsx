import { useState } from "react";
import { motion, AnimatePresence } from "framer-motion";
import {
  Home, Users, Calendar, ClipboardList, Activity,
  MessageCircle, Video, ChevronRight, ArrowLeft,
  AlertTriangle, Zap, Clock, Search, UserCircle,
} from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import DashboardShell, { DashboardSection } from "@/components/dashboard/DashboardShell";
import SectionHeader from "@/components/dashboard/SectionHeader";
import EmptyState from "@/components/dashboard/EmptyState";
import ChatPanel from "@/components/dashboard/ChatPanel";
import VideoCall from "@/components/dashboard/VideoCall";
import ProntuariosSection from "@/components/dashboard/ProntuariosSection";
import PerfilSection from "@/components/dashboard/PerfilSection";
import AIChat from "@/components/dashboard/AIChat";
import { Sparkles } from "lucide-react";

const patients = [
  {
    id: 1, name: "João Silva", age: 34, energy: 4, risk: "baixo",
    history: "Diabetes tipo 2, ansiedade",
    triage: {
      queixa: "Dificuldade de concentração e fadiga persistente",
      duracao: "6 meses a 2 anos",
      psiquiatra: true, terapia: false, medicacao: true,
      saude: "Diabetes tipo 2, hipertensão leve",
      alimentar: "Tentou low-carb por 3 meses",
      energia: 4, sentimento: "Cansado mas esperançoso", horario: "Manhã",
    },
  },
  {
    id: 2, name: "Maria Oliveira", age: 28, energy: 7, risk: "baixo",
    history: "Resistência à insulina",
    triage: {
      queixa: "Ganho de peso progressivo e humor instável",
      duracao: "Mais de 2 anos",
      psiquiatra: false, terapia: true, medicacao: false,
      saude: "Resistência à insulina, SOP",
      alimentar: "Dieta mediterrânea",
      energia: 7, sentimento: "Motivada para mudanças", horario: "Tarde",
    },
  },
  {
    id: 3, name: "Carlos Mendes", age: 45, energy: 3, risk: "moderado",
    history: "Depressão, síndrome metabólica",
    triage: {
      queixa: "Insônia crônica e perda de interesse geral",
      duracao: "Mais de 2 anos",
      psiquiatra: true, terapia: true, medicacao: true,
      saude: "Síndrome metabólica, colesterol alto",
      alimentar: "Nenhuma tentativa anterior",
      energia: 3, sentimento: "Desesperançoso em alguns momentos", horario: "Noite",
    },
  },
];

const agenda = [
  { date: "17/03", time: "09:00", patient: "João Silva", type: "Teleconsulta", status: "hoje" },
  { date: "17/03", time: "11:30", patient: "Maria Oliveira", type: "Retorno", status: "hoje" },
  { date: "18/03", time: "10:00", patient: "Carlos Mendes", type: "Teleconsulta", status: "amanha" },
  { date: "20/03", time: "15:00", patient: "Maria Oliveira", type: "Avaliação", status: "futuro" },
];

const notifications = [
  { id: 1, title: "Nova mensagem", description: "João Silva enviou uma mensagem no chat", time: "há 10 min", unread: true },
  { id: 2, title: "Triagem nova", description: "Carlos Mendes completou a triagem", time: "há 1h", unread: true },
  { id: 3, title: "Resultado de exame", description: "Maria Oliveira anexou novos exames", time: "há 3h", unread: true },
];

const MedicoDashboard = () => {
  const [section, setSection] = useState("inicio");
  const [selectedPatient, setSelectedPatient] = useState<typeof patients[0] | null>(null);
  const [chatOpen, setChatOpen] = useState(false);
  const [videoOpen, setVideoOpen] = useState(false);
  const [aiOpen, setAiOpen] = useState(false);
  const [search, setSearch] = useState("");

  const userName = localStorage.getItem("mm_user") || "Dr. Rafael Mendes";
  const firstName = userName.split(" ").slice(-1)[0];

  const sections: DashboardSection[] = [
    { id: "inicio", label: "Início", icon: Home },
    { id: "pacientes", label: "Pacientes", icon: Users, badge: 1 },
    { id: "agenda", label: "Agenda", icon: Calendar },
    { id: "prontuarios", label: "Prontuários", icon: ClipboardList },
    { id: "perfil", label: "Perfil", icon: UserCircle },
  ];

  const filtered = patients.filter(p => p.name.toLowerCase().includes(search.toLowerCase()));

  const renderInicio = () => (
    <>
      <SectionHeader title={`Bem-vindo, Dr. ${firstName}`} subtitle="Resumo da semana" />

      <div className="grid sm:grid-cols-3 gap-3 mb-6">
        {[
          { label: "Pacientes ativos", value: patients.length, icon: Users, color: "text-primary bg-primary/10" },
          { label: "Consultas hoje", value: 2, icon: Calendar, color: "text-secondary bg-secondary/10" },
          { label: "Pacientes em risco", value: 1, icon: AlertTriangle, color: "text-destructive bg-destructive/10" },
        ].map((stat) => {
          const Icon = stat.icon;
          return (
            <div key={stat.label} className="bg-card border border-border rounded-2xl p-5">
              <div className={`h-10 w-10 rounded-full ${stat.color} flex items-center justify-center mb-3`}>
                <Icon className="h-4 w-4" />
              </div>
              <p className="text-2xl font-bold text-foreground" style={{ fontFamily: "'Montserrat', sans-serif" }}>
                {stat.value}
              </p>
              <p className="text-xs text-muted-foreground">{stat.label}</p>
            </div>
          );
        })}
      </div>

      <h2 className="text-lg font-semibold text-foreground mb-3 flex items-center gap-2">
        <Clock className="h-4 w-4 text-primary" /> Próximos atendimentos
      </h2>
      <div className="space-y-2 mb-6">
        {agenda.filter(a => a.status === "hoje").map((apt, i) => (
          <div key={i} className="bg-card border border-border rounded-2xl p-4 flex items-center gap-4">
            <div className="text-center shrink-0 px-3 py-2 rounded-xl bg-primary/5">
              <p className="text-sm font-bold text-primary">{apt.time}</p>
            </div>
            <div className="flex-1 min-w-0">
              <p className="font-semibold text-sm text-foreground truncate">{apt.patient}</p>
              <p className="text-xs text-muted-foreground">{apt.type}</p>
            </div>
            <Button onClick={() => setVideoOpen(true)} size="sm" className="rounded-xl gap-1 text-xs bg-primary text-primary-foreground">
              <Video className="h-3.5 w-3.5" /> Iniciar
            </Button>
          </div>
        ))}
      </div>

      <h2 className="text-lg font-semibold text-foreground mb-3 flex items-center gap-2">
        <AlertTriangle className="h-4 w-4 text-destructive" /> Alertas clínicos
      </h2>
      <div className="bg-destructive/5 border border-destructive/20 rounded-2xl p-4">
        <p className="text-sm font-semibold text-foreground">Carlos Mendes — risco moderado</p>
        <p className="text-xs text-muted-foreground mt-1">
          Energia em queda nos últimos 7 dias. Considere agendar retorno.
        </p>
      </div>
    </>
  );

  const renderPacientes = () => {
    if (selectedPatient) {
      return (
        <motion.div initial={{ opacity: 0, x: 20 }} animate={{ opacity: 1, x: 0 }}>
          <button onClick={() => setSelectedPatient(null)} className="flex items-center gap-1 text-sm text-muted-foreground hover:text-foreground mb-4 transition-colors">
            <ArrowLeft className="h-4 w-4" /> Voltar
          </button>

          <div className="flex flex-col md:flex-row md:items-start md:justify-between gap-4 mb-6">
            <div>
              <h1 className="text-2xl font-bold text-foreground" style={{ fontFamily: "'Montserrat', sans-serif" }}>
                {selectedPatient.name}
              </h1>
              <p className="text-sm text-muted-foreground">{selectedPatient.age} anos · {selectedPatient.history}</p>
            </div>
            <div className="flex gap-2">
              <Button onClick={() => setChatOpen(true)} variant="outline" size="sm" className="rounded-xl gap-2">
                <MessageCircle className="h-4 w-4" /> Chat
              </Button>
              <Button onClick={() => setVideoOpen(true)} size="sm" className="rounded-xl gap-2 bg-primary text-primary-foreground">
                <Video className="h-4 w-4" /> Videochamada
              </Button>
            </div>
          </div>

          <div className="bg-card border border-border rounded-2xl p-6 space-y-5">
            <h2 className="font-semibold text-foreground flex items-center gap-2">
              <ClipboardList className="h-4 w-4 text-primary" /> Resumo da Triagem
            </h2>

            <div className="grid md:grid-cols-2 gap-4">
              {[
                { label: "Queixa principal", value: selectedPatient.triage.queixa },
                { label: "Duração", value: selectedPatient.triage.duracao },
                { label: "Quadro de saúde", value: selectedPatient.triage.saude },
                { label: "Estratégia alimentar", value: selectedPatient.triage.alimentar },
                { label: "Como se sente", value: selectedPatient.triage.sentimento },
                { label: "Horário preferido", value: selectedPatient.triage.horario },
              ].map((item) => (
                <div key={item.label} className="space-y-1">
                  <p className="text-xs font-medium text-muted-foreground uppercase tracking-wide">{item.label}</p>
                  <p className="text-sm text-foreground">{item.value}</p>
                </div>
              ))}
            </div>

            <div className="grid grid-cols-3 gap-3 pt-3 border-t border-border">
              {[
                { label: "Psiquiatra", value: selectedPatient.triage.psiquiatra },
                { label: "Terapia", value: selectedPatient.triage.terapia },
                { label: "Medicação", value: selectedPatient.triage.medicacao },
              ].map((item) => (
                <div key={item.label} className="text-center p-3 rounded-xl bg-muted/50">
                  <p className="text-xs text-muted-foreground">{item.label}</p>
                  <p className={`text-sm font-semibold mt-1 ${item.value ? "text-secondary" : "text-muted-foreground"}`}>
                    {item.value ? "Sim" : "Não"}
                  </p>
                </div>
              ))}
            </div>

            <div className="pt-3 border-t border-border">
              <p className="text-xs text-muted-foreground mb-2">Energia diária</p>
              <div className="flex items-center gap-3">
                <div className="flex-1 h-2.5 rounded-full bg-muted overflow-hidden">
                  <motion.div
                    initial={{ width: 0 }}
                    animate={{ width: `${selectedPatient.triage.energia * 10}%` }}
                    transition={{ duration: 0.6 }}
                    className="h-full rounded-full bg-primary"
                  />
                </div>
                <span className="text-sm font-semibold text-foreground">{selectedPatient.triage.energia}/10</span>
              </div>
            </div>
          </div>

          <div className="bg-card border border-border rounded-2xl p-6 mt-4">
            <h2 className="font-semibold text-foreground flex items-center gap-2 mb-4">
              <Activity className="h-4 w-4 text-primary" /> Histórico Clínico
            </h2>
            <div className="space-y-3">
              {[
                { date: "10/03/2026", note: "Consulta inicial — triagem realizada" },
                { date: "15/02/2026", note: "Exames laboratoriais solicitados" },
                { date: "20/01/2026", note: "Primeiro contato via formulário" },
              ].map((entry) => (
                <div key={entry.date} className="flex gap-3 items-start">
                  <div className="h-2 w-2 rounded-full bg-primary mt-1.5 shrink-0" />
                  <div>
                    <p className="text-xs text-muted-foreground">{entry.date}</p>
                    <p className="text-sm text-foreground">{entry.note}</p>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </motion.div>
      );
    }

    return (
      <>
        <SectionHeader title="Meus pacientes" subtitle="Resumo da triagem e acompanhamento" />

        <div className="relative mb-4">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
          <Input
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            placeholder="Buscar paciente..."
            className="pl-10 h-11 rounded-xl bg-card border-border"
          />
        </div>

        {filtered.length === 0 ? (
          <EmptyState icon={Users} title="Nenhum paciente encontrado" description="Tente outra busca." />
        ) : (
          <div className="grid gap-3">
            {filtered.map((p) => (
              <motion.button
                key={p.id}
                onClick={() => setSelectedPatient(p)}
                className="w-full text-left bg-card border border-border rounded-2xl p-5 hover:shadow-md hover:border-primary/30 transition-all group"
                whileHover={{ y: -2 }}
              >
                <div className="flex items-start justify-between">
                  <div className="flex-1">
                    <div className="flex items-center gap-3 mb-2">
                      <div className="h-10 w-10 rounded-full bg-primary/10 flex items-center justify-center">
                        <span className="text-sm font-bold text-primary">{p.name.charAt(0)}</span>
                      </div>
                      <div>
                        <p className="font-semibold text-foreground">{p.name}</p>
                        <p className="text-xs text-muted-foreground">{p.age} anos · {p.history}</p>
                      </div>
                    </div>
                    <div className="flex flex-wrap gap-2 mt-3">
                      <span className="inline-flex items-center gap-1 text-xs px-2.5 py-1 rounded-full bg-muted text-muted-foreground">
                        <Zap className="h-3 w-3" /> Energia: {p.energy}/10
                      </span>
                      <span className={`inline-flex items-center gap-1 text-xs px-2.5 py-1 rounded-full ${
                        p.risk === "moderado" ? "bg-destructive/10 text-destructive" : "bg-secondary/10 text-secondary"
                      }`}>
                        <AlertTriangle className="h-3 w-3" /> Risco: {p.risk}
                      </span>
                    </div>
                  </div>
                  <ChevronRight className="h-5 w-5 text-muted-foreground group-hover:text-primary transition-colors mt-2" />
                </div>
              </motion.button>
            ))}
          </div>
        )}
      </>
    );
  };

  const renderAgenda = () => (
    <>
      <SectionHeader title="Agenda" subtitle="Seus próximos atendimentos" />
      <div className="space-y-3">
        {agenda.map((apt, i) => (
          <div key={i} className="bg-card border border-border rounded-2xl p-4 flex items-center gap-4">
            <div className="text-center shrink-0 px-3 py-2 rounded-xl bg-primary/5">
              <p className="text-[10px] uppercase text-muted-foreground">Data</p>
              <p className="text-sm font-bold text-primary">{apt.date}</p>
              <p className="text-[10px] text-muted-foreground">{apt.time}</p>
            </div>
            <div className="flex-1 min-w-0">
              <p className="font-semibold text-sm text-foreground truncate">{apt.patient}</p>
              <p className="text-xs text-muted-foreground">{apt.type}</p>
            </div>
            {apt.status === "hoje" && (
              <Button onClick={() => setVideoOpen(true)} size="sm" className="rounded-xl gap-1 text-xs bg-primary text-primary-foreground">
                <Video className="h-3.5 w-3.5" /> Iniciar
              </Button>
            )}
          </div>
        ))}
      </div>
    </>
  );

  // prontuarios handled by ProntuariosSection component

  return (
    <DashboardShell
      userName={userName}
      role="medico"
      sections={sections}
      currentSection={section}
      onSectionChange={(id) => { setSection(id); setSelectedPatient(null); }}
      notifications={notifications}
    >
      {section === "inicio" && renderInicio()}
      {section === "pacientes" && renderPacientes()}
      {section === "agenda" && renderAgenda()}
      {section === "prontuarios" && <ProntuariosSection patients={patients.map(p => ({ id: p.id, name: p.name }))} />}
      {section === "perfil" && <PerfilSection defaultName={userName} defaultEmail="medico@metabolicamente.com" />}

      <AnimatePresence>
        {chatOpen && <ChatPanel contactName={selectedPatient?.name || ""} onClose={() => setChatOpen(false)} />}
        {videoOpen && <VideoCall contactName={selectedPatient?.name || "Paciente"} onClose={() => setVideoOpen(false)} />}
        {aiOpen && (
          <AIChat
            role="medico"
            title="Assistente clínico"
            subtitle={selectedPatient ? `Caso: ${selectedPatient.name}` : "Raciocínio clínico"}
            context={selectedPatient ? `Paciente ${selectedPatient.name}, ${selectedPatient.age} anos. Histórico: ${selectedPatient.history}. Queixa principal: ${selectedPatient.triage.queixa}. Energia: ${selectedPatient.triage.energia}/10.` : undefined}
            onClose={() => setAiOpen(false)}
          />
        )}
      </AnimatePresence>

      {!aiOpen && (
        <button
          onClick={() => setAiOpen(true)}
          className="fixed bottom-20 lg:bottom-6 right-4 z-30 h-14 w-14 rounded-full bg-secondary text-secondary-foreground shadow-2xl flex items-center justify-center hover:scale-110 transition-transform"
          aria-label="Abrir assistente clínico IA"
        >
          <Sparkles className="h-5 w-5" />
        </button>
      )}
    </DashboardShell>
  );
};

export default MedicoDashboard;
