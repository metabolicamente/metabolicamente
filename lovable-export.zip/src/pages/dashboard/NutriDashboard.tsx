import { useState } from "react";
import { motion, AnimatePresence } from "framer-motion";
import {
  Home, Users, Utensils, FileText, Sparkles,
  MessageCircle, ChevronRight, ArrowLeft, Search, Apple, Calendar, UserCircle,
} from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import DashboardShell, { DashboardSection } from "@/components/dashboard/DashboardShell";
import SectionHeader from "@/components/dashboard/SectionHeader";
import EmptyState from "@/components/dashboard/EmptyState";
import ChatPanel from "@/components/dashboard/ChatPanel";
import AIChat from "@/components/dashboard/AIChat";
import CardapioGenerator from "@/components/dashboard/CardapioGenerator";
import PerfilSection from "@/components/dashboard/PerfilSection";

const patients = [
  {
    id: 1, name: "João Silva", age: 34,
    goal: "Adequação metabólica e controle glicêmico",
    exams: [
      { label: "Glicemia de jejum", value: "112 mg/dL", status: "alto" },
      { label: "HbA1c", value: "5.8%", status: "alerta" },
      { label: "Vitamina D", value: "18 ng/mL", status: "baixo" },
      { label: "Colesterol LDL", value: "145 mg/dL", status: "alto" },
      { label: "Triglicerídeos", value: "180 mg/dL", status: "alto" },
      { label: "TSH", value: "2.3 mUI/L", status: "normal" },
    ],
  },
  {
    id: 2, name: "Maria Oliveira", age: 28,
    goal: "Equilíbrio hormonal e composição corporal",
    exams: [
      { label: "Insulina basal", value: "18 µU/mL", status: "alto" },
      { label: "HOMA-IR", value: "4.5", status: "alto" },
      { label: "Ferro sérico", value: "45 µg/dL", status: "baixo" },
      { label: "B12", value: "320 pg/mL", status: "normal" },
      { label: "Cortisol matinal", value: "22 µg/dL", status: "alto" },
      { label: "PCR", value: "3.2 mg/L", status: "alerta" },
    ],
  },
  {
    id: 3, name: "Carlos Mendes", age: 45,
    goal: "Manejo da síndrome metabólica",
    exams: [
      { label: "Glicemia", value: "126 mg/dL", status: "alto" },
      { label: "HbA1c", value: "6.4%", status: "alto" },
      { label: "Colesterol total", value: "240 mg/dL", status: "alto" },
      { label: "HDL", value: "35 mg/dL", status: "baixo" },
      { label: "Ácido úrico", value: "7.8 mg/dL", status: "alto" },
      { label: "GGT", value: "65 U/L", status: "alerta" },
    ],
  },
];

const statusColors: Record<string, string> = {
  normal: "text-secondary bg-secondary/10",
  alerta: "text-amber-600 bg-amber-50",
  alto: "text-destructive bg-destructive/10",
  baixo: "text-blue-600 bg-blue-50",
};

const notifications = [
  { id: 1, title: "Novo exame", description: "João Silva enviou um PDF de hemograma", time: "há 20 min", unread: true },
  { id: 2, title: "Mensagem", description: "Maria Oliveira respondeu sobre o cardápio", time: "há 2h", unread: true },
];

const NutriDashboard = () => {
  const [section, setSection] = useState("inicio");
  const [selectedPatient, setSelectedPatient] = useState<typeof patients[0] | null>(null);
  const [chatOpen, setChatOpen] = useState(false);
  const [aiOpen, setAiOpen] = useState(false);
  const [genFor, setGenFor] = useState<typeof patients[0] | null>(null);
  const [search, setSearch] = useState("");

  const userName = localStorage.getItem("mm_user") || "Dra. Camila Torres";
  const firstName = userName.split(" ").slice(-1)[0];

  const sections: DashboardSection[] = [
    { id: "inicio", label: "Início", icon: Home },
    { id: "pacientes", label: "Pacientes", icon: Users },
    { id: "cardapios", label: "Cardápios", icon: Utensils },
    { id: "agenda", label: "Agenda", icon: Calendar },
    { id: "perfil", label: "Perfil", icon: UserCircle },
  ];

  const filtered = patients.filter(p => p.name.toLowerCase().includes(search.toLowerCase()));

  const renderInicio = () => (
    <>
      <SectionHeader title={`Olá, Dra. ${firstName}`} subtitle="Visão geral do acompanhamento nutricional" />

      <div className="grid sm:grid-cols-3 gap-3 mb-6">
        {[
          { label: "Pacientes ativos", value: patients.length, icon: Users },
          { label: "Cardápios entregues", value: 8, icon: Utensils },
          { label: "Exames pendentes", value: 2, icon: FileText },
        ].map((stat) => {
          const Icon = stat.icon;
          return (
            <div key={stat.label} className="bg-card border border-border rounded-2xl p-5">
              <div className="h-10 w-10 rounded-full bg-primary/10 flex items-center justify-center mb-3">
                <Icon className="h-4 w-4 text-primary" />
              </div>
              <p className="text-2xl font-bold text-foreground" style={{ fontFamily: "'Montserrat', sans-serif" }}>
                {stat.value}
              </p>
              <p className="text-xs text-muted-foreground">{stat.label}</p>
            </div>
          );
        })}
      </div>

      <div className="bg-gradient-to-br from-secondary/10 to-secondary/5 border border-secondary/20 rounded-2xl p-5">
        <div className="flex items-start gap-3">
          <div className="h-10 w-10 rounded-full bg-secondary/20 flex items-center justify-center shrink-0">
            <Sparkles className="h-4 w-4 text-secondary" />
          </div>
          <div>
            <p className="font-semibold text-foreground text-sm">AI Assistant</p>
            <p className="text-xs text-muted-foreground mt-1">
              Selecione um paciente para gerar análises e sugestões nutricionais com IA.
            </p>
          </div>
        </div>
      </div>
    </>
  );

  const renderPacientes = () => {
    if (selectedPatient) {
      return (
        <motion.div initial={{ opacity: 0, x: 20 }} animate={{ opacity: 1, x: 0 }}>
          <button onClick={() => setSelectedPatient(null)} className="flex items-center gap-1 text-sm text-muted-foreground hover:text-foreground mb-4 transition-colors">
            <ArrowLeft className="h-4 w-4" /> Voltar
          </button>

          <div className="flex flex-col md:flex-row md:items-start md:justify-between gap-4 mb-6">
            <div>
              <h1 className="text-2xl font-bold text-foreground" style={{ fontFamily: "'Montserrat', sans-serif" }}>
                {selectedPatient.name}
              </h1>
              <p className="text-sm text-muted-foreground">{selectedPatient.age} anos · {selectedPatient.goal}</p>
            </div>
            <div className="flex gap-2 flex-wrap">
              <Button onClick={() => setChatOpen(true)} variant="outline" size="sm" className="rounded-xl gap-2">
                <MessageCircle className="h-4 w-4" /> Chat
              </Button>
              <Button onClick={() => setAiOpen(true)} size="sm" className="rounded-xl gap-2 bg-secondary text-secondary-foreground">
                <Sparkles className="h-4 w-4" /> AI Assistant
              </Button>
            </div>
          </div>

          <div className="bg-card border border-border rounded-2xl p-6 mb-4">
            <h2 className="font-semibold text-foreground flex items-center gap-2 mb-4">
              <FileText className="h-4 w-4 text-primary" /> Exame de Sangue (PDF)
            </h2>
            <div className="bg-muted/50 rounded-xl p-4 border border-border">
              <div className="flex items-center gap-3 mb-4">
                <div className="h-10 w-10 bg-destructive/10 rounded-lg flex items-center justify-center">
                  <FileText className="h-5 w-5 text-destructive" />
                </div>
                <div>
                  <p className="text-sm font-medium text-foreground">hemograma_{selectedPatient.name.split(" ")[0].toLowerCase()}.pdf</p>
                  <p className="text-xs text-muted-foreground">Laboratório Central · 05/03/2026</p>
                </div>
              </div>

              <div className="grid grid-cols-2 md:grid-cols-3 gap-3">
                {selectedPatient.exams.map((exam) => (
                  <div key={exam.label} className="p-3 rounded-xl bg-card border border-border">
                    <p className="text-[11px] text-muted-foreground mb-1">{exam.label}</p>
                    <p className="text-sm font-semibold text-foreground">{exam.value}</p>
                    <span className={`inline-block text-[10px] px-2 py-0.5 rounded-full mt-1 font-medium ${statusColors[exam.status]}`}>
                      {exam.status}
                    </span>
                  </div>
                ))}
              </div>
            </div>
          </div>
        </motion.div>
      );
    }

    return (
      <>
        <SectionHeader title="Meus pacientes" subtitle="Acompanhamento nutricional" />

        <div className="relative mb-4">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
          <Input
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            placeholder="Buscar paciente..."
            className="pl-10 h-11 rounded-xl bg-card border-border"
          />
        </div>

        {filtered.length === 0 ? (
          <EmptyState icon={Users} title="Nenhum paciente encontrado" />
        ) : (
          <div className="grid gap-3">
            {filtered.map((p) => (
              <motion.button
                key={p.id}
                onClick={() => setSelectedPatient(p)}
                className="w-full text-left bg-card border border-border rounded-2xl p-5 hover:shadow-md hover:border-primary/30 transition-all group"
                whileHover={{ y: -2 }}
              >
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-3">
                    <div className="h-10 w-10 rounded-full bg-primary/10 flex items-center justify-center">
                      <span className="text-sm font-bold text-primary">{p.name.charAt(0)}</span>
                    </div>
                    <div>
                      <p className="font-semibold text-foreground">{p.name}</p>
                      <p className="text-xs text-muted-foreground">{p.age} anos · {p.goal}</p>
                    </div>
                  </div>
                  <ChevronRight className="h-5 w-5 text-muted-foreground group-hover:text-primary transition-colors" />
                </div>
              </motion.button>
            ))}
          </div>
        )}
      </>
    );
  };

  const renderCardapios = () => (
    <>
      <SectionHeader
        title="Cardápios"
        subtitle="Planos alimentares ativos"
        action={
          <Button
            onClick={() => setGenFor(patients[0])}
            size="sm"
            className="rounded-xl gap-2 bg-secondary text-secondary-foreground"
          >
            <Sparkles className="h-4 w-4" /> Gerar com IA
          </Button>
        }
      />
      <div className="grid sm:grid-cols-2 gap-3">
        {patients.map((p) => (
          <button
            key={p.id}
            onClick={() => setGenFor(p)}
            className="text-left bg-card border border-border rounded-2xl p-5 hover:shadow-md hover:border-secondary/40 transition-all"
          >
            <div className="flex items-center gap-3 mb-3">
              <div className="h-10 w-10 rounded-full bg-secondary/10 flex items-center justify-center">
                <Apple className="h-4 w-4 text-secondary" />
              </div>
              <div>
                <p className="font-semibold text-sm text-foreground">{p.name}</p>
                <p className="text-[11px] text-muted-foreground">Atualizado há 3 dias</p>
              </div>
            </div>
            <p className="text-xs text-muted-foreground mb-3">{p.goal}</p>
            <span className="inline-flex items-center gap-1 text-[11px] text-secondary font-medium">
              <Sparkles className="h-3 w-3" /> Gerar novo cardápio
            </span>
          </button>
        ))}
      </div>
    </>
  );

  const renderAgenda = () => (
    <>
      <SectionHeader title="Agenda" subtitle="Próximos atendimentos nutricionais" />
      <div className="space-y-3">
        {[
          { date: "17/03", time: "14:30", patient: "Maria Oliveira", type: "Retorno nutricional" },
          { date: "19/03", time: "10:00", patient: "João Silva", type: "Avaliação" },
          { date: "22/03", time: "16:00", patient: "Carlos Mendes", type: "Plano alimentar" },
        ].map((apt, i) => (
          <div key={i} className="bg-card border border-border rounded-2xl p-4 flex items-center gap-4">
            <div className="text-center shrink-0 px-3 py-2 rounded-xl bg-secondary/10">
              <p className="text-sm font-bold text-secondary">{apt.date}</p>
              <p className="text-[10px] text-muted-foreground">{apt.time}</p>
            </div>
            <div className="flex-1 min-w-0">
              <p className="font-semibold text-sm text-foreground truncate">{apt.patient}</p>
              <p className="text-xs text-muted-foreground">{apt.type}</p>
            </div>
          </div>
        ))}
      </div>
    </>
  );

  return (
    <DashboardShell
      userName={userName}
      role="nutri"
      sections={sections}
      currentSection={section}
      onSectionChange={(id) => { setSection(id); setSelectedPatient(null); setAiOpen(false); }}
      notifications={notifications}
    >
      {section === "inicio" && renderInicio()}
      {section === "pacientes" && renderPacientes()}
      {section === "cardapios" && renderCardapios()}
      {section === "agenda" && renderAgenda()}
      {section === "perfil" && <PerfilSection defaultName={userName} defaultEmail="nutri@metabolicamente.com" />}

      <AnimatePresence>
        {chatOpen && <ChatPanel contactName={selectedPatient?.name || ""} onClose={() => setChatOpen(false)} />}
        {aiOpen && selectedPatient && <AIChat role="nutri" title="Assistente nutricional" subtitle={`Análise de ${selectedPatient.name}`} context={`Paciente: ${selectedPatient.name}, ${selectedPatient.age} anos. Objetivo: ${selectedPatient.goal}. Exames: ${selectedPatient.exams.map((e: any) => `${e.label} ${e.value} (${e.status})`).join("; ")}.`} onClose={() => setAiOpen(false)} />}
        {genFor && <CardapioGenerator patientName={genFor.name} goal={genFor.goal} onClose={() => setGenFor(null)} />}
      </AnimatePresence>
    </DashboardShell>
  );
};

export default NutriDashboard;
