import Layout from "@/components/Layout";

const PlaceholderPage = ({ title }: { title: string }) => (
  <Layout>
    <div className="container py-20 text-center">
      <h1 className="font-display text-3xl font-bold text-foreground mb-4">{title}</h1>
      <p className="text-muted-foreground">Esta página está em construção.</p>
    </div>
  </Layout>
);

export default PlaceholderPage;
