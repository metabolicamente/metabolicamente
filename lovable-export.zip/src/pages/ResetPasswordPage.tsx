import { useState, useEffect } from "react";
import { Link, useNavigate } from "react-router-dom";
import { Brain, Lock } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { useToast } from "@/hooks/use-toast";
import { supabase } from "@/integrations/supabase/client";
import SEO from "@/components/SEO";

const ResetPasswordPage = () => {
  const [password, setPassword] = useState("");
  const [confirm, setConfirm] = useState("");
  const [loading, setLoading] = useState(false);
  const [hasRecoverySession, setHasRecoverySession] = useState(false);
  const navigate = useNavigate();
  const { toast } = useToast();

  useEffect(() => {
    // Supabase auto-handles the recovery session via URL hash
    const { data: sub } = supabase.auth.onAuthStateChange((event) => {
      if (event === "PASSWORD_RECOVERY") setHasRecoverySession(true);
    });
    supabase.auth.getSession().then(({ data }) => {
      if (data.session) setHasRecoverySession(true);
    });
    return () => sub.subscription.unsubscribe();
  }, []);

  const submit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (password !== confirm) {
      toast({ title: "As senhas não coincidem", variant: "destructive" });
      return;
    }
    setLoading(true);
    const { error } = await supabase.auth.updateUser({ password });
    setLoading(false);
    if (error) {
      toast({ title: "Erro ao atualizar senha", description: error.message, variant: "destructive" });
      return;
    }
    toast({ title: "Senha redefinida com sucesso" });
    navigate("/painel");
  };

  return (
    <div className="min-h-screen bg-background flex items-center justify-center p-4">
      <SEO title="Redefinir senha | Metabolicamente" description="Defina uma nova senha para acessar seu painel da Clínica Metabolicamente." />
      <div className="w-full max-w-md">
        <div className="text-center mb-8">
          <Link to="/" className="inline-flex items-center gap-2">
            <Brain className="h-8 w-8 text-primary" />
            <span className="text-2xl font-bold text-primary" style={{ fontFamily: "'Montserrat', sans-serif" }}>
              Metabolicamente
            </span>
          </Link>
          <h1 className="mt-4 text-xl font-semibold">Redefinir senha</h1>
        </div>

        <div className="bg-card border border-border rounded-2xl p-8 shadow-lg">
          {!hasRecoverySession ? (
            <p className="text-sm text-muted-foreground text-center">
              Abra o link enviado para o seu e-mail para continuar.
            </p>
          ) : (
            <form onSubmit={submit} className="space-y-4">
              <div className="space-y-2">
                <label className="text-sm font-medium">Nova senha</label>
                <div className="relative">
                  <Lock className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
                  <Input type="password" minLength={6} value={password} onChange={(e) => setPassword(e.target.value)} className="pl-10 h-12 rounded-xl" required />
                </div>
              </div>
              <div className="space-y-2">
                <label className="text-sm font-medium">Confirme a senha</label>
                <Input type="password" minLength={6} value={confirm} onChange={(e) => setConfirm(e.target.value)} className="h-12 rounded-xl" required />
              </div>
              <Button type="submit" disabled={loading} className="w-full h-12 rounded-xl bg-primary text-primary-foreground">
                {loading ? "Salvando..." : "Definir nova senha"}
              </Button>
            </form>
          )}
        </div>
      </div>
    </div>
  );
};

export default ResetPasswordPage;
