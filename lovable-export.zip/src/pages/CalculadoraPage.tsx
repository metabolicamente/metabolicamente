import { useState, useMemo } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { Link } from "react-router-dom";
import { Activity, ArrowRight, RotateCcw, ShieldCheck, AlertTriangle, AlertCircle } from "lucide-react";
import Layout from "@/components/Layout";
import StandardHero from "@/components/shared/StandardHero";
import WaveDivider from "@/components/shared/WaveDivider";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";

type Answers = {
  age: number;
  waist: number;
  sleep: string;
  energy: string;
  mood: string;
  diet: string;
  exercise: string;
  family: string;
};

const initial: Answers = {
  age: 35,
  waist: 90,
  sleep: "",
  energy: "",
  mood: "",
  diet: "",
  exercise: "",
  family: "",
};

const questions = [
  { key: "sleep" as const, label: "Como está seu sono?", options: [
    { v: "good", label: "Durmo bem, acordo descansado", score: 0 },
    { v: "ok", label: "Razoável, com alguns despertares", score: 1 },
    { v: "bad", label: "Sono fragmentado / insônia frequente", score: 2 },
  ]},
  { key: "energy" as const, label: "Sua energia ao longo do dia:", options: [
    { v: "stable", label: "Estável e consistente", score: 0 },
    { v: "afternoon", label: "Cai bastante à tarde", score: 1 },
    { v: "low", label: "Cansaço crônico, dificuldade pela manhã", score: 2 },
  ]},
  { key: "mood" as const, label: "Humor e ansiedade:", options: [
    { v: "stable", label: "Estável na maior parte do tempo", score: 0 },
    { v: "sometimes", label: "Oscila com situações cotidianas", score: 1 },
    { v: "frequent", label: "Ansiedade ou tristeza frequentes", score: 2 },
  ]},
  { key: "diet" as const, label: "Alimentação típica:", options: [
    { v: "whole", label: "Comida real, pouco processado", score: 0 },
    { v: "mixed", label: "Mistura, alguns ultraprocessados", score: 1 },
    { v: "processed", label: "Muito açúcar, refrigerante, fast food", score: 2 },
  ]},
  { key: "exercise" as const, label: "Atividade física semanal:", options: [
    { v: "regular", label: "Regular (3+ vezes/semana)", score: 0 },
    { v: "occasional", label: "Ocasional (1–2 vezes)", score: 1 },
    { v: "none", label: "Sedentário", score: 2 },
  ]},
  { key: "family" as const, label: "Histórico familiar (diabetes, depressão, ansiedade)?", options: [
    { v: "no", label: "Não", score: 0 },
    { v: "one", label: "Um caso", score: 1 },
    { v: "many", label: "Vários casos próximos", score: 2 },
  ]},
];

const CalculadoraPage = () => {
  const [a, setA] = useState<Answers>(initial);
  const [done, setDone] = useState(false);

  const score = useMemo(() => {
    let s = 0;
    if (a.age >= 45) s += 1;
    if (a.age >= 60) s += 1;
    if (a.waist >= 90) s += 1;
    if (a.waist >= 102) s += 1;
    questions.forEach(q => {
      const opt = q.options.find(o => o.v === a[q.key]);
      s += opt?.score ?? 0;
    });
    return s;
  }, [a]);

  const maxScore = 4 + questions.length * 2; // 16
  const percent = Math.round((score / maxScore) * 100);

  const tier = score <= 4
    ? { label: "Risco baixo", color: "text-secondary", bg: "bg-secondary/10", icon: ShieldCheck, desc: "Seus hábitos protegem sua saúde metabólica. Continue assim e mantenha avaliações periódicas." }
    : score <= 9
      ? { label: "Risco moderado", color: "text-amber-600", bg: "bg-amber-100", icon: AlertTriangle, desc: "Há sinais de desequilíbrio que merecem atenção. Uma avaliação metabólica pode prevenir agravos no futuro." }
      : { label: "Risco elevado", color: "text-destructive", bg: "bg-destructive/10", icon: AlertCircle, desc: "Vários fatores indicam risco metabólico significativo. Recomendamos fortemente uma avaliação clínica especializada." };

  const filled = questions.every(q => a[q.key] !== "");

  const reset = () => { setA(initial); setDone(false); };

  return (
    <Layout>
      <StandardHero
        variant="organic"
        eyebrow="Ferramenta gratuita"
        title="Calculadora de risco metabólico"
        description="Em 2 minutos, descubra como seus hábitos atuais impactam o risco de desenvolver desequilíbrios metabólicos e suas consequências para a saúde mental."
      />
      <WaveDivider fillColor="hsl(var(--muted))" />

      <section className="py-16 md:py-24 bg-muted">
        <div className="container max-w-3xl">
          <AnimatePresence mode="wait">
            {!done ? (
              <motion.div key="form" initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }} className="bg-background rounded-3xl border border-border p-6 md:p-10 shadow-sm">
                <div className="grid sm:grid-cols-2 gap-5 mb-8">
                  <div>
                    <Label htmlFor="age">Idade</Label>
                    <Input id="age" type="number" min={18} max={100} value={a.age} onChange={(e) => setA({ ...a, age: Number(e.target.value) })} className="mt-1.5 rounded-xl" />
                  </div>
                  <div>
                    <Label htmlFor="waist">Circunferência abdominal (cm)</Label>
                    <Input id="waist" type="number" min={50} max={200} value={a.waist} onChange={(e) => setA({ ...a, waist: Number(e.target.value) })} className="mt-1.5 rounded-xl" />
                  </div>
                </div>

                <div className="space-y-6">
                  {questions.map((q) => (
                    <div key={q.key}>
                      <p className="font-semibold text-foreground mb-3 text-sm">{q.label}</p>
                      <div className="grid gap-2">
                        {q.options.map((opt) => {
                          const selected = a[q.key] === opt.v;
                          return (
                            <button
                              key={opt.v}
                              onClick={() => setA({ ...a, [q.key]: opt.v })}
                              className={`text-left text-sm px-4 py-3 rounded-xl border transition-all ${
                                selected
                                  ? "border-primary bg-primary/5 text-primary font-medium"
                                  : "border-border bg-card hover:border-primary/40 text-foreground/80"
                              }`}
                            >
                              {opt.label}
                            </button>
                          );
                        })}
                      </div>
                    </div>
                  ))}
                </div>

                <Button
                  onClick={() => setDone(true)}
                  disabled={!filled}
                  size="lg"
                  className="w-full mt-10 rounded-xl bg-primary text-primary-foreground gap-2"
                >
                  Calcular meu risco <ArrowRight className="h-4 w-4" />
                </Button>
              </motion.div>
            ) : (
              <motion.div key="result" initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} className="bg-background rounded-3xl border border-border p-6 md:p-10 shadow-sm">
                <div className="text-center mb-8">
                  <div className={`inline-flex items-center justify-center h-20 w-20 rounded-full ${tier.bg} mb-4`}>
                    <tier.icon className={`h-9 w-9 ${tier.color}`} />
                  </div>
                  <p className="text-xs uppercase tracking-wider text-muted-foreground mb-1">Seu resultado</p>
                  <h3 className={`text-3xl md:text-4xl font-bold mb-3 ${tier.color}`} style={{ fontFamily: "'Playfair Display', serif" }}>
                    {tier.label}
                  </h3>
                  <p className="text-foreground/75 max-w-xl mx-auto leading-relaxed">{tier.desc}</p>
                </div>

                {/* Score bar */}
                <div className="mb-8">
                  <div className="flex justify-between text-xs text-muted-foreground mb-2">
                    <span>Pontuação: {score} / {maxScore}</span>
                    <span>{percent}%</span>
                  </div>
                  <div className="h-3 rounded-full bg-muted overflow-hidden">
                    <motion.div
                      initial={{ width: 0 }}
                      animate={{ width: `${percent}%` }}
                      transition={{ duration: 1, ease: "easeOut" }}
                      className={`h-full rounded-full ${
                        score <= 4 ? "bg-secondary" : score <= 9 ? "bg-amber-500" : "bg-destructive"
                      }`}
                    />
                  </div>
                </div>

                <div className="bg-muted/40 rounded-2xl p-5 mb-6">
                  <div className="flex items-start gap-3">
                    <Activity className="h-5 w-5 text-primary shrink-0 mt-0.5" />
                    <div>
                      <p className="font-semibold text-foreground text-sm mb-1">O que isso significa?</p>
                      <p className="text-xs text-foreground/75 leading-relaxed">
                        Esta calculadora é educativa e não substitui avaliação médica. Os fatores avaliados (peso abdominal, sono, energia, alimentação, sedentarismo) são todos modificáveis — pequenas mudanças geram grandes resultados ao longo do tempo.
                      </p>
                    </div>
                  </div>
                </div>

                <div className="flex flex-col sm:flex-row gap-3">
                  <Button asChild size="lg" className="flex-1 rounded-xl bg-primary text-primary-foreground gap-2">
                    <Link to="/avaliacao">Falar com a equipe <ArrowRight className="h-4 w-4" /></Link>
                  </Button>
                  <Button onClick={reset} variant="outline" size="lg" className="rounded-xl gap-2">
                    <RotateCcw className="h-4 w-4" /> Recalcular
                  </Button>
                </div>
              </motion.div>
            )}
          </AnimatePresence>
        </div>
      </section>
    </Layout>
  );
};

export default CalculadoraPage;
