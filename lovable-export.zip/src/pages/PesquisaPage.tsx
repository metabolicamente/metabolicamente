import { useState } from "react";
import { motion } from "framer-motion";
import { Search, ArrowRight, ExternalLink, BookOpen } from "lucide-react";
import Layout from "@/components/Layout";
import { articles, clinicalTrials } from "@/data/research";
import { Badge } from "@/components/ui/badge";
import StandardHero from "@/components/shared/StandardHero";
import WaveDivider from "@/components/shared/WaveDivider";

const allScientificItems = [
  ...articles.map((a) => ({
    id: a.id,
    title: a.title,
    authors: a.authors,
    source: `${a.journal} · ${a.year}`,
    description: a.abstract,
    tags: a.tags,
    url: a.url,
    gradient: a.imageGradient,
  })),
  ...clinicalTrials.map((t) => ({
    id: t.id,
    title: t.title,
    authors: t.institution,
    source: t.year,
    description: t.description,
    tags: [] as string[],
    url: t.url,
    gradient: t.imageGradient,
  })),
];

const referenceProfessionals = [
  {
    name: "Georgia Ede",
    title: "M.D. — Psiquiatra Nutricional",
    institution: "Harvard Medical School",
    initials: "GE",
    description:
      "Psiquiatra e especialista em nutrição da Harvard, Dra. Georgia Ede é pioneira no estudo de como dietas específicas afetam a química cerebral. Autora de 'Change Your Diet, Change Your Mind', ela pesquisa o impacto de alimentos ultraprocessados, carboidratos refinados e deficiências nutricionais nos transtornos mentais. Seu trabalho ajuda a fundamentar protocolos clínicos de intervenção dietética em psiquiatria.",
    url: "https://www.diagnosisdiet.com",
    color: "hsla(153,37%,25%,0.15)",
  },
  {
    name: "Chris Palmer",
    title: "M.D. — Psiquiatra, Pesquisador",
    institution: "Harvard Medical School",
    initials: "CP",
    description:
      "Autor do best-seller 'Brain Energy', o Dr. Chris Palmer é professor de psiquiatria em Harvard e um dos principais defensores da teoria metabólica das doenças mentais. Ele propõe que transtornos psiquiátricos são fundamentalmente distúrbios do metabolismo cerebral, com a mitocôndria no centro da patologia. Seu trabalho conecta décadas de pesquisa em neurociência, metabolismo e psiquiatria.",
    url: "https://www.chrispalmermd.com",
    color: "hsla(100,46%,46%,0.12)",
  },
  {
    name: "Shebani Sethi",
    title: "M.D. — Psiquiatra Metabólica",
    institution: "Stanford University School of Medicine",
    initials: "SS",
    description:
      "Fundadora e diretora do primeiro programa acadêmico de Psiquiatria Metabólica do mundo, na Stanford Medicine. A Dra. Sethi conduziu o estudo piloto que demonstrou que a dieta cetogênica pode produzir remissão em pacientes com esquizofrenia e transtorno bipolar. Seu trabalho está definindo os padrões clínicos e de pesquisa para todo o campo.",
    url: "https://med.stanford.edu/metabolicpsychiatry.html",
    color: "hsla(36,50%,60%,0.12)",
  },
];

const fadeUp = {
  initial: { opacity: 0, y: 20 },
  whileInView: { opacity: 1, y: 0 },
  viewport: { once: true },
};

const PesquisaPage = () => {
  const [search, setSearch] = useState("");

  const filtered = allScientificItems.filter(
    (item) =>
      item.title.toLowerCase().includes(search.toLowerCase()) ||
      item.authors.toLowerCase().includes(search.toLowerCase()) ||
      item.description.toLowerCase().includes(search.toLowerCase()) ||
      item.tags.some((t) => t.toLowerCase().includes(search.toLowerCase()))
  );

  return (
    <Layout>
      <StandardHero
        variant="mesh"
        eyebrow="Base Científica"
        title="Pesquisa Científica"
        description="Artigos revisados por pares, ensaios clínicos e evidências que fundamentam a psiquiatria metabólica."
      >
        <div className="relative max-w-md mx-auto">
          <Search className="absolute left-4 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
          <input
            type="text"
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            placeholder="Buscar artigos, autores ou temas..."
            className="w-full bg-background rounded-xl pl-11 pr-4 py-3.5 text-sm text-foreground placeholder:text-muted-foreground/60 focus:outline-none focus:ring-2 focus:ring-secondary/50 border border-border"
          />
        </div>
      </StandardHero>

      <WaveDivider fillColor="hsl(var(--muted))" />

      {/* Artigos Científicos — unified section */}
      <section className="py-16 md:py-24 bg-muted">
        <div className="container max-w-6xl">
          <motion.div {...fadeUp} transition={{ duration: 0.6 }} className="flex items-center gap-3 mb-10">
            <div className="w-10 h-10 rounded-xl bg-primary/10 flex items-center justify-center">
              <BookOpen className="h-5 w-5 text-primary" />
            </div>
            <h2 className="text-2xl md:text-3xl font-bold text-foreground">Artigos Científicos</h2>
          </motion.div>

          <div className="grid grid-cols-2 lg:grid-cols-3 gap-4 md:gap-6">
            {filtered.map((item, i) => (
              <motion.a
                key={item.id}
                href={item.url}
                target="_blank"
                rel="noopener noreferrer"
                {...fadeUp}
                transition={{ duration: 0.5, delay: i * 0.06 }}
                className="group block h-full rounded-2xl border border-border bg-background overflow-hidden hover:shadow-lg hover:-translate-y-1 transition-all duration-300"
              >
                <div className={`h-28 md:h-36 bg-gradient-to-br ${item.gradient} relative flex items-end p-4 md:p-5`}>
                  <span className="text-[10px] md:text-sm font-medium text-white/80">{item.source}</span>
                </div>
                <div className="p-4 md:p-5">
                  <h3 className="text-xs md:text-base font-semibold text-foreground mb-1 md:mb-2 line-clamp-3 group-hover:text-primary transition-colors">{item.title}</h3>
                  <p className="text-[10px] md:text-xs text-muted-foreground mb-2 md:mb-3 line-clamp-1">{item.authors}</p>
                  <p className="text-xs md:text-sm text-muted-foreground/70 mb-3 md:mb-4 line-clamp-2 md:line-clamp-3 hidden sm:block">{item.description}</p>
                  {item.tags.length > 0 && (
                    <div className="flex flex-wrap gap-1 md:gap-1.5 mb-2 md:mb-3 hidden sm:flex">
                      {item.tags.map((tag) => (
                        <Badge key={tag} variant="secondary" className="text-[10px] md:text-xs bg-muted text-muted-foreground border-0">{tag}</Badge>
                      ))}
                    </div>
                  )}
                  <span className="inline-flex items-center gap-1 text-xs md:text-sm font-medium text-primary group-hover:gap-2 transition-all">
                    Acessar <ExternalLink className="h-3 w-3 md:h-3.5 md:w-3.5" />
                  </span>
                </div>
              </motion.a>
            ))}
          </div>
          {filtered.length === 0 && (
            <p className="text-center text-muted-foreground py-12">Nenhum artigo encontrado para "{search}".</p>
          )}
        </div>
      </section>

      <WaveDivider fillColor="hsl(var(--hero-bg))" />

      {/* Profissionais de Referência */}
      <section className="py-16 md:py-24" style={{ background: "hsl(var(--hero-bg))" }}>
        <div className="container max-w-5xl">
          <motion.div {...fadeUp} transition={{ duration: 0.6 }} className="text-center mb-14">
            <p className="text-sm uppercase tracking-[0.3em] text-primary-foreground/50 mb-3" style={{ fontFamily: "'Montserrat', sans-serif" }}>
              Referências Globais
            </p>
            <h2 className="text-2xl md:text-4xl font-bold text-primary-foreground" style={{ fontFamily: "'Montserrat', sans-serif" }}>
              Profissionais de Referência
            </h2>
          </motion.div>

          <div className="space-y-8">
            {referenceProfessionals.map((prof, i) => (
              <motion.a
                key={prof.name}
                href={prof.url}
                target="_blank"
                rel="noopener noreferrer"
                {...fadeUp}
                transition={{ duration: 0.6, delay: i * 0.12 }}
                className="group flex flex-col md:flex-row gap-6 md:gap-8 p-6 md:p-8 rounded-2xl border border-white/10 bg-white/[0.03] hover:bg-white/[0.06] transition-all duration-300"
              >
                {/* Initials avatar */}
                <div className="flex-shrink-0 flex items-start">
                  <div
                    className="w-20 h-20 md:w-24 md:h-24 rounded-2xl flex items-center justify-center text-2xl md:text-3xl font-bold text-primary-foreground/80 border border-white/10"
                    style={{ background: prof.color }}
                  >
                    {prof.initials}
                  </div>
                </div>

                {/* Info */}
                <div className="flex-1 min-w-0">
                  <h3 className="text-xl md:text-2xl font-bold text-primary-foreground mb-1 group-hover:text-secondary transition-colors" style={{ fontFamily: "'Montserrat', sans-serif" }}>
                    {prof.name}
                  </h3>
                  <p className="text-sm text-primary-foreground/60 mb-1">{prof.title}</p>
                  <p className="text-xs text-secondary/80 mb-4 font-medium">{prof.institution}</p>
                  <p className="text-sm text-primary-foreground/70 leading-relaxed">{prof.description}</p>
                  <span className="inline-flex items-center gap-1.5 text-xs font-medium text-secondary mt-4 group-hover:gap-2.5 transition-all">
                    Saiba mais <ArrowRight className="h-3 w-3" />
                  </span>
                </div>
              </motion.a>
            ))}
          </div>
        </div>
      </section>
    </Layout>
  );
};

export default PesquisaPage;
