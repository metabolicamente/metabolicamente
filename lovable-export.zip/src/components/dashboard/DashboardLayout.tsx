import { ReactNode, useState } from "react";
import { Link, useNavigate } from "react-router-dom";
import { Brain, LogOut, Menu, X } from "lucide-react";
import { Button } from "@/components/ui/button";

interface DashboardLayoutProps {
  children: ReactNode;
  userName: string;
  role: string;
}

const DashboardLayout = ({ children, userName, role }: DashboardLayoutProps) => {
  const navigate = useNavigate();
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);

  const roleLabel = role === "medico" ? "Médico" : role === "nutri" ? "Nutricionista" : "Paciente";

  const handleLogout = () => {
    localStorage.removeItem("mm_role");
    localStorage.removeItem("mm_user");
    navigate("/login");
  };

  return (
    <div className="min-h-screen bg-background">
      {/* Top bar */}
      <header className="sticky top-0 z-50 bg-primary text-primary-foreground">
        <div className="container flex h-14 items-center justify-between">
          <Link to="/" className="flex items-center gap-2">
            <Brain className="h-5 w-5" />
            <span className="text-base font-bold hidden sm:inline" style={{ fontFamily: "'Montserrat', sans-serif" }}>
              Metabolicamente
            </span>
          </Link>

          <div className="hidden sm:flex items-center gap-4">
            <div className="text-right">
              <p className="text-sm font-medium leading-tight">{userName}</p>
              <p className="text-[11px] opacity-80">{roleLabel}</p>
            </div>
            <Button
              variant="ghost"
              size="sm"
              onClick={handleLogout}
              className="text-primary-foreground/80 hover:text-primary-foreground hover:bg-primary-foreground/10"
            >
              <LogOut className="h-4 w-4 mr-1" />
              Sair
            </Button>
          </div>

          <button className="sm:hidden text-primary-foreground" onClick={() => setMobileMenuOpen(!mobileMenuOpen)}>
            {mobileMenuOpen ? <X className="h-5 w-5" /> : <Menu className="h-5 w-5" />}
          </button>
        </div>

        {mobileMenuOpen && (
          <div className="sm:hidden border-t border-primary-foreground/10 pb-3 px-4">
            <div className="py-3 border-b border-primary-foreground/10 mb-2">
              <p className="text-sm font-medium">{userName}</p>
              <p className="text-[11px] opacity-80">{roleLabel}</p>
            </div>
            <Button
              variant="ghost"
              size="sm"
              onClick={handleLogout}
              className="text-primary-foreground/80 hover:text-primary-foreground hover:bg-primary-foreground/10 w-full justify-start"
            >
              <LogOut className="h-4 w-4 mr-2" />
              Sair
            </Button>
          </div>
        )}
      </header>

      <main className="container py-6 md:py-8">{children}</main>
    </div>
  );
};

export default DashboardLayout;
