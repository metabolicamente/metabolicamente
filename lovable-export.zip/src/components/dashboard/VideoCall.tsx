import { useState } from "react";
import { motion } from "framer-motion";
import { X, Mic, MicOff, Video, VideoOff, PhoneOff } from "lucide-react";
import { Button } from "@/components/ui/button";

interface VideoCallProps {
  contactName: string;
  onClose: () => void;
}

const VideoCall = ({ contactName, onClose }: VideoCallProps) => {
  const [micOn, setMicOn] = useState(true);
  const [camOn, setCamOn] = useState(true);

  return (
    <motion.div
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      exit={{ opacity: 0 }}
      className="fixed inset-0 z-50 bg-foreground/95 flex flex-col items-center justify-center"
    >
      {/* Contact name */}
      <div className="absolute top-6 left-0 right-0 text-center">
        <p className="text-primary-foreground text-lg font-semibold">{contactName}</p>
        <p className="text-primary-foreground/60 text-sm">Teleconsulta em andamento</p>
      </div>

      {/* "Video" area */}
      <div className="w-full max-w-2xl aspect-video bg-primary/20 rounded-2xl flex items-center justify-center mx-4 relative overflow-hidden">
        <div className="text-center">
          <div className="w-24 h-24 rounded-full bg-primary/30 mx-auto flex items-center justify-center mb-4">
            <span className="text-3xl font-bold text-primary-foreground">{contactName.charAt(0)}</span>
          </div>
          <p className="text-primary-foreground/80 text-sm">{camOn ? "Câmera ativa (simulação)" : "Câmera desligada"}</p>
        </div>

        {/* Self-view */}
        <div className="absolute bottom-3 right-3 w-28 h-20 bg-primary/40 rounded-xl flex items-center justify-center border border-primary-foreground/20">
          <span className="text-xs text-primary-foreground/70">Você</span>
        </div>
      </div>

      {/* Controls */}
      <div className="flex items-center gap-4 mt-8">
        <Button
          variant="ghost"
          size="icon"
          onClick={() => setMicOn(!micOn)}
          className={`h-14 w-14 rounded-full ${micOn ? "bg-primary-foreground/10 text-primary-foreground" : "bg-destructive text-destructive-foreground"}`}
        >
          {micOn ? <Mic className="h-5 w-5" /> : <MicOff className="h-5 w-5" />}
        </Button>
        <Button
          variant="ghost"
          size="icon"
          onClick={() => setCamOn(!camOn)}
          className={`h-14 w-14 rounded-full ${camOn ? "bg-primary-foreground/10 text-primary-foreground" : "bg-destructive text-destructive-foreground"}`}
        >
          {camOn ? <Video className="h-5 w-5" /> : <VideoOff className="h-5 w-5" />}
        </Button>
        <Button
          variant="ghost"
          size="icon"
          onClick={onClose}
          className="h-14 w-14 rounded-full bg-destructive text-destructive-foreground hover:bg-destructive/80"
        >
          <PhoneOff className="h-5 w-5" />
        </Button>
      </div>

      {/* Close X */}
      <button onClick={onClose} className="absolute top-4 right-4 text-primary-foreground/60 hover:text-primary-foreground transition-colors">
        <X className="h-5 w-5" />
      </button>
    </motion.div>
  );
};

export default VideoCall;
