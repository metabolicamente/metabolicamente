import { useState } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { Sparkles, X, Send } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";

interface AIAssistantProps {
  patientName: string;
  onClose: () => void;
}

const suggestions = [
  "Com base nos exames de sangue, os níveis de vitamina D estão abaixo do ideal (18 ng/mL). Sugiro suplementação de 2.000 UI/dia e exposição solar matinal de 15 min.",
  "A hemoglobina glicada está em 5.8%, na faixa de pré-diabetes. Recomendo reduzir carboidratos refinados e incluir mais fibras solúveis nas refeições.",
  "O perfil lipídico mostra LDL elevado (145 mg/dL). Uma estratégia com aveia, linhaça e azeite pode ajudar a reduzir em 4-6 semanas.",
  "Os marcadores inflamatórios (PCR) estão levemente elevados. Considere incluir ômega-3 (EPA/DHA) e cúrcuma na dieta.",
];

type Msg = { id: number; text: string; sender: "ai" | "user" };

const AIAssistant = ({ patientName, onClose }: AIAssistantProps) => {
  const [messages, setMessages] = useState<Msg[]>([
    { id: 1, text: `Analisando os exames de ${patientName}...`, sender: "ai" },
    { id: 2, text: suggestions[0], sender: "ai" },
  ]);
  const [input, setInput] = useState("");

  const handleSend = () => {
    if (!input.trim()) return;
    setMessages((prev) => [...prev, { id: Date.now(), text: input, sender: "user" as const }]);
    setInput("");
    setTimeout(() => {
      const idx = Math.floor(Math.random() * suggestions.length);
      setMessages((prev) => [...prev, { id: Date.now() + 1, text: suggestions[idx], sender: "ai" as const }]);
    }, 1200);
  };

  return (
    <motion.div
      initial={{ opacity: 0, x: 30 }}
      animate={{ opacity: 1, x: 0 }}
      exit={{ opacity: 0, x: 30 }}
      className="fixed inset-0 z-50 bg-background flex flex-col md:inset-auto md:top-4 md:right-4 md:bottom-4 md:w-[380px] md:rounded-2xl md:border md:border-border md:shadow-2xl"
    >
      {/* Header */}
      <div className="flex items-center justify-between px-4 py-3 border-b border-border">
        <div className="flex items-center gap-2">
          <div className="h-8 w-8 rounded-full bg-secondary/20 flex items-center justify-center">
            <Sparkles className="h-4 w-4 text-secondary" />
          </div>
          <div>
            <p className="text-sm font-semibold text-foreground">AI Assistant</p>
            <p className="text-[11px] text-muted-foreground">Análise nutricional inteligente</p>
          </div>
        </div>
        <button onClick={onClose} className="text-muted-foreground hover:text-foreground transition-colors">
          <X className="h-4 w-4" />
        </button>
      </div>

      {/* Messages */}
      <div className="flex-1 overflow-y-auto p-4 space-y-3">
        <AnimatePresence>
          {messages.map((msg) => (
            <motion.div
              key={msg.id}
              initial={{ opacity: 0, y: 10 }}
              animate={{ opacity: 1, y: 0 }}
              className={`flex ${msg.sender === "user" ? "justify-end" : "justify-start"}`}
            >
              <div
                className={`max-w-[85%] px-3.5 py-2.5 rounded-2xl text-sm leading-relaxed ${
                  msg.sender === "user"
                    ? "bg-primary text-primary-foreground rounded-br-md"
                    : "bg-muted text-foreground rounded-bl-md"
                }`}
              >
                {msg.sender === "ai" && <Sparkles className="h-3 w-3 text-secondary inline mr-1 -mt-0.5" />}
                {msg.text}
              </div>
            </motion.div>
          ))}
        </AnimatePresence>
      </div>

      {/* Input */}
      <div className="p-3 border-t border-border flex gap-2">
        <Input
          value={input}
          onChange={(e) => setInput(e.target.value)}
          onKeyDown={(e) => e.key === "Enter" && handleSend()}
          placeholder="Pergunte à IA..."
          className="flex-1 h-10 rounded-xl bg-muted/50 border-border text-sm"
        />
        <Button onClick={handleSend} size="icon" className="h-10 w-10 rounded-xl bg-secondary text-secondary-foreground">
          <Send className="h-4 w-4" />
        </Button>
      </div>
    </motion.div>
  );
};

export default AIAssistant;
