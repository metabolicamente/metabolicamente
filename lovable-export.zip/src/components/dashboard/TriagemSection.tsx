import { useState } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { CheckCircle2, ArrowRight, ArrowLeft, Sparkles } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import SectionHeader from "@/components/dashboard/SectionHeader";

const STEPS = [
  { id: "queixa", label: "Qual é sua principal queixa hoje?", placeholder: "Descreva como você se sente..." },
  { id: "energia", label: "Como está sua energia?", type: "scale" },
  { id: "sono", label: "Como está seu sono?", type: "scale" },
  { id: "humor", label: "Como descreveria seu humor?", placeholder: "Triste, ansioso, motivado..." },
  { id: "alimentar", label: "Como foi sua alimentação esta semana?", placeholder: "Resumo do que comeu..." },
] as const;

const TriagemSection = () => {
  const [step, setStep] = useState(0);
  const [answers, setAnswers] = useState<Record<string, string | number>>({});
  const [done, setDone] = useState(false);

  const current = STEPS[step];
  const value = answers[current.id];
  const isScale = "type" in current && current.type === "scale";
  const canAdvance = isScale ? value !== undefined : (typeof value === "string" && value.trim().length > 3);

  const next = () => {
    if (step < STEPS.length - 1) setStep(step + 1);
    else setDone(true);
  };

  if (done) {
    return (
      <motion.div
        initial={{ opacity: 0, scale: 0.96 }}
        animate={{ opacity: 1, scale: 1 }}
        className="bg-card border border-border rounded-2xl p-8 text-center"
      >
        <div className="h-16 w-16 rounded-full bg-secondary/20 flex items-center justify-center mx-auto mb-4">
          <CheckCircle2 className="h-8 w-8 text-secondary" />
        </div>
        <h2 className="text-xl font-bold text-foreground mb-2" style={{ fontFamily: "'Montserrat', sans-serif" }}>
          Check-in registrado
        </h2>
        <p className="text-sm text-muted-foreground mb-5">
          Sua equipe receberá essas informações para o próximo atendimento.
        </p>
        <Button onClick={() => { setDone(false); setStep(0); setAnswers({}); }} variant="outline" className="rounded-xl">
          Fazer novo check-in
        </Button>
      </motion.div>
    );
  }

  return (
    <>
      <SectionHeader
        title="Check-in semanal"
        subtitle="Responda em poucos passos para sua equipe acompanhar"
      />

      {/* Progress bar */}
      <div className="mb-6">
        <div className="flex justify-between text-xs text-muted-foreground mb-2">
          <span>Passo {step + 1} de {STEPS.length}</span>
          <span>{Math.round(((step + 1) / STEPS.length) * 100)}%</span>
        </div>
        <div className="h-1.5 rounded-full bg-muted overflow-hidden">
          <motion.div
            className="h-full bg-primary rounded-full"
            animate={{ width: `${((step + 1) / STEPS.length) * 100}%` }}
            transition={{ duration: 0.4 }}
          />
        </div>
      </div>

      <AnimatePresence mode="wait">
        <motion.div
          key={current.id}
          initial={{ opacity: 0, x: 30 }}
          animate={{ opacity: 1, x: 0 }}
          exit={{ opacity: 0, x: -30 }}
          transition={{ duration: 0.25 }}
          className="bg-card border border-border rounded-2xl p-6"
        >
          <div className="flex items-center gap-2 mb-4">
            <Sparkles className="h-4 w-4 text-secondary" />
            <p className="text-xs uppercase tracking-wider text-muted-foreground font-semibold">
              Pergunta
            </p>
          </div>
          <h2 className="text-lg font-semibold text-foreground mb-5" style={{ fontFamily: "'Montserrat', sans-serif" }}>
            {current.label}
          </h2>

          {isScale ? (
            <div className="grid grid-cols-10 gap-1.5">
              {Array.from({ length: 10 }, (_, i) => i + 1).map((n) => (
                <button
                  key={n}
                  onClick={() => setAnswers({ ...answers, [current.id]: n })}
                  className={`aspect-square rounded-xl text-sm font-semibold border transition-all ${
                    value === n
                      ? "bg-primary text-primary-foreground border-primary scale-105"
                      : "bg-card text-foreground border-border hover:border-primary/40"
                  }`}
                >
                  {n}
                </button>
              ))}
            </div>
          ) : (
            <Textarea
              value={(value as string) || ""}
              onChange={(e) => setAnswers({ ...answers, [current.id]: e.target.value })}
              placeholder={"placeholder" in current ? current.placeholder : ""}
              rows={4}
              className="rounded-xl resize-none bg-muted/30 border-border"
            />
          )}
        </motion.div>
      </AnimatePresence>

      <div className="flex justify-between mt-5">
        <Button
          variant="ghost"
          onClick={() => setStep(Math.max(0, step - 1))}
          disabled={step === 0}
          className="rounded-xl"
        >
          <ArrowLeft className="h-4 w-4 mr-1" /> Voltar
        </Button>
        <Button
          onClick={next}
          disabled={!canAdvance}
          className="rounded-xl bg-primary text-primary-foreground gap-2"
        >
          {step === STEPS.length - 1 ? "Finalizar" : "Próximo"}
          <ArrowRight className="h-4 w-4" />
        </Button>
      </div>
    </>
  );
};

export default TriagemSection;
