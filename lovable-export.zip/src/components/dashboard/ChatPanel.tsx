import { useState, useRef, useEffect } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { Send, X } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";

interface Message {
  id: number;
  text: string;
  sender: "me" | "other";
  time: string;
}

interface ChatPanelProps {
  contactName: string;
  onClose: () => void;
  initialMessages?: Message[];
}

const defaultMessages: Message[] = [
  { id: 1, text: "Olá! Como você está se sentindo hoje?", sender: "other", time: "10:30" },
  { id: 2, text: "Estou bem, obrigado! Segui as orientações.", sender: "me", time: "10:32" },
  { id: 3, text: "Ótimo! Notou alguma diferença na disposição?", sender: "other", time: "10:33" },
];

const ChatPanel = ({ contactName, onClose, initialMessages }: ChatPanelProps) => {
  const [messages, setMessages] = useState<Message[]>(initialMessages || defaultMessages);
  const [input, setInput] = useState("");
  const bottomRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    bottomRef.current?.scrollIntoView({ behavior: "smooth" });
  }, [messages]);

  const sendMessage = () => {
    if (!input.trim()) return;
    const newMsg: Message = {
      id: Date.now(),
      text: input.trim(),
      sender: "me",
      time: new Date().toLocaleTimeString("pt-BR", { hour: "2-digit", minute: "2-digit" }),
    };
    setMessages((prev) => [...prev, newMsg]);
    setInput("");

    // Simulated reply
    setTimeout(() => {
      setMessages((prev) => [
        ...prev,
        {
          id: Date.now() + 1,
          text: "Recebi sua mensagem. Vou analisar e retorno em breve!",
          sender: "other",
          time: new Date().toLocaleTimeString("pt-BR", { hour: "2-digit", minute: "2-digit" }),
        },
      ]);
    }, 1500);
  };

  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      exit={{ opacity: 0, y: 20 }}
      className="fixed inset-0 z-50 bg-background flex flex-col md:inset-auto md:bottom-4 md:right-4 md:w-[400px] md:h-[550px] md:rounded-2xl md:border md:border-border md:shadow-2xl"
    >
      {/* Header */}
      <div className="flex items-center justify-between px-4 py-3 border-b border-border bg-primary text-primary-foreground md:rounded-t-2xl">
        <div>
          <p className="text-sm font-semibold">{contactName}</p>
          <p className="text-[11px] opacity-80">Online</p>
        </div>
        <button onClick={onClose} className="hover:bg-primary-foreground/10 rounded-full p-1 transition-colors">
          <X className="h-4 w-4" />
        </button>
      </div>

      {/* Messages */}
      <div className="flex-1 overflow-y-auto p-4 space-y-3">
        {messages.map((msg) => (
          <div key={msg.id} className={`flex ${msg.sender === "me" ? "justify-end" : "justify-start"}`}>
            <div
              className={`max-w-[75%] px-3.5 py-2.5 rounded-2xl text-sm leading-relaxed ${
                msg.sender === "me"
                  ? "bg-primary text-primary-foreground rounded-br-md"
                  : "bg-muted text-foreground rounded-bl-md"
              }`}
            >
              {msg.text}
              <p className={`text-[10px] mt-1 ${msg.sender === "me" ? "text-primary-foreground/60" : "text-muted-foreground"}`}>
                {msg.time}
              </p>
            </div>
          </div>
        ))}
        <div ref={bottomRef} />
      </div>

      {/* Input */}
      <div className="p-3 border-t border-border flex gap-2">
        <Input
          value={input}
          onChange={(e) => setInput(e.target.value)}
          onKeyDown={(e) => e.key === "Enter" && sendMessage()}
          placeholder="Digite sua mensagem..."
          className="flex-1 h-10 rounded-xl bg-muted/50 border-border text-sm"
        />
        <Button onClick={sendMessage} size="icon" className="h-10 w-10 rounded-xl bg-primary text-primary-foreground">
          <Send className="h-4 w-4" />
        </Button>
      </div>
    </motion.div>
  );
};

export default ChatPanel;
