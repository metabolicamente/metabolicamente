import { LucideIcon } from "lucide-react";
import { motion } from "framer-motion";

interface EmptyStateProps {
  icon: LucideIcon;
  title: string;
  description?: string;
  action?: React.ReactNode;
}

const EmptyState = ({ icon: Icon, title, description, action }: EmptyStateProps) => (
  <motion.div
    initial={{ opacity: 0, scale: 0.96 }}
    animate={{ opacity: 1, scale: 1 }}
    className="flex flex-col items-center justify-center text-center py-12 px-6 bg-card border border-dashed border-border rounded-2xl"
  >
    <div className="h-16 w-16 rounded-full bg-primary/5 flex items-center justify-center mb-4">
      <Icon className="h-7 w-7 text-primary/60" />
    </div>
    <p className="font-semibold text-foreground" style={{ fontFamily: "'Montserrat', sans-serif" }}>
      {title}
    </p>
    {description && (
      <p className="text-sm text-muted-foreground mt-1 max-w-sm">{description}</p>
    )}
    {action && <div className="mt-4">{action}</div>}
  </motion.div>
);

export default EmptyState;
