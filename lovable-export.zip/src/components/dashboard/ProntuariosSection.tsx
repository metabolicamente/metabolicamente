import { useState, useEffect } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { FilePlus, Trash2, ClipboardList, Save } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import SectionHeader from "@/components/dashboard/SectionHeader";
import EmptyState from "@/components/dashboard/EmptyState";

interface Note {
  id: string;
  patient: string;
  title: string;
  body: string;
  date: string;
}

const STORAGE_KEY = "mm_clinical_notes";

const ProntuariosSection = ({ patients }: { patients: { id: number; name: string }[] }) => {
  const [notes, setNotes] = useState<Note[]>([]);
  const [creating, setCreating] = useState(false);
  const [draft, setDraft] = useState({ patient: patients[0]?.name || "", title: "", body: "" });

  useEffect(() => {
    try {
      const raw = localStorage.getItem(STORAGE_KEY);
      if (raw) setNotes(JSON.parse(raw));
    } catch { /* ignore */ }
  }, []);

  const persist = (next: Note[]) => {
    setNotes(next);
    localStorage.setItem(STORAGE_KEY, JSON.stringify(next));
  };

  const save = () => {
    if (!draft.title.trim() || !draft.body.trim()) return;
    const note: Note = {
      id: Date.now().toString(),
      patient: draft.patient,
      title: draft.title.trim(),
      body: draft.body.trim(),
      date: new Date().toLocaleDateString("pt-BR"),
    };
    persist([note, ...notes]);
    setDraft({ patient: patients[0]?.name || "", title: "", body: "" });
    setCreating(false);
  };

  const remove = (id: string) => persist(notes.filter(n => n.id !== id));

  return (
    <>
      <SectionHeader
        title="Prontuários"
        subtitle="Notas e evolução clínica"
        action={
          !creating && (
            <Button
              onClick={() => setCreating(true)}
              size="sm"
              className="rounded-xl gap-2 bg-primary text-primary-foreground"
            >
              <FilePlus className="h-4 w-4" /> Nova nota
            </Button>
          )
        }
      />

      <AnimatePresence>
        {creating && (
          <motion.div
            initial={{ opacity: 0, y: -10 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -10 }}
            className="bg-card border border-border rounded-2xl p-5 mb-4 space-y-3"
          >
            <div>
              <label className="text-xs font-medium text-muted-foreground uppercase tracking-wide">Paciente</label>
              <select
                value={draft.patient}
                onChange={(e) => setDraft({ ...draft, patient: e.target.value })}
                className="mt-1 w-full h-11 rounded-xl border border-border bg-card px-3 text-sm focus:outline-none focus:ring-2 focus:ring-ring"
              >
                {patients.map(p => <option key={p.id} value={p.name}>{p.name}</option>)}
              </select>
            </div>
            <div>
              <label className="text-xs font-medium text-muted-foreground uppercase tracking-wide">Título</label>
              <Input
                value={draft.title}
                onChange={(e) => setDraft({ ...draft, title: e.target.value })}
                placeholder="Ex: Retorno após 30 dias"
                className="mt-1 h-11 rounded-xl"
              />
            </div>
            <div>
              <label className="text-xs font-medium text-muted-foreground uppercase tracking-wide">Nota clínica</label>
              <Textarea
                value={draft.body}
                onChange={(e) => setDraft({ ...draft, body: e.target.value })}
                placeholder="Evolução, conduta, prescrição..."
                rows={5}
                className="mt-1 rounded-xl resize-none"
              />
            </div>
            <div className="flex justify-end gap-2 pt-1">
              <Button variant="ghost" onClick={() => setCreating(false)} className="rounded-xl">
                Cancelar
              </Button>
              <Button onClick={save} className="rounded-xl bg-primary text-primary-foreground gap-2">
                <Save className="h-4 w-4" /> Salvar
              </Button>
            </div>
          </motion.div>
        )}
      </AnimatePresence>

      {notes.length === 0 && !creating ? (
        <EmptyState
          icon={ClipboardList}
          title="Nenhuma nota ainda"
          description="Crie sua primeira nota clínica para começar o prontuário."
        />
      ) : (
        <div className="space-y-3">
          <AnimatePresence>
            {notes.map((n) => (
              <motion.div
                key={n.id}
                initial={{ opacity: 0, y: 8 }}
                animate={{ opacity: 1, y: 0 }}
                exit={{ opacity: 0, x: -20 }}
                className="bg-card border border-border rounded-2xl p-5"
              >
                <div className="flex items-start justify-between gap-3 mb-2">
                  <div>
                    <p className="font-semibold text-foreground text-sm">{n.title}</p>
                    <p className="text-xs text-muted-foreground">{n.patient} · {n.date}</p>
                  </div>
                  <button
                    onClick={() => remove(n.id)}
                    className="text-muted-foreground hover:text-destructive transition-colors p-1"
                    aria-label="Excluir nota"
                  >
                    <Trash2 className="h-4 w-4" />
                  </button>
                </div>
                <p className="text-sm text-foreground/80 whitespace-pre-line leading-relaxed">{n.body}</p>
              </motion.div>
            ))}
          </AnimatePresence>
        </div>
      )}
    </>
  );
};

export default ProntuariosSection;
