import { useState } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { Sparkles, X, Loader2, Coffee, Sun, Moon, Apple, Check } from "lucide-react";
import { Button } from "@/components/ui/button";

interface CardapioGeneratorProps {
  patientName: string;
  goal: string;
  onClose: () => void;
}

const sampleDay = [
  { time: "Café da manhã", icon: Coffee, items: ["Omelete com espinafre e queijo", "Abacate fatiado", "Chá verde"] },
  { time: "Lanche da manhã", icon: Apple, items: ["Iogurte natural com chia", "Mix de castanhas (30g)"] },
  { time: "Almoço", icon: Sun, items: ["Filé de salmão grelhado", "Quinoa com legumes salteados", "Salada folhosa com azeite e limão"] },
  { time: "Lanche da tarde", icon: Apple, items: ["Frutas vermelhas", "Pasta de amendoim com banana"] },
  { time: "Jantar", icon: Moon, items: ["Frango ao curry com leite de coco", "Brócolis e cenoura no vapor", "Batata-doce assada"] },
];

const CardapioGenerator = ({ patientName, goal, onClose }: CardapioGeneratorProps) => {
  const [step, setStep] = useState<"loading" | "ready" | "saved">("loading");

  setTimeout(() => {
    if (step === "loading") setStep("ready");
  }, 1800);

  return (
    <motion.div
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      exit={{ opacity: 0 }}
      className="fixed inset-0 z-50 bg-foreground/40 flex items-center justify-center p-4"
      onClick={onClose}
    >
      <motion.div
        initial={{ scale: 0.95, y: 20 }}
        animate={{ scale: 1, y: 0 }}
        exit={{ scale: 0.95, y: 20 }}
        onClick={(e) => e.stopPropagation()}
        className="bg-background rounded-2xl shadow-2xl w-full max-w-2xl max-h-[90vh] flex flex-col overflow-hidden border border-border"
      >
        {/* Header */}
        <div className="flex items-center justify-between p-5 border-b border-border bg-gradient-to-r from-secondary/10 to-secondary/5">
          <div className="flex items-center gap-3">
            <div className="h-10 w-10 rounded-full bg-secondary/20 flex items-center justify-center">
              <Sparkles className="h-4 w-4 text-secondary" />
            </div>
            <div>
              <p className="font-semibold text-foreground text-sm">Cardápio gerado por IA</p>
              <p className="text-[11px] text-muted-foreground">Para {patientName}</p>
            </div>
          </div>
          <button onClick={onClose} className="text-muted-foreground hover:text-foreground transition-colors">
            <X className="h-5 w-5" />
          </button>
        </div>

        <div className="flex-1 overflow-y-auto p-6">
          <AnimatePresence mode="wait">
            {step === "loading" && (
              <motion.div
                key="loading"
                initial={{ opacity: 0 }}
                animate={{ opacity: 1 }}
                exit={{ opacity: 0 }}
                className="flex flex-col items-center justify-center py-16 text-center"
              >
                <Loader2 className="h-10 w-10 text-secondary animate-spin mb-4" />
                <p className="font-semibold text-foreground" style={{ fontFamily: "'Montserrat', sans-serif" }}>
                  Analisando exames e objetivos...
                </p>
                <p className="text-xs text-muted-foreground mt-1">
                  Gerando cardápio personalizado para "{goal}"
                </p>
              </motion.div>
            )}

            {step === "ready" && (
              <motion.div key="ready" initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }}>
                <p className="text-xs uppercase tracking-wider text-muted-foreground font-semibold mb-1">
                  Sugestão para hoje
                </p>
                <h3 className="text-lg font-bold text-foreground mb-5" style={{ fontFamily: "'Montserrat', sans-serif" }}>
                  Cardápio personalizado
                </h3>

                <div className="space-y-3">
                  {sampleDay.map((meal, i) => {
                    const Icon = meal.icon;
                    return (
                      <motion.div
                        key={meal.time}
                        initial={{ opacity: 0, x: -10 }}
                        animate={{ opacity: 1, x: 0 }}
                        transition={{ delay: i * 0.08 }}
                        className="bg-card border border-border rounded-2xl p-4"
                      >
                        <div className="flex items-center gap-2 mb-2">
                          <div className="h-8 w-8 rounded-full bg-secondary/10 flex items-center justify-center">
                            <Icon className="h-3.5 w-3.5 text-secondary" />
                          </div>
                          <p className="font-semibold text-sm text-foreground">{meal.time}</p>
                        </div>
                        <ul className="space-y-1 ml-10">
                          {meal.items.map(item => (
                            <li key={item} className="flex items-start gap-2 text-xs text-foreground/80">
                              <span className="h-1 w-1 rounded-full bg-primary mt-1.5 shrink-0" />
                              {item}
                            </li>
                          ))}
                        </ul>
                      </motion.div>
                    );
                  })}
                </div>

                <div className="mt-5 p-4 bg-primary/5 border border-primary/15 rounded-xl">
                  <p className="text-xs text-foreground/80 leading-relaxed">
                    💡 <span className="font-medium">Sugestão da IA:</span> baseado nos níveis de vitamina D e perfil glicêmico, este plano enfatiza proteínas magras, gorduras boas e fibras solúveis.
                  </p>
                </div>
              </motion.div>
            )}

            {step === "saved" && (
              <motion.div
                key="saved"
                initial={{ opacity: 0, scale: 0.95 }}
                animate={{ opacity: 1, scale: 1 }}
                className="flex flex-col items-center py-16 text-center"
              >
                <div className="h-14 w-14 rounded-full bg-secondary/20 flex items-center justify-center mb-4">
                  <Check className="h-7 w-7 text-secondary" />
                </div>
                <p className="font-bold text-foreground" style={{ fontFamily: "'Montserrat', sans-serif" }}>
                  Cardápio enviado!
                </p>
                <p className="text-sm text-muted-foreground mt-1">
                  {patientName} já pode visualizar o plano no painel.
                </p>
              </motion.div>
            )}
          </AnimatePresence>
        </div>

        {step === "ready" && (
          <div className="p-4 border-t border-border flex justify-end gap-2">
            <Button variant="ghost" onClick={onClose} className="rounded-xl">Cancelar</Button>
            <Button
              onClick={() => { setStep("saved"); setTimeout(onClose, 1500); }}
              className="rounded-xl bg-secondary text-secondary-foreground gap-2"
            >
              <Check className="h-4 w-4" /> Enviar para paciente
            </Button>
          </div>
        )}
      </motion.div>
    </motion.div>
  );
};

export default CardapioGenerator;
