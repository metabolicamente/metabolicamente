import { useState, useRef, useEffect } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { Sparkles, X, Send, Loader2 } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { toast } from "sonner";

interface AIChatProps {
  title?: string;
  subtitle?: string;
  role?: "cliente" | "medico" | "nutri";
  context?: string;
  onClose: () => void;
}

type Msg = { role: "user" | "assistant"; content: string };

const SUPABASE_URL = import.meta.env.VITE_SUPABASE_URL;
const SUPABASE_KEY = import.meta.env.VITE_SUPABASE_PUBLISHABLE_KEY;

const greetings: Record<string, string> = {
  cliente: "Olá! Sou seu assistente clínico. Posso esclarecer dúvidas sobre alimentação, exames e seu tratamento. Como posso ajudar?",
  medico: "Pronto para auxiliar no raciocínio clínico. Compartilhe exames, queixas ou hipóteses para discutirmos.",
  nutri: "Posso ajudar com análise nutricional, sugestões de cardápio ou interpretação de exames. O que vamos avaliar?",
};

const AIChat = ({ title = "Assistente IA", subtitle = "Powered by Lovable AI", role = "cliente", context, onClose }: AIChatProps) => {
  const initialAssistant = context ? `${greetings[role]}\n\nContexto inicial: ${context}` : greetings[role];
  const [messages, setMessages] = useState<Msg[]>([{ role: "assistant", content: initialAssistant }]);
  const [input, setInput] = useState("");
  const [loading, setLoading] = useState(false);
  const bottomRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    bottomRef.current?.scrollIntoView({ behavior: "smooth" });
  }, [messages, loading]);

  const send = async () => {
    const text = input.trim();
    if (!text || loading) return;

    const next: Msg[] = [...messages, { role: "user", content: text }];
    setMessages(next);
    setInput("");
    setLoading(true);

    try {
      const res = await fetch(`${SUPABASE_URL}/functions/v1/ai-chat`, {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          Authorization: `Bearer ${SUPABASE_KEY}`,
        },
        body: JSON.stringify({ messages: next, role }),
      });

      if (res.status === 429) {
        toast.error("Limite de uso atingido. Tente novamente em alguns minutos.");
        setLoading(false);
        return;
      }
      if (res.status === 402) {
        toast.error("Créditos da IA esgotados. Adicione créditos nas configurações.");
        setLoading(false);
        return;
      }
      if (!res.ok || !res.body) {
        toast.error("Não foi possível obter resposta da IA.");
        setLoading(false);
        return;
      }

      // Stream SSE response
      const reader = res.body.getReader();
      const decoder = new TextDecoder();
      let assistant = "";
      setMessages((prev) => [...prev, { role: "assistant", content: "" }]);

      let buffer = "";
      while (true) {
        const { value, done } = await reader.read();
        if (done) break;
        buffer += decoder.decode(value, { stream: true });
        const lines = buffer.split("\n");
        buffer = lines.pop() || "";
        for (const line of lines) {
          const trimmed = line.trim();
          if (!trimmed.startsWith("data:")) continue;
          const data = trimmed.slice(5).trim();
          if (data === "[DONE]") continue;
          try {
            const parsed = JSON.parse(data);
            const delta = parsed.choices?.[0]?.delta?.content;
            if (delta) {
              assistant += delta;
              setMessages((prev) => {
                const copy = [...prev];
                copy[copy.length - 1] = { role: "assistant", content: assistant };
                return copy;
              });
            }
          } catch { /* skip */ }
        }
      }
    } catch (e) {
      toast.error("Erro de conexão com a IA.");
    } finally {
      setLoading(false);
    }
  };

  return (
    <motion.div
      initial={{ opacity: 0, x: 30 }}
      animate={{ opacity: 1, x: 0 }}
      exit={{ opacity: 0, x: 30 }}
      className="fixed inset-0 z-50 bg-background flex flex-col md:inset-auto md:top-4 md:right-4 md:bottom-4 md:w-[400px] md:rounded-2xl md:border md:border-border md:shadow-2xl"
    >
      <div className="flex items-center justify-between px-4 py-3 border-b border-border">
        <div className="flex items-center gap-2">
          <div className="h-9 w-9 rounded-full bg-secondary/20 flex items-center justify-center">
            <Sparkles className="h-4 w-4 text-secondary" />
          </div>
          <div>
            <p className="text-sm font-semibold text-foreground">{title}</p>
            <p className="text-[11px] text-muted-foreground">{subtitle}</p>
          </div>
        </div>
        <button onClick={onClose} className="text-muted-foreground hover:text-foreground transition-colors">
          <X className="h-4 w-4" />
        </button>
      </div>

      <div className="flex-1 overflow-y-auto p-4 space-y-3">
        <AnimatePresence>
          {messages.map((msg, i) => (
            <motion.div
              key={i}
              initial={{ opacity: 0, y: 8 }}
              animate={{ opacity: 1, y: 0 }}
              className={`flex ${msg.role === "user" ? "justify-end" : "justify-start"}`}
            >
              <div
                className={`max-w-[85%] px-3.5 py-2.5 rounded-2xl text-sm leading-relaxed whitespace-pre-wrap ${
                  msg.role === "user"
                    ? "bg-primary text-primary-foreground rounded-br-md"
                    : "bg-muted text-foreground rounded-bl-md"
                }`}
              >
                {msg.content || (loading && i === messages.length - 1 ? <span className="opacity-50">...</span> : "")}
              </div>
            </motion.div>
          ))}
        </AnimatePresence>
        {loading && messages[messages.length - 1]?.role === "user" && (
          <div className="flex justify-start">
            <div className="bg-muted text-muted-foreground rounded-2xl rounded-bl-md px-3.5 py-2.5">
              <Loader2 className="h-4 w-4 animate-spin" />
            </div>
          </div>
        )}
        <div ref={bottomRef} />
      </div>

      <div className="p-3 border-t border-border flex gap-2">
        <Input
          value={input}
          onChange={(e) => setInput(e.target.value)}
          onKeyDown={(e) => e.key === "Enter" && send()}
          placeholder="Pergunte algo..."
          disabled={loading}
          className="flex-1 h-10 rounded-xl bg-muted/50 border-border text-sm"
        />
        <Button onClick={send} disabled={loading || !input.trim()} size="icon" className="h-10 w-10 rounded-xl bg-secondary text-secondary-foreground">
          {loading ? <Loader2 className="h-4 w-4 animate-spin" /> : <Send className="h-4 w-4" />}
        </Button>
      </div>
    </motion.div>
  );
};

export default AIChat;
