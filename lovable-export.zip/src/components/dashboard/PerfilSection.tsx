import { useState, useEffect } from "react";
import { motion } from "framer-motion";
import { User, Mail, Phone, MapPin, Save, Camera, Bell, Lock } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Switch } from "@/components/ui/switch";
import { useToast } from "@/hooks/use-toast";
import SectionHeader from "@/components/dashboard/SectionHeader";

interface ProfileData {
  name: string;
  email: string;
  phone: string;
  city: string;
  notifEmail: boolean;
  notifPush: boolean;
}

const STORAGE_KEY = "mm_profile";

const PerfilSection = ({ defaultName, defaultEmail }: { defaultName: string; defaultEmail?: string }) => {
  const { toast } = useToast();
  const [data, setData] = useState<ProfileData>({
    name: defaultName,
    email: defaultEmail || "usuario@metabolicamente.com",
    phone: "",
    city: "",
    notifEmail: true,
    notifPush: true,
  });

  useEffect(() => {
    try {
      const raw = localStorage.getItem(STORAGE_KEY);
      if (raw) setData(prev => ({ ...prev, ...JSON.parse(raw) }));
    } catch { /* ignore */ }
  }, []);

  const initials = data.name.split(" ").slice(0, 2).map(n => n[0]).join("").toUpperCase();

  const save = () => {
    localStorage.setItem(STORAGE_KEY, JSON.stringify(data));
    localStorage.setItem("mm_user", data.name);
    toast({ title: "Perfil salvo", description: "Suas informações foram atualizadas." });
  };

  return (
    <>
      <SectionHeader title="Meu perfil" subtitle="Suas informações e preferências" />

      <motion.div
        initial={{ opacity: 0, y: 8 }}
        animate={{ opacity: 1, y: 0 }}
        className="bg-card border border-border rounded-2xl p-6 mb-4"
      >
        <div className="flex items-center gap-4 mb-6">
          <div className="relative">
            <div className="h-20 w-20 rounded-full bg-primary/10 flex items-center justify-center">
              <span className="text-xl font-bold text-primary">{initials || "U"}</span>
            </div>
            <button className="absolute -bottom-1 -right-1 h-7 w-7 rounded-full bg-primary text-primary-foreground flex items-center justify-center shadow-sm">
              <Camera className="h-3.5 w-3.5" />
            </button>
          </div>
          <div>
            <p className="font-semibold text-foreground">{data.name}</p>
            <p className="text-xs text-muted-foreground">{data.email}</p>
          </div>
        </div>

        <div className="grid sm:grid-cols-2 gap-4">
          <Field icon={User} label="Nome" value={data.name} onChange={(v) => setData({ ...data, name: v })} />
          <Field icon={Mail} label="E-mail" value={data.email} onChange={(v) => setData({ ...data, email: v })} type="email" />
          <Field icon={Phone} label="Telefone" value={data.phone} onChange={(v) => setData({ ...data, phone: v })} placeholder="(11) 99999-9999" />
          <Field icon={MapPin} label="Cidade" value={data.city} onChange={(v) => setData({ ...data, city: v })} placeholder="São Paulo, SP" />
        </div>
      </motion.div>

      {/* Preferences */}
      <motion.div
        initial={{ opacity: 0, y: 8 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.05 }}
        className="bg-card border border-border rounded-2xl p-6 mb-4"
      >
        <p className="font-semibold text-foreground mb-4 flex items-center gap-2">
          <Bell className="h-4 w-4 text-primary" /> Notificações
        </p>
        <div className="space-y-3">
          <Toggle
            label="Notificações por e-mail"
            description="Lembretes de consulta e atualizações"
            checked={data.notifEmail}
            onChange={(v) => setData({ ...data, notifEmail: v })}
          />
          <Toggle
            label="Notificações no navegador"
            description="Alertas em tempo real"
            checked={data.notifPush}
            onChange={(v) => setData({ ...data, notifPush: v })}
          />
        </div>
      </motion.div>

      <motion.div
        initial={{ opacity: 0, y: 8 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.1 }}
        className="bg-card border border-border rounded-2xl p-6 mb-6"
      >
        <p className="font-semibold text-foreground mb-2 flex items-center gap-2">
          <Lock className="h-4 w-4 text-primary" /> Segurança
        </p>
        <p className="text-xs text-muted-foreground mb-3">
          Mantenha sua conta protegida alterando a senha periodicamente.
        </p>
        <Button variant="outline" size="sm" className="rounded-xl">Alterar senha</Button>
      </motion.div>

      <div className="flex justify-end">
        <Button onClick={save} className="rounded-xl bg-primary text-primary-foreground gap-2">
          <Save className="h-4 w-4" /> Salvar alterações
        </Button>
      </div>
    </>
  );
};

const Field = ({
  icon: Icon, label, value, onChange, type = "text", placeholder,
}: {
  icon: typeof User; label: string; value: string;
  onChange: (v: string) => void; type?: string; placeholder?: string;
}) => (
  <div>
    <label className="text-xs font-medium text-muted-foreground uppercase tracking-wide flex items-center gap-1.5 mb-1.5">
      <Icon className="h-3 w-3" /> {label}
    </label>
    <Input
      type={type}
      value={value}
      onChange={(e) => onChange(e.target.value)}
      placeholder={placeholder}
      className="h-11 rounded-xl"
    />
  </div>
);

const Toggle = ({
  label, description, checked, onChange,
}: {
  label: string; description: string; checked: boolean; onChange: (v: boolean) => void;
}) => (
  <div className="flex items-center justify-between gap-3 p-3 rounded-xl bg-muted/40">
    <div className="min-w-0">
      <p className="text-sm font-medium text-foreground">{label}</p>
      <p className="text-xs text-muted-foreground">{description}</p>
    </div>
    <Switch checked={checked} onCheckedChange={onChange} />
  </div>
);

export default PerfilSection;
