import { ReactNode } from "react";

interface SectionHeaderProps {
  title: string;
  subtitle?: string;
  action?: ReactNode;
}

const SectionHeader = ({ title, subtitle, action }: SectionHeaderProps) => (
  <div className="flex flex-wrap items-end justify-between gap-3 mb-5">
    <div>
      <h1
        className="text-2xl font-bold text-foreground"
        style={{ fontFamily: "'Montserrat', sans-serif" }}
      >
        {title}
      </h1>
      {subtitle && <p className="text-sm text-muted-foreground mt-1">{subtitle}</p>}
    </div>
    {action}
  </div>
);

export default SectionHeader;
