import { motion } from "framer-motion";
import {
  Area, AreaChart, CartesianGrid, Legend, Line, LineChart,
  ResponsiveContainer, Tooltip, XAxis, YAxis,
} from "recharts";
import { Activity, Moon, Heart, TrendingDown } from "lucide-react";

const energyData = [
  { day: "Seg", energia: 5, humor: 6, sono: 7 },
  { day: "Ter", energia: 4, humor: 5, sono: 6 },
  { day: "Qua", energia: 6, humor: 6, sono: 7 },
  { day: "Qui", energia: 5, humor: 7, sono: 8 },
  { day: "Sex", energia: 7, humor: 7, sono: 7 },
  { day: "Sáb", energia: 8, humor: 8, sono: 8 },
  { day: "Dom", energia: 7, humor: 8, sono: 9 },
];

const weightData = [
  { mes: "Out", peso: 92, meta: 80 },
  { mes: "Nov", peso: 90, meta: 80 },
  { mes: "Dez", peso: 88, meta: 80 },
  { mes: "Jan", peso: 86, meta: 80 },
  { mes: "Fev", peso: 84, meta: 80 },
  { mes: "Mar", peso: 82, meta: 80 },
];

const glucoseData = [
  { semana: "S1", glicemia: 124, hba1c: 6.2 },
  { semana: "S3", glicemia: 118, hba1c: 6.0 },
  { semana: "S5", glicemia: 112, hba1c: 5.8 },
  { semana: "S7", glicemia: 105, hba1c: 5.6 },
  { semana: "S9", glicemia: 98, hba1c: 5.4 },
];

const tooltipStyle = {
  backgroundColor: "hsl(var(--background))",
  border: "1px solid hsl(var(--border))",
  borderRadius: "0.75rem",
  fontSize: "12px",
};

const fade = { initial: { opacity: 0, y: 12 }, animate: { opacity: 1, y: 0 } };

const ChartCard = ({ title, subtitle, icon: Icon, children, delay = 0 }: any) => (
  <motion.div {...fade} transition={{ duration: 0.5, delay }} className="bg-card border border-border rounded-2xl p-5">
    <div className="flex items-center gap-3 mb-4">
      <div className="h-9 w-9 rounded-xl bg-primary/10 flex items-center justify-center">
        <Icon className="h-4 w-4 text-primary" />
      </div>
      <div>
        <h3 className="text-sm font-semibold text-foreground">{title}</h3>
        <p className="text-[11px] text-muted-foreground">{subtitle}</p>
      </div>
    </div>
    <div className="h-52">
      <ResponsiveContainer width="100%" height="100%">
        {children}
      </ResponsiveContainer>
    </div>
  </motion.div>
);

const EvolutionCharts = () => {
  return (
    <div className="grid lg:grid-cols-2 gap-4">
      <ChartCard title="Bem-estar — últimos 7 dias" subtitle="Energia, humor e qualidade do sono" icon={Activity}>
        <AreaChart data={energyData}>
          <defs>
            <linearGradient id="g-energia" x1="0" y1="0" x2="0" y2="1">
              <stop offset="0%" stopColor="hsl(var(--primary))" stopOpacity={0.5} />
              <stop offset="100%" stopColor="hsl(var(--primary))" stopOpacity={0} />
            </linearGradient>
            <linearGradient id="g-humor" x1="0" y1="0" x2="0" y2="1">
              <stop offset="0%" stopColor="hsl(var(--secondary))" stopOpacity={0.5} />
              <stop offset="100%" stopColor="hsl(var(--secondary))" stopOpacity={0} />
            </linearGradient>
          </defs>
          <CartesianGrid strokeDasharray="3 3" stroke="hsl(var(--border))" vertical={false} />
          <XAxis dataKey="day" stroke="hsl(var(--muted-foreground))" fontSize={11} tickLine={false} axisLine={false} />
          <YAxis stroke="hsl(var(--muted-foreground))" fontSize={11} tickLine={false} axisLine={false} domain={[0, 10]} />
          <Tooltip contentStyle={tooltipStyle} />
          <Legend wrapperStyle={{ fontSize: 11 }} iconType="circle" />
          <Area type="monotone" dataKey="energia" stroke="hsl(var(--primary))" fill="url(#g-energia)" strokeWidth={2} />
          <Area type="monotone" dataKey="humor" stroke="hsl(var(--secondary))" fill="url(#g-humor)" strokeWidth={2} />
          <Line type="monotone" dataKey="sono" stroke="hsl(var(--accent))" strokeWidth={2} dot={{ r: 3 }} />
        </AreaChart>
      </ChartCard>

      <ChartCard title="Peso — últimos 6 meses" subtitle="Evolução até a meta clínica" icon={TrendingDown} delay={0.1}>
        <LineChart data={weightData}>
          <CartesianGrid strokeDasharray="3 3" stroke="hsl(var(--border))" vertical={false} />
          <XAxis dataKey="mes" stroke="hsl(var(--muted-foreground))" fontSize={11} tickLine={false} axisLine={false} />
          <YAxis stroke="hsl(var(--muted-foreground))" fontSize={11} tickLine={false} axisLine={false} domain={[78, 95]} />
          <Tooltip contentStyle={tooltipStyle} />
          <Legend wrapperStyle={{ fontSize: 11 }} iconType="circle" />
          <Line type="monotone" dataKey="peso" stroke="hsl(var(--primary))" strokeWidth={3} dot={{ r: 4 }} />
          <Line type="monotone" dataKey="meta" stroke="hsl(var(--secondary))" strokeWidth={2} strokeDasharray="5 5" dot={false} />
        </LineChart>
      </ChartCard>

      <ChartCard title="Glicemia em jejum" subtitle="Tendência de melhora ao longo do tratamento" icon={Heart} delay={0.15}>
        <AreaChart data={glucoseData}>
          <defs>
            <linearGradient id="g-glic" x1="0" y1="0" x2="0" y2="1">
              <stop offset="0%" stopColor="hsl(var(--destructive))" stopOpacity={0.4} />
              <stop offset="100%" stopColor="hsl(var(--destructive))" stopOpacity={0} />
            </linearGradient>
          </defs>
          <CartesianGrid strokeDasharray="3 3" stroke="hsl(var(--border))" vertical={false} />
          <XAxis dataKey="semana" stroke="hsl(var(--muted-foreground))" fontSize={11} tickLine={false} axisLine={false} />
          <YAxis stroke="hsl(var(--muted-foreground))" fontSize={11} tickLine={false} axisLine={false} />
          <Tooltip contentStyle={tooltipStyle} />
          <Area type="monotone" dataKey="glicemia" stroke="hsl(var(--destructive))" fill="url(#g-glic)" strokeWidth={2} />
        </AreaChart>
      </ChartCard>

      <ChartCard title="HbA1c (hemoglobina glicada)" subtitle="Indicador de controle glicêmico de longo prazo" icon={Moon} delay={0.2}>
        <LineChart data={glucoseData}>
          <CartesianGrid strokeDasharray="3 3" stroke="hsl(var(--border))" vertical={false} />
          <XAxis dataKey="semana" stroke="hsl(var(--muted-foreground))" fontSize={11} tickLine={false} axisLine={false} />
          <YAxis stroke="hsl(var(--muted-foreground))" fontSize={11} tickLine={false} axisLine={false} domain={[5, 6.5]} />
          <Tooltip contentStyle={tooltipStyle} />
          <Line type="monotone" dataKey="hba1c" stroke="hsl(var(--secondary))" strokeWidth={3} dot={{ r: 4 }} />
        </LineChart>
      </ChartCard>
    </div>
  );
};

export default EvolutionCharts;
