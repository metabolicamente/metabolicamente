import { ReactNode, useState } from "react";
import { Link, useNavigate } from "react-router-dom";
import { motion, AnimatePresence } from "framer-motion";
import { Brain, LogOut, Menu, X, Bell, LucideIcon } from "lucide-react";
import { Button } from "@/components/ui/button";
import { cn } from "@/lib/utils";

export interface DashboardSection {
  id: string;
  label: string;
  icon: LucideIcon;
  badge?: number;
}

interface Notification {
  id: number;
  title: string;
  description: string;
  time: string;
  unread?: boolean;
}

interface DashboardShellProps {
  userName: string;
  role: "medico" | "nutri" | "cliente";
  sections: DashboardSection[];
  currentSection: string;
  onSectionChange: (id: string) => void;
  notifications?: Notification[];
  children: ReactNode;
}

const roleLabels: Record<string, string> = {
  medico: "Médico",
  nutri: "Nutricionista",
  cliente: "Paciente",
};

const DashboardShell = ({
  userName,
  role,
  sections,
  currentSection,
  onSectionChange,
  notifications = [],
  children,
}: DashboardShellProps) => {
  const navigate = useNavigate();
  const [mobileOpen, setMobileOpen] = useState(false);
  const [notifOpen, setNotifOpen] = useState(false);

  const unreadCount = notifications.filter((n) => n.unread).length;

  const handleLogout = () => {
    localStorage.removeItem("mm_role");
    localStorage.removeItem("mm_user");
    navigate("/login");
  };

  const NavItems = ({ onClick }: { onClick?: () => void }) => (
    <>
      {sections.map((s) => {
        const active = s.id === currentSection;
        const Icon = s.icon;
        return (
          <button
            key={s.id}
            onClick={() => {
              onSectionChange(s.id);
              onClick?.();
            }}
            className={cn(
              "w-full flex items-center gap-3 px-3 py-2.5 rounded-xl text-sm font-medium transition-all relative",
              active
                ? "bg-primary text-primary-foreground shadow-sm"
                : "text-foreground/70 hover:text-foreground hover:bg-muted"
            )}
          >
            <Icon className="h-4 w-4 shrink-0" />
            <span className="truncate">{s.label}</span>
            {s.badge ? (
              <span className="ml-auto text-[10px] font-bold px-1.5 py-0.5 rounded-full bg-secondary text-secondary-foreground">
                {s.badge}
              </span>
            ) : null}
          </button>
        );
      })}
    </>
  );

  return (
    <div className="min-h-screen bg-background flex flex-col">
      {/* Top bar */}
      <header className="sticky top-0 z-40 bg-primary text-primary-foreground border-b border-primary/30">
        <div className="px-4 sm:px-6 flex h-14 items-center justify-between gap-3">
          <div className="flex items-center gap-3">
            <button
              className="lg:hidden text-primary-foreground"
              onClick={() => setMobileOpen(true)}
              aria-label="Abrir menu"
            >
              <Menu className="h-5 w-5" />
            </button>
            <Link to="/" className="flex items-center gap-2">
              <Brain className="h-5 w-5" />
              <span
                className="text-base font-bold hidden sm:inline"
                style={{ fontFamily: "'Montserrat', sans-serif" }}
              >
                Metabolicamente
              </span>
            </Link>
          </div>

          <div className="flex items-center gap-2">
            {/* Notifications */}
            <div className="relative">
              <button
                onClick={() => setNotifOpen((v) => !v)}
                className="relative h-9 w-9 rounded-full hover:bg-primary-foreground/10 flex items-center justify-center transition-colors"
                aria-label="Notificações"
              >
                <Bell className="h-4 w-4" />
                {unreadCount > 0 && (
                  <span className="absolute top-1.5 right-1.5 h-4 min-w-[16px] px-1 rounded-full bg-secondary text-secondary-foreground text-[10px] font-bold flex items-center justify-center">
                    {unreadCount}
                  </span>
                )}
              </button>

              <AnimatePresence>
                {notifOpen && (
                  <>
                    <div
                      className="fixed inset-0 z-40"
                      onClick={() => setNotifOpen(false)}
                    />
                    <motion.div
                      initial={{ opacity: 0, y: -8 }}
                      animate={{ opacity: 1, y: 0 }}
                      exit={{ opacity: 0, y: -8 }}
                      className="absolute right-0 mt-2 w-80 max-w-[calc(100vw-2rem)] bg-card text-foreground rounded-2xl shadow-xl border border-border overflow-hidden z-50"
                    >
                      <div className="px-4 py-3 border-b border-border">
                        <p className="text-sm font-semibold">Notificações</p>
                        <p className="text-[11px] text-muted-foreground">
                          {unreadCount > 0
                            ? `${unreadCount} não lida${unreadCount > 1 ? "s" : ""}`
                            : "Tudo em dia"}
                        </p>
                      </div>
                      <div className="max-h-80 overflow-y-auto">
                        {notifications.length === 0 ? (
                          <p className="text-xs text-muted-foreground p-6 text-center">
                            Sem notificações.
                          </p>
                        ) : (
                          notifications.map((n) => (
                            <div
                              key={n.id}
                              className={cn(
                                "px-4 py-3 border-b border-border last:border-0 hover:bg-muted/40 transition-colors",
                                n.unread && "bg-primary/5"
                              )}
                            >
                              <div className="flex items-start gap-2">
                                {n.unread && (
                                  <span className="h-1.5 w-1.5 rounded-full bg-secondary mt-1.5 shrink-0" />
                                )}
                                <div className="flex-1 min-w-0">
                                  <p className="text-sm font-medium leading-tight">
                                    {n.title}
                                  </p>
                                  <p className="text-xs text-muted-foreground mt-0.5">
                                    {n.description}
                                  </p>
                                  <p className="text-[10px] text-muted-foreground mt-1">
                                    {n.time}
                                  </p>
                                </div>
                              </div>
                            </div>
                          ))
                        )}
                      </div>
                    </motion.div>
                  </>
                )}
              </AnimatePresence>
            </div>

            <div className="hidden sm:block text-right pl-2">
              <p className="text-sm font-medium leading-tight">{userName}</p>
              <p className="text-[11px] opacity-80">{roleLabels[role]}</p>
            </div>

            <Button
              variant="ghost"
              size="sm"
              onClick={handleLogout}
              className="text-primary-foreground/80 hover:text-primary-foreground hover:bg-primary-foreground/10 hidden sm:inline-flex"
            >
              <LogOut className="h-4 w-4 sm:mr-1" />
              <span className="hidden sm:inline">Sair</span>
            </Button>
          </div>
        </div>
      </header>

      <div className="flex flex-1 w-full">
        {/* Sidebar desktop */}
        <aside className="hidden lg:flex flex-col w-60 shrink-0 border-r border-border bg-card/40 px-3 py-6 gap-1">
          <p className="text-[10px] uppercase tracking-wider text-muted-foreground font-semibold px-3 mb-2">
            Painel
          </p>
          <NavItems />
          <div className="mt-auto pt-4 border-t border-border">
            <Button
              variant="ghost"
              size="sm"
              onClick={handleLogout}
              className="w-full justify-start text-muted-foreground hover:text-foreground"
            >
              <LogOut className="h-4 w-4 mr-2" /> Sair
            </Button>
          </div>
        </aside>

        {/* Mobile drawer */}
        <AnimatePresence>
          {mobileOpen && (
            <>
              <motion.div
                initial={{ opacity: 0 }}
                animate={{ opacity: 1 }}
                exit={{ opacity: 0 }}
                onClick={() => setMobileOpen(false)}
                className="fixed inset-0 z-50 bg-foreground/40 lg:hidden"
              />
              <motion.aside
                initial={{ x: "-100%" }}
                animate={{ x: 0 }}
                exit={{ x: "-100%" }}
                transition={{ type: "spring", damping: 28, stiffness: 240 }}
                className="fixed top-0 left-0 bottom-0 z-50 w-72 bg-background border-r border-border p-4 flex flex-col gap-1 lg:hidden"
              >
                <div className="flex items-center justify-between mb-4">
                  <div>
                    <p className="text-sm font-semibold">{userName}</p>
                    <p className="text-[11px] text-muted-foreground">{roleLabels[role]}</p>
                  </div>
                  <button onClick={() => setMobileOpen(false)} aria-label="Fechar">
                    <X className="h-5 w-5 text-muted-foreground" />
                  </button>
                </div>
                <NavItems onClick={() => setMobileOpen(false)} />
                <div className="mt-auto pt-4 border-t border-border">
                  <Button
                    variant="ghost"
                    size="sm"
                    onClick={handleLogout}
                    className="w-full justify-start text-muted-foreground hover:text-foreground"
                  >
                    <LogOut className="h-4 w-4 mr-2" /> Sair
                  </Button>
                </div>
              </motion.aside>
            </>
          )}
        </AnimatePresence>

        {/* Main */}
        <main className="flex-1 min-w-0">
          <div className="px-4 sm:px-6 py-6 md:py-8 pb-24 lg:pb-8 max-w-5xl mx-auto w-full">
            <AnimatePresence mode="wait">
              <motion.div
                key={currentSection}
                initial={{ opacity: 0, y: 8 }}
                animate={{ opacity: 1, y: 0 }}
                exit={{ opacity: 0, y: -8 }}
                transition={{ duration: 0.25 }}
              >
                {children}
              </motion.div>
            </AnimatePresence>
          </div>
        </main>
      </div>

      {/* Bottom tabs mobile */}
      <nav className="lg:hidden fixed bottom-0 left-0 right-0 z-30 bg-card/95 backdrop-blur border-t border-border">
        <div className="flex items-center justify-around px-1 py-1.5">
          {sections.slice(0, 5).map((s) => {
            const active = s.id === currentSection;
            const Icon = s.icon;
            return (
              <button
                key={s.id}
                onClick={() => onSectionChange(s.id)}
                className={cn(
                  "flex-1 flex flex-col items-center gap-0.5 py-1.5 rounded-lg transition-colors relative",
                  active ? "text-primary" : "text-muted-foreground"
                )}
              >
                <Icon className="h-5 w-5" />
                <span className="text-[10px] font-medium leading-none">{s.label}</span>
                {s.badge ? (
                  <span className="absolute top-0.5 right-1/4 h-3.5 min-w-[14px] px-1 rounded-full bg-secondary text-secondary-foreground text-[9px] font-bold flex items-center justify-center">
                    {s.badge}
                  </span>
                ) : null}
                {active && (
                  <motion.div
                    layoutId="bottom-tab-indicator"
                    className="absolute -top-1.5 h-1 w-8 rounded-full bg-primary"
                  />
                )}
              </button>
            );
          })}
        </div>
      </nav>
    </div>
  );
};

export default DashboardShell;
