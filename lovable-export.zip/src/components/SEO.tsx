import { useEffect } from "react";
import { useLocation } from "react-router-dom";

interface SEOProps {
  title: string;
  description?: string;
  canonical?: string;
  jsonLd?: Record<string, unknown>;
}

const ensureMeta = (selector: string, attrs: Record<string, string>) => {
  let el = document.head.querySelector<HTMLElement>(selector);
  if (!el) {
    el = document.createElement(attrs.tag || "meta");
    document.head.appendChild(el);
  }
  Object.entries(attrs).forEach(([k, v]) => {
    if (k === "tag") return;
    el!.setAttribute(k, v);
  });
  return el;
};

const SEO = ({ title, description, canonical, jsonLd }: SEOProps) => {
  const location = useLocation();
  const fullTitle = title.length > 60 ? title.slice(0, 57) + "..." : title;
  const desc = description?.slice(0, 160);
  const url = canonical ?? `${window.location.origin}${location.pathname}`;

  useEffect(() => {
    document.title = fullTitle;

    if (desc) {
      ensureMeta('meta[name="description"]', { tag: "meta", name: "description", content: desc });
      ensureMeta('meta[property="og:description"]', { tag: "meta", property: "og:description", content: desc });
    }
    ensureMeta('meta[property="og:title"]', { tag: "meta", property: "og:title", content: fullTitle });
    ensureMeta('meta[property="og:type"]', { tag: "meta", property: "og:type", content: "website" });
    ensureMeta('meta[property="og:url"]', { tag: "meta", property: "og:url", content: url });
    ensureMeta('meta[name="twitter:card"]', { tag: "meta", name: "twitter:card", content: "summary_large_image" });

    let link = document.head.querySelector<HTMLLinkElement>('link[rel="canonical"]');
    if (!link) {
      link = document.createElement("link");
      link.rel = "canonical";
      document.head.appendChild(link);
    }
    link.href = url;

    let scriptEl: HTMLScriptElement | null = null;
    if (jsonLd) {
      scriptEl = document.createElement("script");
      scriptEl.type = "application/ld+json";
      scriptEl.text = JSON.stringify(jsonLd);
      scriptEl.dataset.seo = "true";
      document.head.appendChild(scriptEl);
    }
    return () => {
      if (scriptEl) scriptEl.remove();
    };
  }, [fullTitle, desc, url, jsonLd]);

  return null;
};

export default SEO;
