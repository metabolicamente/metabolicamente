import { useEffect, useRef } from 'react';

interface OrganicGradientProps {
  subtle?: boolean;
}

const OrganicGradient = ({ subtle = false }: OrganicGradientProps) => {
  const canvasRef = useRef<HTMLCanvasElement>(null);

  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    let raf: number;
    let w = 0, h = 0;

    const resize = () => {
      const parent = canvas.parentElement;
      if (!parent) return;
      const dpr = window.devicePixelRatio || 1;
      w = parent.clientWidth;
      h = parent.clientHeight;
      canvas.width = w * dpr;
      canvas.height = h * dpr;
      canvas.style.width = `${w}px`;
      canvas.style.height = `${h}px`;
      ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
    };

    const opacity = subtle ? 0.25 : 0.5;

    const draw = (t: number) => {
      ctx.clearRect(0, 0, w, h);

      const blobs = [
        { x: 0.3, y: 0.3, r: 0.4, color: [42, 90, 70], speed: 0.0003, phase: 0 },
        { x: 0.7, y: 0.6, r: 0.35, color: [95, 170, 65], speed: 0.00025, phase: 2 },
        { x: 0.5, y: 0.8, r: 0.3, color: [45, 90, 76], speed: 0.00035, phase: 4 },
        { x: 0.2, y: 0.7, r: 0.25, color: [55, 110, 80], speed: 0.0002, phase: 1 },
        { x: 0.8, y: 0.3, r: 0.3, color: [35, 75, 60], speed: 0.00028, phase: 3 },
      ];

      for (const blob of blobs) {
        const bx = (blob.x + Math.sin(t * blob.speed + blob.phase) * 0.08) * w;
        const by = (blob.y + Math.cos(t * blob.speed * 0.7 + blob.phase) * 0.06) * h;
        const br = blob.r * Math.min(w, h);

        const grad = ctx.createRadialGradient(bx, by, 0, bx, by, br);
        grad.addColorStop(0, `rgba(${blob.color.join(',')}, ${opacity})`);
        grad.addColorStop(0.5, `rgba(${blob.color.join(',')}, ${opacity * 0.3})`);
        grad.addColorStop(1, `rgba(${blob.color.join(',')}, 0)`);
        ctx.fillStyle = grad;
        ctx.fillRect(0, 0, w, h);
      }

      raf = requestAnimationFrame(draw);
    };

    window.addEventListener('resize', resize);
    resize();
    raf = requestAnimationFrame(draw);

    return () => {
      cancelAnimationFrame(raf);
      window.removeEventListener('resize', resize);
    };
  }, [subtle]);

  return <canvas ref={canvasRef} className="absolute inset-0 w-full h-full" />;
};

export default OrganicGradient;
