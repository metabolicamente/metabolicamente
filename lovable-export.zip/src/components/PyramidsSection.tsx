import { motion, useInView } from "framer-motion";
import { useRef, useState } from "react";
import WaveDivider from "@/components/shared/WaveDivider";

const conventionalLayers = [
  { label: "Sono, Dieta\ne Exercício", shortDesc: "Fatores gerais de estilo de vida, frequentemente negligenciados como secundários ao tratamento farmacológico.", bg: "hsl(0, 0%, 12%)", color: "#fff" },
  { label: "Terapia", shortDesc: "Utilizada como suporte complementar, sem integração com a biologia do paciente.", bg: "hsl(0, 0%, 28%)", color: "#fff" },
  { label: "Medicação", shortDesc: "Foco principal no controle dos sintomas através de psicofármacos.", bg: "hsl(0, 0%, 45%)", color: "#fff" },
];

const metabolicLayers = [
  { label: "Terapia e\nMedicação", shortDesc: "Uso de medicação e outras estratégias quando necessário, atuando sobre os sintomas enquanto a base biológica é reconstruída.", bg: "hsl(153, 37%, 22%)", color: "#fff" },
  { label: "Movimento", shortDesc: "Atividade física como ferramenta para regular o humor, melhorar a função do cérebro e aumentar a capacidade de lidar com o estresse.", bg: "hsl(153, 37%, 30%)", color: "#fff" },
  { label: "Ritmos\nCircadianos", shortDesc: "Regulação do sono, da luz e dos horários biológicos para alinhar hormônios, energia e funcionamento do cérebro ao ciclo natural do dia.", bg: "hsl(153, 37%, 38%)", color: "#fff" },
  { label: "Nutrição\nTerapêutica", shortDesc: "Uso estratégico da alimentação para restaurar o metabolismo cerebral, reduzir inflamação e fornecer os nutrientes essenciais ao funcionamento da mente.", bg: "hsl(153, 37%, 18%)", color: "#fff" },
];


const Pyramid = ({
  layers,
  title,
  glow,
  delay,
  activeLayer,
  onHover







}: {layers: typeof conventionalLayers;title: string;glow?: boolean;delay: number;activeLayer: number | null;onHover: (i: number | null) => void;}) => {
  const total = layers.length;

  return (
    <motion.div
      className="flex flex-col items-center gap-1 w-full max-w-[400px] mx-auto"
      initial={{ opacity: 0, y: 40 }}
      whileInView={{ opacity: 1, y: 0 }}
      viewport={{ once: true, margin: "-80px" }}
      transition={{ duration: 0.8, delay }}>
      
      <div
        className="w-full flex flex-col items-center gap-[3px]"
        style={glow ? { filter: "drop-shadow(0 0 32px hsla(153, 37%, 25%, 0.35))" } : {}}>

        {layers.map((layer, i) => {
          const topW = 18 + i * (82 / total);
          const botW = 18 + (i + 1) * (82 / total);
          const isActive = activeLayer === i;
          return (
            <motion.div
              key={i}
              className="relative flex items-center justify-center text-center cursor-pointer transition-all duration-300"
              style={{
                clipPath: `polygon(${(100 - topW) / 2}% 0%, ${100 - (100 - topW) / 2}% 0%, ${100 - (100 - botW) / 2}% 100%, ${(100 - botW) / 2}% 100%)`,
                background: layer.bg,
                color: layer.color,
                width: "100%",
                minHeight: "85px",
                transform: isActive ? "scale(1.06)" : "scale(1)",
                filter: isActive ? "brightness(1.25)" : "brightness(1)"
              }}
              onMouseEnter={() => onHover(i)}
              onMouseLeave={() => onHover(null)}
              whileHover={{ scale: 1.06 }}>
              
              <span className="text-[11px] md:text-sm font-semibold uppercase tracking-wider whitespace-pre-line leading-tight px-8">
                {layer.label}
              </span>
            </motion.div>);

        })}
      </div>
      <p
        className="mt-6 text-sm md:text-base font-bold tracking-widest uppercase text-center"
        style={{ fontFamily: "'Montserrat', sans-serif", color: glow ? "hsl(153, 37%, 25%)" : "hsl(0,0%,30%)" }}>
        
        {title}
      </p>
    </motion.div>);

};

const PyramidsSection = () => {
  const ref = useRef(null);
  useInView(ref, { once: true, margin: "-100px" });
  const [activeConv, setActiveConv] = useState<number | null>(null);
  const [activeMeta, setActiveMeta] = useState<number | null>(null);

  const activeDesc = activeMeta !== null ?
  metabolicLayers[activeMeta].shortDesc :
  activeConv !== null ?
  conventionalLayers[activeConv].shortDesc :
  null;

  return (
    <>
      <section className="bg-muted py-24 md:py-32 lg:py-40" ref={ref}>
        <div className="container">
          <motion.div
            className="text-center mb-20"
            initial={{ opacity: 0, y: 30 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.8 }}>
            
            <h2 className="text-3xl md:text-5xl lg:text-6xl font-bold text-primary mb-6 leading-tight">O que é Psiquiatria Metabólica?

            </h2>
            <p className="text-muted-foreground text-lg md:text-xl leading-relaxed max-w-2xl mx-auto">Uma abordagem que compreende a saúde mental como resultado do metabolismo cerebral, integrando processos biológicos ao tratamento de transtornos psiquiátricos.
            </p>
          </motion.div>

          <div className="flex flex-col sm:flex-row items-end justify-center gap-12 sm:gap-16 lg:gap-24">
            <Pyramid layers={conventionalLayers} title="Abordagem Convencional" delay={0.2} activeLayer={activeConv} onHover={setActiveConv} />
            <Pyramid layers={metabolicLayers} title="Abordagem Metabólica" glow delay={0.5} activeLayer={activeMeta} onHover={setActiveMeta} />
          </div>

          {/* Tooltip description area — bigger */}
          <div className="h-20 flex items-center justify-center mt-10">
            <motion.p
              key={activeDesc || "empty"}
              className="text-base md:text-lg text-muted-foreground text-center max-w-lg italic leading-relaxed"
              initial={{ opacity: 0, y: 8 }}
              animate={{ opacity: activeDesc ? 1 : 0, y: activeDesc ? 0 : 8 }}
              transition={{ duration: 0.3 }}>
              
              {activeDesc || "\u00A0"}
            </motion.p>
          </div>
        </div>
      </section>
      <WaveDivider fillColor="hsl(153, 37%, 18%)" />
    </>);

};

export default PyramidsSection;