import { useEffect, useRef } from 'react';

const MetabolicCanvas = () => {
  const canvasRef = useRef<HTMLCanvasElement>(null);

  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    const COLOR = [57, 122, 74];
    const mouse = { x: -9999, y: -9999 };
    let raf: number;
    const NEURON_COUNT = 200;
    const CONNECTION_DIST = 120;
    const MOUSE_RADIUS = 140;

    interface Neuron {
      x: number; y: number;
      baseX: number; baseY: number;
      vx: number; vy: number;
      r: number;
      offsetX: number; offsetY: number;
      speedX: number; speedY: number;
      phase: number;
    }

    let neurons: Neuron[] = [];
    let w = 0, h = 0;

    const init = () => {
      const parent = canvas.parentElement;
      if (!parent) return;

      const dpr = window.devicePixelRatio || 1;
      w = parent.clientWidth;
      h = parent.clientHeight;
      canvas.width = w * dpr;
      canvas.height = h * dpr;
      canvas.style.width = `${w}px`;
      canvas.style.height = `${h}px`;
      ctx.setTransform(dpr, 0, 0, dpr, 0, 0);

      const padX = w * 0.06;
      const padY = h * 0.06;

      neurons = [];
      for (let i = 0; i < NEURON_COUNT; i++) {
        const x = padX + Math.random() * (w - padX * 2);
        const y = padY + Math.random() * (h - padY * 2);
        neurons.push({
          x, y,
          baseX: x, baseY: y,
          vx: 0, vy: 0,
          r: 1.5 + Math.random() * 1.5,
          offsetX: Math.random() * 1000,
          offsetY: Math.random() * 1000,
          speedX: 0.0002 + Math.random() * 0.0003,
          speedY: 0.0002 + Math.random() * 0.0003,
          phase: Math.random() * Math.PI * 2,
        });
      }
    };

    const draw = (ts: number) => {
      if (!ctx) return;
      ctx.clearRect(0, 0, w, h);

      // Breathing opacity for connections (~6s cycle)
      const breathe = 0.5 + 0.5 * Math.sin(ts * 0.001);

      // Update positions with slow organic drift
      for (const n of neurons) {
        // Organic float using sine waves
        const driftX = Math.sin(ts * n.speedX + n.offsetX) * 18;
        const driftY = Math.cos(ts * n.speedY + n.offsetY) * 14;

        let targetX = n.baseX + driftX;
        let targetY = n.baseY + driftY;

        // Mouse repulsion (subtle)
        const dx = targetX - mouse.x;
        const dy = targetY - mouse.y;
        const dm = Math.hypot(dx, dy);
        if (dm < MOUSE_RADIUS && dm > 0) {
          const force = (1 - dm / MOUSE_RADIUS) * 30;
          targetX += (dx / dm) * force;
          targetY += (dy / dm) * force;
        }

        // Smooth easing toward target
        n.x += (targetX - n.x) * 0.04;
        n.y += (targetY - n.y) * 0.04;
      }

      // Draw connections
      ctx.lineCap = 'round';
      for (let i = 0; i < neurons.length; i++) {
        const a = neurons[i];
        for (let j = i + 1; j < neurons.length; j++) {
          const b = neurons[j];
          const d = Math.hypot(a.x - b.x, a.y - b.y);
          if (d < CONNECTION_DIST) {
            const proximity = 1 - d / CONNECTION_DIST;
            const alpha = proximity * (0.15 + breathe * 0.12);
            ctx.beginPath();
            ctx.moveTo(a.x, a.y);
            ctx.lineTo(b.x, b.y);
            ctx.strokeStyle = `rgba(${COLOR},${alpha})`;
            ctx.lineWidth = 0.5;
            ctx.stroke();
          }
        }
      }

      // Draw neurons
      for (const n of neurons) {
        ctx.beginPath();
        ctx.arc(n.x, n.y, n.r, 0, Math.PI * 2);
        ctx.fillStyle = `rgba(${COLOR},0.65)`;
        ctx.fill();
      }

      raf = requestAnimationFrame(draw);
    };

    const onMove = (e: MouseEvent) => {
      const rect = canvas.getBoundingClientRect();
      mouse.x = e.clientX - rect.left;
      mouse.y = e.clientY - rect.top;
    };
    const onLeave = () => { mouse.x = -9999; mouse.y = -9999; };

    canvas.addEventListener('mousemove', onMove);
    canvas.addEventListener('mouseleave', onLeave);
    window.addEventListener('resize', init);
    init();
    raf = requestAnimationFrame(draw);

    return () => {
      cancelAnimationFrame(raf);
      canvas.removeEventListener('mousemove', onMove);
      canvas.removeEventListener('mouseleave', onLeave);
      window.removeEventListener('resize', init);
    };
  }, []);

  return <canvas ref={canvasRef} className="absolute inset-0 w-full h-full" />;
};

export default MetabolicCanvas;
