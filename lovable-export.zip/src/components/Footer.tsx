import { Link } from "react-router-dom";
import { Brain, Instagram, Facebook, Linkedin, Mail, Phone } from "lucide-react";

const Footer = () => {
  const year = new Date().getFullYear();

  return (
    <footer className="bg-primary text-primary-foreground">
      <div className="container py-12 md:py-16">
        <div className="grid grid-cols-1 md:grid-cols-4 gap-10">
          <div>
            <Link to="/" className="flex items-center gap-2 mb-4">
              <Brain className="h-6 w-6 text-background" />
              <span className="text-lg font-bold" style={{ fontFamily: "'Montserrat', sans-serif" }}><span className="text-lg font-bold" style={{ fontFamily: "'Montserrat', sans-serif" }}>Metabolicamente</span></span>
            </Link>
            <p className="text-sm text-primary-foreground/60 leading-relaxed">
              Cuidando da sua saúde mental com uma abordagem metabólica integrativa e baseada em evidências.
            </p>
          </div>

          <div>
            <h4 className="font-semibold mb-4 text-sm uppercase tracking-wider text-primary-foreground/40" style={{ fontFamily: "'Montserrat', sans-serif" }}>Institucional</h4>
            <nav className="flex flex-col gap-2">
              {[{ label: "Sobre", href: "/sobre" }, { label: "Equipe", href: "/equipe" }].map((l) => (
                <Link key={l.href} to={l.href} className="text-sm text-primary-foreground/60 hover:text-primary-foreground transition-colors">{l.label}</Link>
              ))}
            </nav>
          </div>

          <div>
            <h4 className="font-semibold mb-4 text-sm uppercase tracking-wider text-primary-foreground/40" style={{ fontFamily: "'Montserrat', sans-serif" }}>Para clientes</h4>
            <nav className="flex flex-col gap-2">
              {[{ label: "Dúvidas frequentes", href: "/faq" }, { label: "Conteúdo", href: "/conteudo" }, { label: "Pesquisa", href: "/pesquisa" }, { label: "Comece aqui", href: "/avaliacao" }].map((l) => (
                <Link key={l.href} to={l.href} className="text-sm text-primary-foreground/60 hover:text-primary-foreground transition-colors">{l.label}</Link>
              ))}
            </nav>
          </div>

          <div>
            <h4 className="font-semibold mb-4 text-sm uppercase tracking-wider text-primary-foreground/40" style={{ fontFamily: "'Montserrat', sans-serif" }}>Contato</h4>
            <div className="flex flex-col gap-3 text-sm text-primary-foreground/60">
              <a href="mailto:contato@mentemetabolica.com.br" className="flex items-center gap-2 hover:text-primary-foreground transition-colors">
                <Mail className="h-4 w-4" /> contato@mentemetabolica.com.br
              </a>
              <a href="tel:+5511999999999" className="flex items-center gap-2 hover:text-primary-foreground transition-colors">
                <Phone className="h-4 w-4" /> (11) 99999-9999
              </a>
              <div className="flex gap-3 mt-2">
                <a href="#" aria-label="Instagram" className="text-primary-foreground/40 hover:text-accent transition-colors"><Instagram className="h-5 w-5" /></a>
                <a href="#" aria-label="Facebook" className="text-primary-foreground/40 hover:text-accent transition-colors"><Facebook className="h-5 w-5" /></a>
                <a href="#" aria-label="LinkedIn" className="text-primary-foreground/40 hover:text-accent transition-colors"><Linkedin className="h-5 w-5" /></a>
              </div>
            </div>
          </div>
        </div>

        <div className="border-t border-primary-foreground/10 mt-10 pt-6 text-center text-xs text-primary-foreground/40">
          © {year} MenteMetabólica. Todos os direitos reservados.
        </div>
      </div>
    </footer>
  );
};

export default Footer;
