import { motion } from "framer-motion";
import { useState } from "react";
import { Link } from "react-router-dom";
import { ArrowRight } from "lucide-react";
import { Button } from "@/components/ui/button";
import WaveDivider from "@/components/shared/WaveDivider";

const faqs = [
  {
    question: "O que é psiquiatria metabólica?",
    answer: "É uma abordagem que investiga e trata as causas biológicas subjacentes aos transtornos mentais — como disfunção mitocondrial, resistência à insulina e inflamação crônica — integrando nutrição, exercício e ritmos circadianos ao tratamento psiquiátrico.",
  },
  {
    question: "Qual o papel da dieta cetogênica na saúde mental?",
    answer: "A dieta cetogênica tem sido estudada como intervenção terapêutica em psiquiatria por seu potencial de melhorar o metabolismo energético cerebral, reduzir a neuroinflamação e estabilizar a função dos neurotransmissores. Ensaios clínicos recentes mostram resultados promissores em condições como transtorno bipolar e esquizofrenia.",
  },
  {
    question: "É necessário parar com a medicação atual?",
    answer: "Não necessariamente. O tratamento é complementar e focado na redução progressiva sob supervisão médica. Nosso objetivo é alcançar estabilidade biológica para que, quando possível, a carga medicamentosa possa ser ajustada com segurança.",
  },
  {
    question: "O que é inflamação cerebral?",
    answer: "É um processo inflamatório crônico no sistema nervoso central que pode afetar a função dos neurotransmissores e a saúde das células cerebrais. Fatores como dieta inadequada, sedentarismo, estresse crônico e distúrbios metabólicos podem contribuir para esse quadro, agravando sintomas psiquiátricos.",
  },
  {
    question: "Quanto tempo para ver os primeiros resultados?",
    answer: "Os primeiros sinais de melhora costumam ser percebidos entre 4 a 8 semanas, dependendo do quadro clínico e da adesão ao plano de intervenção. Mudanças no sono, energia e clareza mental geralmente são os primeiros indicadores de progresso.",
  },
  {
    question: "Qual a diferença entre psiquiatria metabólica e convencional?",
    answer: "A psiquiatria convencional foca principalmente no manejo farmacológico dos sintomas. A abordagem metabólica investiga e trata as causas biológicas subjacentes — como disfunção mitocondrial, resistência à insulina e inflamação crônica — integrando nutrição, exercício e ritmos circadianos ao tratamento.",
  },
];

const FAQItem = ({ question, answer, index }: { question: string; answer: string; index: number }) => {
  const [open, setOpen] = useState(false);

  return (
    <motion.div
      className="border-b border-border"
      initial={{ opacity: 0, y: 20 }}
      whileInView={{ opacity: 1, y: 0 }}
      viewport={{ once: true }}
      transition={{ duration: 0.5, delay: index * 0.1 }}
    >
      <button className="w-full flex items-center justify-between py-6 text-left group" onClick={() => setOpen(!open)}>
        <span className="text-lg md:text-xl font-medium text-foreground pr-4">{question}</span>
        <span className="relative flex-shrink-0 w-8 h-8 flex items-center justify-center">
          <motion.span className="absolute w-5 h-[1.5px] bg-primary rounded-full" animate={{ rotate: open ? 45 : 0 }} transition={{ duration: 0.3, ease: "easeInOut" }} />
          <motion.span className="absolute w-5 h-[1.5px] bg-primary rounded-full" animate={{ rotate: open ? -45 : 90 }} transition={{ duration: 0.3, ease: "easeInOut" }} />
        </span>
      </button>
      <motion.div className="overflow-hidden" initial={false} animate={{ height: open ? "auto" : 0, opacity: open ? 1 : 0 }} transition={{ duration: 0.35, ease: "easeInOut" }}>
        <p className="pb-6 text-muted-foreground leading-relaxed max-w-2xl">{answer}</p>
      </motion.div>
    </motion.div>
  );
};

const FAQSection = () => (
  <>
    <WaveDivider fillColor="#F7F0E5" />
    <section className="py-20 md:py-28 lg:py-36" style={{ background: "#F7F0E5" }}>
      <div className="container max-w-3xl">
        <motion.div
          className="text-center mb-14"
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.7 }}
        >
          <h2 className="text-3xl md:text-4xl lg:text-5xl font-bold text-primary mb-4">Dúvidas Frequentes</h2>
          <p className="text-muted-foreground text-base md:text-lg">As perguntas mais comuns sobre a abordagem metabólica.</p>
        </motion.div>

        <div className="mb-16">
          {faqs.map((faq, i) => (
            <FAQItem key={i} question={faq.question} answer={faq.answer} index={i} />
          ))}
        </div>

        {/* Final CTA */}
        <motion.div
          className="text-center"
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.7, delay: 0.2 }}
        >
          <p className="text-muted-foreground text-lg mb-6">Pronto para dar o próximo passo?</p>
          <Button
            size="lg"
            asChild
            className="group bg-primary text-primary-foreground hover:bg-primary/90 text-base px-10 py-7 text-lg rounded-full hover:shadow-xl hover:shadow-primary/20 transition-all duration-500 ease-out hover:scale-105"
          >
            <Link to="/avaliacao">
              Iniciar sua jornada
              <ArrowRight className="ml-2 h-5 w-5 transition-transform duration-300 ease-out group-hover:translate-x-1.5" />
            </Link>
          </Button>
        </motion.div>
      </div>
    </section>
  </>
);

export default FAQSection;
