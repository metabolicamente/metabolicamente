import { motion } from "framer-motion";
import OrganicGradient from "@/components/OrganicGradient";

type HeroVariant = "default" | "organic" | "radial" | "mesh" | "aurora";

interface StandardHeroProps {
  eyebrow?: string;
  title: string;
  description: string;
  children?: React.ReactNode;
  variant?: HeroVariant;
}

const VariantBackground = ({ variant }: { variant: HeroVariant }) => {
  switch (variant) {
    case "organic":
      return (
        <div className="absolute inset-0">
          <OrganicGradient />
        </div>
      );

    case "radial":
      return (
        <div className="absolute inset-0">
          <div className="absolute top-1/4 -left-20 w-[500px] h-[500px] rounded-full opacity-30 animate-[pulse_8s_ease-in-out_infinite]"
            style={{ background: "radial-gradient(circle, hsla(100,46%,46%,0.3) 0%, transparent 70%)" }} />
          <div className="absolute -bottom-20 right-1/4 w-[600px] h-[600px] rounded-full opacity-25 animate-[pulse_10s_ease-in-out_infinite_1s]"
            style={{ background: "radial-gradient(circle, hsla(153,37%,35%,0.4) 0%, transparent 70%)" }} />
          <div className="absolute top-1/3 right-10 w-[300px] h-[300px] rounded-full opacity-20 animate-[pulse_7s_ease-in-out_infinite_2s]"
            style={{ background: "radial-gradient(circle, hsla(36,50%,93%,0.1) 0%, transparent 70%)" }} />
        </div>
      );

    case "mesh":
      return (
        <div className="absolute inset-0">
          <div className="absolute inset-0" style={{
            background: `
              radial-gradient(ellipse at 20% 50%, hsla(153,40%,30%,0.6) 0%, transparent 50%),
              radial-gradient(ellipse at 80% 20%, hsla(100,46%,35%,0.4) 0%, transparent 50%),
              radial-gradient(ellipse at 60% 80%, hsla(153,37%,22%,0.5) 0%, transparent 50%),
              radial-gradient(ellipse at 40% 30%, hsla(36,50%,60%,0.08) 0%, transparent 40%)
            `
          }} />
        </div>
      );

    case "aurora":
      return (
        <div className="absolute inset-0 overflow-hidden">
          <div className="absolute -top-1/2 left-0 w-full h-[200%] opacity-30" style={{
            background: `
              linear-gradient(135deg, hsla(153,50%,25%,0.5) 0%, transparent 40%),
              linear-gradient(225deg, hsla(100,46%,40%,0.3) 0%, transparent 40%),
              linear-gradient(315deg, hsla(153,37%,20%,0.4) 10%, transparent 50%)
            `
          }} />
          <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[700px] h-[400px] rounded-full opacity-20 blur-3xl"
            style={{ background: "hsla(100,46%,46%,0.3)" }} />
        </div>
      );

    default:
      return (
        <div className="absolute inset-0">
          <div className="absolute top-1/3 left-1/4 w-[400px] h-[400px] rounded-full opacity-15 blur-3xl"
            style={{ background: "hsla(100,46%,46%,0.4)" }} />
          <div className="absolute bottom-1/4 right-1/3 w-[350px] h-[350px] rounded-full opacity-10 blur-3xl"
            style={{ background: "hsla(153,37%,35%,0.3)" }} />
        </div>
      );
  }
};

const StandardHero = ({ eyebrow, title, description, children, variant = "default" }: StandardHeroProps) => (
  <section className="relative py-24 md:py-32 overflow-hidden" style={{ background: "hsl(var(--hero-bg))" }}>
    <VariantBackground variant={variant} />
    <div className="container relative z-10 text-center">
      {eyebrow && (
        <motion.p
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6 }}
          className="text-sm uppercase tracking-[0.3em] mb-4"
          style={{ color: "hsl(var(--hero-foreground) / 0.6)", fontFamily: "'Montserrat', sans-serif" }}>
          {eyebrow}
        </motion.p>
      )}
      <motion.h1
        initial={{ opacity: 0, y: 30 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.7, delay: 0.1 }}
        className="text-4xl md:text-6xl font-bold mb-6"
        style={{ color: "hsl(var(--hero-foreground))", fontFamily: "'Montserrat', sans-serif" }}>
        {title}
      </motion.h1>
      <motion.p
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.7, delay: 0.2 }}
        className="text-lg md:text-xl max-w-2xl mx-auto leading-relaxed"
        style={{ color: "hsl(var(--hero-foreground) / 0.8)" }}>
        {description}
      </motion.p>
      {children && (
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.7, delay: 0.3 }}
          className="mt-8"
        >
          {children}
        </motion.div>
      )}
    </div>
  </section>
);

export default StandardHero;
