interface WaveDividerProps {
  fillClass?: string;
  fillColor?: string;
  flip?: boolean;
  heightClass?: string;
}

const WaveDivider = ({ fillClass, fillColor, flip, heightClass = "h-8 md:h-10" }: WaveDividerProps) => (
  <div className={`relative -mb-px overflow-hidden ${heightClass} ${flip ? 'rotate-180' : ''}`}>
    <svg viewBox="0 0 1440 80" fill="none" xmlns="http://www.w3.org/2000/svg" className="w-full h-full block" preserveAspectRatio="none">
      <path
        d="M0,40 C360,80 720,0 1080,40 C1260,60 1380,50 1440,40 L1440,80 L0,80 Z"
        className={fillClass}
        fill={fillColor}
      />
    </svg>
  </div>
);

export default WaveDivider;
