import { Link } from "react-router-dom";
import { ArrowRight } from "lucide-react";
import { Button } from "@/components/ui/button";
import { motion } from "framer-motion";
import OrganicGradient from "@/components/OrganicGradient";
import WaveDivider from "@/components/shared/WaveDivider";

const HeroSection = () => (
  <>
    <section className="relative overflow-hidden min-h-[90vh] flex items-center" style={{ background: "hsl(153, 37%, 18%)" }}>
      {/* Organic bio-gradient background */}
      <div className="absolute inset-0">
        <OrganicGradient />
      </div>

      {/* Content */}
      <div className="container relative z-10 py-24 md:py-32 lg:py-40">
        <div className="max-w-3xl mx-auto text-center lg:text-left lg:mx-0">
          <motion.p
            className="text-sm uppercase tracking-[0.35em] mb-6 text-primary-foreground/50"
            style={{ fontFamily: "'Montserrat', sans-serif" }}
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8, delay: 0.2 }}
          >
            Psiquiatria Metabólica
          </motion.p>
          <motion.h1
            className="text-5xl md:text-6xl lg:text-[5.5rem] font-bold mb-8 leading-[1.05] text-primary-foreground"
            style={{ fontFamily: "'Montserrat', sans-serif", letterSpacing: "-0.02em" }}
            initial={{ opacity: 0, y: 30 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 1, ease: "easeOut", delay: 0.4 }}
          >
            Uma nova abordagem para a saúde mental.
          </motion.h1>
          <motion.p
            className="text-lg md:text-xl text-primary-foreground/70 mb-12 max-w-xl leading-relaxed"
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 1, ease: "easeOut", delay: 0.7 }}
          >
            Cuidamos de sua mente e corpo para restaurar sua qualidade de vida através da ciência metabólica.
          </motion.p>
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 1, ease: "easeOut", delay: 1 }}
          >
            <Button
              size="lg"
              asChild
              className="group bg-primary-foreground text-primary hover:bg-primary-foreground/90 text-base px-10 py-7 text-lg rounded-full hover:shadow-2xl hover:shadow-primary-foreground/10 transition-all duration-500 ease-out hover:scale-105"
            >
              <Link to="/avaliacao">
                Iniciar sua jornada
                <ArrowRight className="ml-2 h-5 w-5 transition-transform duration-300 ease-out group-hover:translate-x-1.5" />
              </Link>
            </Button>
          </motion.div>
        </div>
      </div>
    </section>
    <WaveDivider fillColor="hsl(36, 30%, 88%)" />
  </>
);

export default HeroSection;
