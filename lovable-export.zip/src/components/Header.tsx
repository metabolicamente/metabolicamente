import { useState } from "react";
import { Link, useLocation, useNavigate } from "react-router-dom";
import { Brain, Menu, X, LogOut, LayoutDashboard } from "lucide-react";
import { Button } from "@/components/ui/button";
import { useAuth } from "@/hooks/useAuth";
import ThemeToggle from "@/components/ThemeToggle";

const navLinks = [
  { label: "Sobre", href: "/sobre" },
  { label: "Tratamento", href: "/tratamento" },
  { label: "Conteúdo", href: "/conteudo" },
  { label: "Pesquisa", href: "/pesquisa" },
  { label: "Corpo clínico", href: "/equipe" },
  { label: "FAQ", href: "/faq" },
];

const Header = () => {
  const [mobileOpen, setMobileOpen] = useState(false);
  const location = useLocation();
  const navigate = useNavigate();
  const { session, signOut } = useAuth();

  const handleSignOut = async () => {
    await signOut();
    navigate("/");
  };

  return (
    <header className="sticky top-0 z-50 w-full bg-background/60 backdrop-blur-xl border-b border-border/50">
      <div className="container flex h-16 items-center">
        {/* Logo — pushed left */}
        <Link to="/" className="flex items-center gap-2 mr-auto">
          <Brain className="h-7 w-7 text-primary" />
          <span className="text-xl font-bold text-primary" style={{ fontFamily: "'Montserrat', sans-serif" }}>
            Metabolicamente
          </span>
        </Link>

        {/* Desktop nav + buttons — pushed right */}
        <div className="hidden md:flex items-center gap-8">
          <nav className="flex items-center gap-6">
            {navLinks.map((link) => (
              <Link
                key={link.href}
                to={link.href}
                className={`relative text-sm font-medium transition-colors pb-1 group ${
                  location.pathname === link.href ? "text-primary" : "text-foreground/70 hover:text-primary"
                }`}
              >
                {link.label}
                {/* Animated underline */}
                <span
                  className={`absolute bottom-0 left-0 h-[2px] bg-secondary rounded-full transition-all duration-300 ease-out ${
                    location.pathname === link.href ? "w-full" : "w-0 group-hover:w-full"
                  }`}
                />
              </Link>
            ))}
          </nav>

          <div className="flex items-center gap-3 ml-4">
            <ThemeToggle />
            {session ? (
              <>
                <Button size="sm" asChild className="bg-background text-primary border border-primary/20 hover:bg-background/80 rounded-full px-4 gap-1.5">
                  <Link to="/painel"><LayoutDashboard className="h-3.5 w-3.5" /> Painel</Link>
                </Button>
                <Button size="sm" onClick={handleSignOut} className="bg-primary text-primary-foreground hover:bg-primary/90 rounded-full px-4 gap-1.5">
                  <LogOut className="h-3.5 w-3.5" /> Sair
                </Button>
              </>
            ) : (
              <>
                <Button size="sm" asChild className="bg-background text-primary border border-primary/20 hover:bg-background/80 hover:shadow-md transition-all duration-300 ease-out hover:scale-105 rounded-full px-5">
                  <Link to="/login">Login</Link>
                </Button>
                <Button size="sm" asChild className="bg-primary text-primary-foreground hover:bg-primary/90 hover:shadow-lg hover:shadow-primary/20 transition-all duration-300 ease-out hover:scale-105 rounded-full px-5">
                  <Link to="/avaliacao">Comece aqui</Link>
                </Button>
              </>
            )}
          </div>
        </div>

        <div className="md:hidden flex items-center gap-2">
          <ThemeToggle />
          <button className="text-foreground" onClick={() => setMobileOpen(!mobileOpen)} aria-label="Menu">
            {mobileOpen ? <X className="h-6 w-6" /> : <Menu className="h-6 w-6" />}
          </button>
        </div>
      </div>

      {mobileOpen && (
        <div className="md:hidden bg-background border-t border-border pb-4">
          <nav className="container flex flex-col gap-3 pt-4">
            {navLinks.map((link) => (
              <Link key={link.href} to={link.href} className="text-sm font-medium text-foreground/70 hover:text-primary py-2" onClick={() => setMobileOpen(false)}>
                {link.label}
              </Link>
            ))}
            <div className="flex flex-col gap-2 pt-3 border-t border-border">
              {session ? (
                <>
                  <Button asChild className="bg-background text-primary border border-primary/20 justify-start">
                    <Link to="/painel" onClick={() => setMobileOpen(false)}>Painel</Link>
                  </Button>
                  <Button onClick={() => { handleSignOut(); setMobileOpen(false); }} className="bg-primary text-primary-foreground">
                    Sair
                  </Button>
                </>
              ) : (
                <>
                  <Button asChild className="bg-background text-primary border border-primary/20 hover:bg-background/80 justify-start">
                    <Link to="/login" onClick={() => setMobileOpen(false)}>Login</Link>
                  </Button>
                  <Button asChild className="bg-primary text-primary-foreground hover:bg-primary/90">
                    <Link to="/avaliacao" onClick={() => setMobileOpen(false)}>Comece aqui</Link>
                  </Button>
                </>
              )}
            </div>
          </nav>
        </div>
      )}
    </header>
  );
};

export default Header;
