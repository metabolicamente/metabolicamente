import { motion } from "framer-motion";

const BrainMetabolicSection = () => (
  <section className="pt-8 md:pt-12 pb-20 md:pb-28 lg:pb-36 -mt-1 bg-muted">
    <div className="container max-w-3xl">
      <motion.div
        className="relative rounded-2xl border border-white/10 px-8 py-10 md:px-12 md:py-14 shadow-md"
        style={{ backgroundColor: "hsl(var(--hero-bg))" }}
        initial={{ opacity: 0, y: 30 }}
        whileInView={{ opacity: 1, y: 0 }}
        viewport={{ once: true, margin: "-80px" }}
        transition={{ duration: 0.8 }}
      >
        <div className="absolute top-0 left-8 right-8 h-px bg-gradient-to-r from-transparent via-white/20 to-transparent" />

        <h3 className="text-xl md:text-2xl font-semibold text-white/90 mb-6 leading-snug">
          O cérebro é um órgão metabólico.
        </h3>

        <div className="space-y-4 text-white/70 text-base md:text-lg leading-relaxed">
          <p>Apesar de representar uma pequena fração do peso corporal, o cérebro consome uma quantidade desproporcional de energia.</p>
          <p>Seu funcionamento depende da produção eficiente dessa energia, do fornecimento adequado de nutrientes e de um ambiente metabólico equilibrado.</p>
          <p>Alterações como resistência à insulina, inflamação e disfunção mitocondrial podem comprometer esse processo e impactar diretamente a saúde mental.</p>
        </div>
      </motion.div>
    </div>
  </section>
);

export default BrainMetabolicSection;
