import { motion } from "framer-motion";
import { Link } from "react-router-dom";
import { ArrowRight } from "lucide-react";
import { Button } from "@/components/ui/button";
import WaveDivider from "@/components/shared/WaveDivider";

const WhyMetabolismSection = () => (
  <>
    <WaveDivider fillColor="hsl(var(--hero-bg))" />
    <section className="py-20 md:py-28 lg:py-36" style={{ backgroundColor: "hsl(var(--hero-bg))" }}>
      <div className="container max-w-3xl">
        <motion.div
          className="relative rounded-2xl border border-white/10 bg-[hsl(var(--background))]/90 backdrop-blur-sm px-8 py-10 md:px-12 md:py-14 shadow-md"
          initial={{ opacity: 0, y: 30 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true, margin: "-80px" }}
          transition={{ duration: 0.8 }}
        >
          <div className="absolute top-0 left-8 right-8 h-px bg-gradient-to-r from-transparent via-primary/30 to-transparent" />

          <h3 className="text-xl md:text-2xl font-semibold text-primary mb-6 leading-snug">
            Por que considerar o metabolismo na saúde mental?
          </h3>

          <div className="space-y-4 text-muted-foreground text-base md:text-lg leading-relaxed mb-8">
            <p>Nas últimas décadas, houve um aumento expressivo na prevalência de transtornos mentais.</p>
            <p>Ao mesmo tempo, ocorreram mudanças relevantes nos padrões alimentares e no estilo de vida.</p>
            <p>A literatura científica tem investigado a relação entre metabolismo cerebral, inflamação e saúde mental, ampliando as possibilidades de compreensão e cuidado clínico.</p>
          </div>

          <motion.div
            whileHover={{ scale: 1.05 }}
            transition={{ type: "spring", stiffness: 300, damping: 20 }}
            className="inline-block"
          >
            <Button
              asChild
              className="group bg-primary text-primary-foreground hover:bg-primary/90 rounded-full px-6"
            >
              <Link to="/pesquisa">
                Pesquisas sobre o tema
                <ArrowRight className="ml-2 h-4 w-4 transition-transform duration-300 group-hover:translate-x-1" />
              </Link>
            </Button>
          </motion.div>
        </motion.div>
      </div>
    </section>
    <WaveDivider fillColor="hsl(var(--background))" />
  </>
);

export default WhyMetabolismSection;
