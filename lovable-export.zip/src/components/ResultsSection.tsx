import { motion, useInView, animate } from "framer-motion";
import { useRef, useEffect, useState } from "react";
import { Activity, Brain, Pill, Scale } from "lucide-react";
import WaveDivider from "@/components/shared/WaveDivider";

const AnimatedNumber = ({ value, suffix = "%", delay = 0 }: { value: number; suffix?: string; delay?: number }) => {
  const ref = useRef(null);
  const isInView = useInView(ref, { once: true, margin: "-80px" });
  const [display, setDisplay] = useState(0);

  useEffect(() => {
    if (!isInView) return;
    const timeout = setTimeout(() => {
      const controls = animate(0, value, {
        duration: 2,
        ease: "easeOut",
        onUpdate: (v) => setDisplay(Math.round(v)),
      });
      return () => controls.stop();
    }, delay * 1000);
    return () => clearTimeout(timeout);
  }, [isInView, value, delay]);

  return <span ref={ref} className="tabular-nums">{display}{suffix}</span>;
};

const metrics = [
  { icon: Activity, value: 100, label: "reversal of metabolic syndrome", delay: 0 },
  { icon: Brain, value: 79, label: "mental health improvement (CGI)", delay: 0.15 },
  { icon: Pill, value: 30, label: "decrease in medications", delay: 0.3 },
  { icon: Scale, value: 10, label: "average weight loss", delay: 0.45 },
];

const ResultsSection = () => (
  <>
    <section className="py-20 md:py-28 lg:py-36 bg-muted">
      <div className="container">
        <motion.div
          className="text-center mb-6"
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.7 }}
        >
          <h2 className="text-3xl md:text-4xl lg:text-5xl font-bold text-primary mb-4">
            Resultados reais, respaldados pela ciência.
          </h2>
          <p className="text-muted-foreground text-base md:text-lg max-w-2xl mx-auto leading-relaxed">
            Em um ensaio clínico conduzido por{" "}
            <span className="font-semibold text-foreground">Stanford</span>, pacientes apresentaram melhorias mensuráveis na saúde mental e metabólica.
          </p>
        </motion.div>

        <div className="grid grid-cols-2 md:grid-cols-4 gap-8 lg:gap-12 mt-16">
          {metrics.map((m, i) => (
            <motion.div
              key={i}
              className="text-center"
              initial={{ opacity: 0, y: 30 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.7, delay: m.delay }}
            >
              <motion.div
                className="inline-flex items-center justify-center w-14 h-14 rounded-full bg-primary/10 mb-5"
                initial={{ scale: 0.8 }}
                whileInView={{ scale: [0.8, 1.08, 1] }}
                viewport={{ once: true }}
                transition={{ duration: 1, delay: m.delay + 0.3, ease: "easeOut" }}
              >
                <m.icon className="w-6 h-6 text-primary" strokeWidth={1.5} />
              </motion.div>
              <p className="text-4xl md:text-5xl font-bold text-primary mb-2" style={{ fontFamily: "'Montserrat', sans-serif" }}>
                <AnimatedNumber value={m.value} delay={m.delay + 0.4} />
              </p>
              <p className="text-sm md:text-base text-muted-foreground leading-relaxed max-w-[180px] mx-auto">{m.label}</p>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
    <WaveDivider fillColor="hsl(var(--background))" />
  </>
);

export default ResultsSection;
