import { motion } from "framer-motion";
import { ClipboardList, Users, MessageCircle, HeartPulse } from "lucide-react";
import WaveDivider from "@/components/shared/WaveDivider";

import doctor1 from "@/assets/doctor-1.jpg";
import doctor2 from "@/assets/doctor-2.jpg";
import doctor3 from "@/assets/doctor-3.jpg";
import doctor4 from "@/assets/doctor-4.jpg";
import videoCall from "@/assets/video-call.png";

const doctors = [
  { photo: doctor1, name: "Dr. Ricardo" },
  { photo: doctor2, name: "Dra. Camila" },
  { photo: doctor3, name: "Dr. Lucas" },
  { photo: doctor4, name: "Dra. Beatriz" },
];

const steps = [
  { icon: ClipboardList, title: "Avaliação Inicial", description: "Questionário rápido sobre seus sintomas, histórico e objetivos de saúde.", extra: null },
  { icon: Users, title: "Encaminhamento", description: "Nossa equipe identifica o profissional ideal para o seu caso clínico.", extra: null },
  { icon: MessageCircle, title: "Conversa Inicial", description: "Sessão para alinhamento das expectativas e aprofundamento do caso.", extra: "video" as const },
  { icon: HeartPulse, title: "Acompanhamento", description: "Plano de intervenção metabólica traçado pela equipe de nutricionistas e psiquiatras.", extra: "mosaic" as const },
];

const DoctorMosaic = () => (
  <div className="flex items-center justify-center mt-5 -space-x-3">
    {doctors.map((doc, i) => (
      <motion.div
        key={i}
        className="w-10 h-10 md:w-11 md:h-11 rounded-full border-2 border-primary-foreground overflow-hidden shadow-lg"
        initial={{ opacity: 0, scale: 0.7 }}
        whileInView={{ opacity: 1, scale: 1 }}
        viewport={{ once: true }}
        transition={{ delay: 0.3 + i * 0.1, duration: 0.5 }}
      >
        <img src={doc.photo} alt={doc.name} className="w-full h-full object-cover" />
      </motion.div>
    ))}
  </div>
);

const VideoCallPreview = () => (
  <motion.div
    className="mt-5 rounded-lg overflow-hidden border border-white/10 shadow-lg"
    initial={{ opacity: 0, scale: 0.9 }}
    whileInView={{ opacity: 1, scale: 1 }}
    viewport={{ once: true }}
    transition={{ delay: 0.4, duration: 0.5 }}
  >
    <img src={videoCall} alt="Teleconsulta médica" className="w-full h-auto" />
  </motion.div>
);

const HowItWorksSection = () => (
  <>
    <section className="py-20 md:py-28 lg:py-36 relative" style={{ background: "hsl(153, 37%, 18%)" }}>
      <div className="container">
        <motion.div
          className="text-center mb-16"
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.7 }}
        >
          <h2 className="text-3xl md:text-4xl lg:text-5xl font-bold mb-4" style={{ color: "hsl(var(--primary-foreground))", fontFamily: "'Montserrat', sans-serif" }}>
            Como Funciona
          </h2>
          <p className="text-lg max-w-md mx-auto" style={{ color: "hsl(var(--primary-foreground) / 0.6)" }}>
            Quatro passos para transformar sua saúde mental.
          </p>
        </motion.div>

        {/* Desktop: horizontal with arrows */}
        <div className="hidden lg:grid grid-cols-[1fr_auto_1fr_auto_1fr_auto_1fr] items-start gap-0">
          {steps.map((step, i) => (
            <>
              <motion.div
                key={`step-${i}`}
                className="group relative rounded-2xl border border-white/10 p-8 text-center backdrop-blur-sm bg-white/[0.03] transition-all duration-300 hover:-translate-y-2 hover:bg-white/[0.06]"
                initial={{ opacity: 0, y: 30 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ duration: 0.6, delay: i * 0.15 }}
              >
                <span className="absolute top-4 right-4 text-xs font-semibold opacity-30" style={{ color: "hsl(var(--primary-foreground))", fontFamily: "'Montserrat', sans-serif" }}>0{i + 1}</span>
                <div className="inline-flex items-center justify-center w-14 h-14 rounded-xl bg-white/10 mb-6">
                  <step.icon className="w-6 h-6 text-primary-foreground/80" strokeWidth={1.5} />
                </div>
                <h3 className="text-lg font-semibold mb-2" style={{ color: "hsl(var(--primary-foreground))" }}>{step.title}</h3>
                <p className="text-sm leading-relaxed" style={{ color: "hsl(var(--primary-foreground) / 0.6)" }}>{step.description}</p>
                {step.extra === "mosaic" && <DoctorMosaic />}
                {step.extra === "video" && <VideoCallPreview />}
              </motion.div>
              {i < steps.length - 1 && (
                <div key={`arrow-${i}`} className="flex items-center justify-center pt-16">
                  <motion.svg
                    width="40" height="2" viewBox="0 0 40 2"
                    className="text-primary-foreground/20"
                    initial={{ opacity: 0, scaleX: 0 }}
                    whileInView={{ opacity: 1, scaleX: 1 }}
                    viewport={{ once: true }}
                    transition={{ delay: 0.3 + i * 0.15, duration: 0.5 }}
                  >
                    <line x1="0" y1="1" x2="32" y2="1" stroke="currentColor" strokeWidth="1" strokeDasharray="4 4" />
                    <polygon points="32,0 40,1 32,2" fill="currentColor" />
                  </motion.svg>
                </div>
              )}
            </>
          ))}
        </div>

        {/* Mobile: 2-column grid */}
        <div className="lg:hidden grid grid-cols-2 gap-4">
          {steps.map((step, i) => (
            <motion.div
              key={i}
              className="relative rounded-2xl border border-white/10 p-5 text-center backdrop-blur-sm bg-white/[0.03]"
              initial={{ opacity: 0, y: 30 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.6, delay: i * 0.1 }}
            >
              <span className="absolute top-3 right-3 text-xs font-semibold opacity-30" style={{ color: "hsl(var(--primary-foreground))", fontFamily: "'Montserrat', sans-serif" }}>0{i + 1}</span>
              <div className="inline-flex items-center justify-center w-11 h-11 rounded-xl bg-white/10 mb-4">
                <step.icon className="w-5 h-5 text-primary-foreground/80" strokeWidth={1.5} />
              </div>
              <h3 className="text-sm font-semibold mb-1.5" style={{ color: "hsl(var(--primary-foreground))" }}>{step.title}</h3>
              <p className="text-xs leading-relaxed" style={{ color: "hsl(var(--primary-foreground) / 0.6)" }}>{step.description}</p>
              {step.extra === "mosaic" && <DoctorMosaic />}
              {step.extra === "video" && <VideoCallPreview />}
            </motion.div>
          ))}
        </div>
      </div>
    </section>
    <WaveDivider fillColor="hsl(36, 30%, 88%)" />
  </>
);

export default HowItWorksSection;
