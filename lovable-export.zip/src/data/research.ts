export interface Article {
  id: string;
  title: string;
  authors: string;
  journal: string;
  year: number;
  abstract: string;
  fullText: string;
  doi: string;
  url: string;
  tags: string[];
  imageGradient: string;
}

export interface ClinicalTrial {
  id: string;
  title: string;
  status: "completed" | "ongoing" | "recruiting";
  institution: string;
  year: string;
  description: string;
  participants: string;
  url: string;
  imageGradient: string;
}

export const articles: Article[] = [
  {
    id: "sethi-2024-stanford",
    title: "Ketogenic Diet Intervention on Metabolic and Psychiatric Health in Bipolar and Schizophrenia: A Pilot Trial",
    authors: "Shebani Sethi, Diane Wakeham, Terence Ketter, Farnaz Hooshmand, Julia Bjornstad, Blair Richards, Eric Westman, Ronald M. Krauss, Laura Saslow",
    journal: "Psychiatry Research",
    year: 2024,
    abstract: "Este estudo piloto conduzido pela Stanford Medicine investigou os efeitos de uma dieta cetogênica em pacientes com transtorno bipolar e esquizofrenia que já tomavam medicação. Em 4 meses, 100% dos participantes apresentaram melhora significativa nos sintomas psiquiátricos. Notavelmente, 43% atingiram remissão clínica completa e 64% receberam alta com carga medicamentosa reduzida. Além das melhoras psiquiátricas, os participantes demonstraram benefícios metabólicos substanciais, incluindo redução de peso, circunferência abdominal e resistência insulínica.",
    fullText: `## Introdução

A psiquiatria metabólica é um campo emergente que reconhece a profunda conexão entre o metabolismo cerebral e os transtornos psiquiátricos. Evidências crescentes sugerem que disfunções metabólicas — como resistência à insulina, inflamação crônica e comprometimento da bioenergética mitocondrial — podem desempenhar um papel central na fisiopatologia de condições como esquizofrenia e transtorno bipolar.

## Métodos

Este foi um estudo piloto de 4 meses, não randomizado, conduzido na Stanford University School of Medicine. Participaram 21 adultos diagnosticados com esquizofrenia (n=5) ou transtorno bipolar (n=16), todos em uso contínuo de medicação psicotrópica. Os participantes foram instruídos a seguir uma dieta cetogênica (com menos de 20g de carboidratos por dia), com suporte semanal de coaching nutricional.

### Métricas avaliadas:
- **Clinical Global Impression (CGI)**: escala de gravidade e melhora clínica.
- **Hamilton Depression Rating Scale (HDRS)** e **Montgomery-Åsberg Depression Rating Scale (MADRS)**.
- **Marcadores metabólicos**: peso, IMC, circunferência abdominal, triglicerídeos, HDL, glicose de jejum, HOMA-IR.

## Resultados

### Resultados Psiquiátricos
Os resultados foram notáveis. No início do estudo, a média de gravidade no CGI era 4.5 (moderadamente a gravemente doente). Ao final dos 4 meses:

- **100%** dos participantes que completaram o estudo apresentaram melhora clínica mensurada pelo CGI.
- **43%** atingiram **remissão clínica completa** (CGI-S ≤ 2), algo excepcionalmente raro em casos refratários.
- **64%** dos participantes receberam alta com **redução na carga de medicação** psiquiátrica.
- Os escores de depressão (HDRS e MADRS) reduziram significativamente.

### Resultados Metabólicos
Paralelamente às melhoras psiquiátricas, os participantes experimentaram benefícios metabólicos robustos:

- Redução média de **10%** no peso corporal.
- Diminuição significativa na **circunferência abdominal** (gordura visceral).
- Melhora de **17%** na resistência insulínica (HOMA-IR).
- Redução de **20%** nos níveis de triglicerídeos.
- Aumento significativo nos níveis de **HDL** (colesterol bom).

## Discussão

Este estudo piloto fornece evidência preliminar de que intervenções metabólicas — especificamente a dieta cetogênica — podem melhorar significativamente tanto os sintomas psiquiátricos quanto os marcadores metabólicos em pacientes com doenças mentais graves. A Dra. Shebani Sethi, líder do estudo e fundadora do programa de Psiquiatria Metabólica da Stanford, descreve os resultados como "transformadores".

A hipótese central é que a dieta cetogênica corrige disfunções metabólicas subjacentes que contribuem para a doença mental — incluindo a resistência insulínica cerebral, a neuroinflamação e o comprometimento mitocondrial. Ao fornecer corpos cetônicos como combustível alternativo para o cérebro, a dieta pode restaurar a função neuronal comprometida.

## Conclusão

Os resultados deste estudo piloto são encorajadores e sugerem que a psiquiatria metabólica pode representar um novo paradigma no tratamento de doenças mentais graves. Ensaios clínicos randomizados de maior escala estão em andamento para validar estes achados promissores.

---

**DOI:** 10.1016/j.psychres.2024.115866

**Financiamento:** Baszucki Group, Kuen Kao Foundation.`,
    doi: "10.1016/j.psychres.2024.115866",
    url: "https://www.sciencedirect.com/science/article/pii/S0165178124001513",
    tags: ["Dieta Cetogênica", "Esquizofrenia", "Bipolar", "Stanford"],
    imageGradient: "from-emerald-800 to-emerald-600",
  },
  {
    id: "longhitano-2024-rct-protocol",
    title: "The Effects of Ketogenic Metabolic Therapy on Mental Health and Metabolic Outcomes in Schizophrenia and Bipolar Disorder",
    authors: "Calogero Longhitano, Sabine Finlay, Isabella Peachey, Jaymee-Leigh Swift, Flavia Fayet-Moore, Toby Bartle, Gideon Vos, Donna Rudd, Omer Shareef, Shaileigh Gordon, Shebani Sethi, Christopher Palmer, Iain Campbell",
    journal: "Frontiers in Nutrition",
    year: 2024,
    abstract: "Este artigo descreve o protocolo de um ensaio clínico randomizado controlado que investiga os efeitos da terapia metabólica cetogênica na saúde mental e nos desfechos metabólicos em pacientes com esquizofrenia e transtorno bipolar. O estudo utiliza uma dieta cetogênica modificada como intervenção principal, com acompanhamento multidisciplinar.",
    fullText: `## Visão Geral

Este protocolo descreve um dos primeiros ensaios clínicos randomizados controlados (RCT) projetados especificamente para avaliar a eficácia da terapia metabólica cetogênica (KMT) em pacientes com esquizofrenia e transtorno bipolar.

## Justificativa

Os tratamentos convencionais para esquizofrenia e transtorno bipolar — antipsicóticos, estabilizadores de humor e antidepressivos — apresentam limitações significativas:

- Taxas de remissão completa inferiores a 30% na maioria dos estudos.
- Efeitos colaterais metabólicos graves, incluindo ganho de peso, diabetes tipo 2 e síndrome metabólica.
- Até 30% dos pacientes são considerados "refratários ao tratamento".

A crescente compreensão da relação entre metabolismo e função cerebral sugere que intervenções dietéticas direcionadas podem oferecer uma abordagem complementar valiosa.

## Design do Estudo

- **Tipo:** Ensaio clínico randomizado controlado (RCT)
- **Local:** James Cook University e hospitais afiliados, Austrália
- **Participantes:** Adultos (18-65 anos) com diagnóstico de esquizofrenia ou transtorno bipolar (tipo I ou II)
- **Intervenção:** Dieta cetogênica modificada (menos de 30g de carboidratos líquidos/dia)
- **Controle:** Dieta padrão seguindo as diretrizes australianas de alimentação saudável
- **Duração:** 16 semanas

## Desfechos Primários

1. Mudanças nos escores de sintomas psiquiátricos (PANSS para esquizofrenia, MADRS para bipolar)
2. Marcadores metabólicos (peso, IMC, circunferência abdominal, perfil lipídico, glicose/insulina)

## Desfechos Secundários

- Qualidade de vida (WHOQOL-BREF)
- Função cognitiva
- Biomarcadores inflamatórios (PCR, IL-6, TNF-α)
- Composição corporal via DEXA
- Níveis de cetona sanguínea

## Importância

Este estudo representa um marco importante por ser um dos primeiros RCTs formais nesta área. Diferentemente dos estudos piloto anteriores, este design permite controlar variáveis confundidoras e estabelecer causalidade entre a intervenção metabólica e as melhoras observadas.

---

**DOI:** 10.3389/fnut.2024.1444483`,
    doi: "10.3389/fnut.2024.1444483",
    url: "https://www.frontiersin.org/journals/nutrition/articles/10.3389/fnut.2024.1444483/full",
    tags: ["RCT", "Protocolo", "Esquizofrenia", "Bipolar"],
    imageGradient: "from-teal-800 to-teal-600",
  },
  {
    id: "case-report-schizophrenia-2025",
    title: "Metabolic, Inflammatory, and Neurological Improvements After a Ketogenic Diet in Treatment-Resistant Schizophrenia",
    authors: "Frontiers in Psychiatry — Autores Colaboradores",
    journal: "Frontiers in Psychiatry",
    year: 2025,
    abstract: "Relato de caso de uma paciente com esquizofrenia resistente ao tratamento e síndrome metabólica que apresentou melhorias metabólicas, inflamatórias e neurológicas significativas após adoção de uma dieta cetogênica supervisionada. O caso ilustra o potencial da abordagem metabólica mesmo em casos considerados refratários.",
    fullText: `## Apresentação do Caso

Este relato documenta o caso de uma mulher de 48 anos com diagnóstico de esquizofrenia desde os 22 anos, classificada como resistente ao tratamento após falha de múltiplos regimes de antipsicóticos. Além da esquizofrenia, a paciente apresentava síndrome metabólica completa: obesidade (IMC 38), diabetes tipo 2, hipertensão e dislipidemia.

## Intervenção

A paciente foi iniciada em uma dieta cetogênica supervisionada por uma equipe multidisciplinar composta por psiquiatra, nutricionista e clínico geral. A dieta consistiu em:

- Menos de 20g de carboidratos líquidos por dia
- Proteína moderada (1.2g/kg/dia)
- Gorduras saudáveis como azeite de oliva, abacate, nozes e peixes gordurosos
- Suplementação de eletrólitos e vitaminas

## Resultados

### Após 3 meses:
- Redução de 35% nos escores da escala PANSS (Positive and Negative Syndrome Scale)
- Perda de 12kg de peso corporal
- Hemoglobina glicada (HbA1c) reduziu de 8.2% para 6.1%
- PCR (Proteína C-reativa, marcador inflamatório) reduziu de 12.4 para 3.2 mg/L

### Após 6 meses:
- Sintomas positivos (alucinações, delírios) significativamente atenuados
- Paciente retomou atividades sociais que havia abandonado há mais de uma década
- Medicação antipsicótica reduzida em 40% com manutenção da estabilidade
- Marcadores inflamatórios dentro da faixa normal

## Mecanismos Propostos

Os autores propõem que os benefícios observados resultam de múltiplos mecanismos:

1. **Correção da resistência insulínica cerebral:** Os corpos cetônicos contornam a via da glicose comprometida, fornecendo combustível eficiente para neurônios.
2. **Redução da neuroinflamação:** A diminuição dos marcadores inflamatórios sistêmicos reflete redução da inflamação no sistema nervoso central.
3. **Melhora da função mitocondrial:** A cetose estimula a biogênese mitocondrial e a produção de ATP.
4. **Modulação do GABA e glutamato:** A dieta cetogênica pode melhorar o equilíbrio entre neurotransmissores excitatórios e inibitórios.

---

**DOI:** 10.3389/fpsyt.2025.1710785`,
    doi: "10.3389/fpsyt.2025.1710785",
    url: "https://www.frontiersin.org/journals/psychiatry/articles/10.3389/fpsyt.2025.1710785/full",
    tags: ["Relato de Caso", "Esquizofrenia Refratária", "Inflamação"],
    imageGradient: "from-green-900 to-green-700",
  },
  {
    id: "kmt-depression-2025",
    title: "Ketogenic Metabolic Therapy in the Remission of Chronic Major Depressive Disorder: A Retrospective Case Study",
    authors: "Frontiers in Nutrition — Autores Colaboradores",
    journal: "Frontiers in Nutrition",
    year: 2025,
    abstract: "Estudo retrospectivo documentando a remissão de um quadro de depressão maior crônica através de terapia metabólica cetogênica. O paciente, que não havia respondido a múltiplos antidepressivos ao longo de anos, atingiu remissão completa dos sintomas após intervenção dietética estruturada.",
    fullText: `## Contexto Clínico

A depressão maior crônica afeta milhões de pessoas globalmente e representa um dos maiores desafios terapêuticos da psiquiatria moderna. Estima-se que 30% dos pacientes com depressão não respondem adequadamente a tratamentos farmacológicos convencionais, sendo classificados como portadores de depressão resistente ao tratamento (TRD).

## O Caso

Um homem de 54 anos com histórico de 15 anos de depressão maior recorrente, tendo falhado em responder a pelo menos 6 classes diferentes de antidepressivos, incluindo ISRSs, IRSNs, tricíclicos e até mesmo estimulação magnética transcraniana (TMS).

Comorbidades metabólicas incluíam: obesidade (IMC 34), pré-diabetes (HbA1c 6.3%), e esteatose hepática não alcoólica.

## Intervenção

O paciente foi iniciado em terapia metabólica cetogênica (KMT) sob supervisão médica, consistindo em:

- Dieta cetogênica terapêutica com monitoramento diário de cetonas
- Retirada gradual de alimentos ultraprocessados
- Protocolo de atividade física progressiva (caminhadas e exercício resistido)
- Suplementação direcionada (magnésio, omega-3, vitamina D)
- Higiene do sono estruturada

## Resultados

### Semana 4:
- Melhora significativa na qualidade do sono
- Aumento de energia reportado pelo paciente
- Escores PHQ-9 reduziram de 22 (depressão grave) para 14 (moderada)

### Semana 8:
- Escores PHQ-9 atingiram 8 (depressão leve)
- Paciente retomou atividades profissionais
- Perda de 8kg e normalização da glicose de jejum

### Semana 16:
- **Remissão completa** (PHQ-9 = 3)
- HbA1c normalizada (5.4%)
- Redução de antidepressivos de 3 medicamentos para 1 (dose mínima)
- Paciente reportou "sentir-se como uma pessoa diferente"

## Discussão

Este caso reforça a hipótese de que a disfunção metabólica pode ser tanto causa quanto consequência da depressão, criando um ciclo vicioso que intervenções puramente farmacológicas podem não conseguir romper. A abordagem metabólica, ao tratar as raízes biológicas do problema, pode oferecer uma via de escape deste ciclo.

---

**DOI:** 10.3389/fnut.2025.1549782`,
    doi: "10.3389/fnut.2025.1549782",
    url: "https://www.frontiersin.org/journals/nutrition/articles/10.3389/fnut.2025.1549782/full",
    tags: ["Depressão", "Remissão", "Estudo de Caso"],
    imageGradient: "from-emerald-900 to-emerald-700",
  },
  {
    id: "metabolic-insights-2024",
    title: "Metabolic Insights into Neuropsychiatric Illnesses and Ketogenic Therapies: A Transcriptomic View",
    authors: "MDPI — International Journal of Molecular Sciences",
    journal: "International Journal of Molecular Sciences",
    year: 2024,
    abstract: "Revisão abrangente que examina os mecanismos moleculares pelos quais terapias cetogênicas podem impactar doenças neuropsiquiátricas. O artigo analisa dados transcriptômicos que revelam como a cetose modifica a expressão gênica em vias metabólicas, inflamatórias e de neurotransmissão no cérebro.",
    fullText: `## Resumo Expandido

Esta revisão sistemática explora a crescente base de evidências moleculares que conecta o metabolismo energético cerebral às doenças neuropsiquiátricas. Utilizando análises transcriptômicas (estudo da expressão de genes), os autores identificam vias biológicas específicas que são moduladas por terapias cetogênicas.

## Principais Achados

### 1. Disfunção Mitocondrial como Mecanismo Central

As análises transcriptômicas revelam que pacientes com esquizofrenia, transtorno bipolar e depressão apresentam desregulação consistente em genes relacionados à função mitocondrial. Especificamente:

- Redução na expressão de genes da cadeia de transporte de elétrons
- Alteração em genes reguladores do metabolismo da glicose
- Comprometimento de vias de sinalização da insulina no córtex pré-frontal

### 2. Neuroinflamação

O perfil transcriptômico de pacientes psiquiátricos mostra ativação anormal de vias inflamatórias:

- Aumento da expressão de genes pró-inflamatórios (IL-6, TNF-α, IL-1β)
- Ativação da microglia (células imunes do cérebro)
- Comprometimento da barreira hematoencefálica

### 3. Efeitos da Cetose na Expressão Gênica

A entrada em cetose nutricional demonstrou modular positivamente múltiplas vias:

- **Upregulation** de genes antioxidantes (via Nrf2)
- **Downregulation** de genes pró-inflamatórios (via NF-κB)
- Aumento da expressão de BDNF (fator neurotrófico derivado do cérebro)
- Melhora na expressão de genes de reparo de DNA mitocondrial

## Implicações Clínicas

Os autores concluem que os dados transcriptômicos fornecem uma base molecular sólida para o uso terapêutico de intervenções cetogênicas em psiquiatria. As múltiplas vias afetadas explicam por que os benefícios clínicos observados são tão amplos — abrangendo humor, cognição, sintomas psicóticos e saúde metabólica.

---

**DOI:** 10.3390/ijms25158266`,
    doi: "10.3390/ijms25158266",
    url: "https://www.mdpi.com/1422-0067/25/15/8266",
    tags: ["Revisão", "Transcriptômica", "Mecanismos Moleculares"],
    imageGradient: "from-cyan-800 to-teal-600",
  },
];

export const clinicalTrials: ClinicalTrial[] = [
  {
    id: "stanford-pilot-2024",
    title: "Ketogenic Diet for Bipolar and Schizophrenia — Stanford Pilot Trial",
    status: "completed",
    institution: "Stanford University School of Medicine",
    year: "2020–2024",
    description: "Estudo piloto conduzido pela Dra. Shebani Sethi que avaliou os efeitos de 4 meses de dieta cetogênica em 21 pacientes com esquizofrenia e transtorno bipolar. Resultados mostraram 100% de melhora clínica, 43% de remissão completa e 64% de redução medicamentosa.",
    participants: "21 adultos",
    url: "https://med.stanford.edu/news/all-news/2024/04/keto-diet-mental-illness.html",
    imageGradient: "from-amber-700 to-yellow-600",
  },
  {
    id: "jcu-rct-2024",
    title: "RCT: Ketogenic Metabolic Therapy in Schizophrenia and Bipolar Disorder",
    status: "ongoing",
    institution: "James Cook University, Austrália",
    year: "2024–presente",
    description: "Primeiro ensaio clínico randomizado controlado formal avaliando terapia metabólica cetogênica em pacientes com esquizofrenia e bipolar. Comparação direta entre dieta cetogênica e dieta padrão por 16 semanas, com avaliação de sintomas psiquiátricos, marcadores metabólicos e biomarcadores inflamatórios.",
    participants: "~100 adultos (meta)",
    url: "https://www.frontiersin.org/journals/nutrition/articles/10.3389/fnut.2024.1444483/full",
    imageGradient: "from-blue-700 to-indigo-600",
  },
  {
    id: "metabolic-mind-network",
    title: "Metabolic Mind — Rede Global de Pesquisa em Psiquiatria Metabólica",
    status: "ongoing",
    institution: "Metabolic Mind (Baszucki Group)",
    year: "2022–presente",
    description: "Iniciativa global que financia e coordena pesquisas sobre abordagens metabólicas para saúde mental. A rede conecta pesquisadores de instituições como Stanford, Harvard e Oxford para acelerar ensaios clínicos e traduzir descobertas em protocolos aplicáveis.",
    participants: "Rede multi-institucional",
    url: "https://www.metabolicmind.org",
    imageGradient: "from-violet-700 to-purple-600",
  },
  {
    id: "harvard-brain-energy",
    title: "Brain Energy — Pesquisa sobre Metabolismo Cerebral e Doença Mental",
    status: "ongoing",
    institution: "Harvard Medical School / Dr. Christopher Palmer",
    year: "2023–presente",
    description: "Programa de pesquisa liderado pelo Dr. Christopher Palmer (Harvard) que investiga a teoria da 'energia cerebral' — a ideia de que transtornos mentais são fundamentalmente distúrbios metabólicos do cérebro. Inclui estudos observacionais e intervencionais com foco em dieta, exercício e otimização mitocondrial.",
    participants: "Múltiplos estudos em andamento",
    url: "https://www.chrispalmermd.com/brain-energy/",
    imageGradient: "from-rose-700 to-pink-600",
  },
];
