export interface OpinionArticle {
  id: string;
  title: string;
  author: string;
  source: string;
  excerpt: string;
  fullText: string;
  externalUrl: string;
}

export const opinionArticles: OpinionArticle[] = [
  {
    id: "metabolic-psychiatry-mental-health-meets-metabolic-health",
    title: "Metabolic Psychiatry: Where Mental Health Meets Metabolic Health",
    author: "Proactive Psychiatry",
    source: "Proactive Psychiatry",
    excerpt: "Por muito tempo, a psiquiatria ficou presa no modelo de desequilíbrio químico. E se as doenças mentais forem mais do que um problema de neurotransmissores?",
    externalUrl: "https://www.proactivepsychiatry.com/post/metabolic-psychiatry-where-mental-health-meets-metabolic-health",
    fullText: `## A Mudança de Paradigma

Por décadas, a psiquiatria operou sob a premissa do "desequilíbrio químico" — a ideia de que transtornos mentais são causados principalmente por desregulações nos neurotransmissores como serotonina, dopamina e norepinefrina. Embora essa teoria tenha sido útil para o desenvolvimento de medicamentos, ela oferece uma visão incompleta da complexidade das doenças mentais.

## O Que É Psiquiatria Metabólica?

A psiquiatria metabólica é uma abordagem emergente que investiga como o metabolismo cerebral — incluindo a produção de energia, a função mitocondrial, a inflamação e a resistência à insulina — contribui para o desenvolvimento e a manutenção dos transtornos mentais.

Em vez de tratar apenas os sintomas com psicofármacos, essa abordagem busca identificar e corrigir as disfunções metabólicas subjacentes que podem estar na raiz do sofrimento psíquico.

## Evidências Crescentes

Pesquisas recentes, incluindo o estudo piloto da Stanford University liderado pela Dra. Shebani Sethi, demonstram que intervenções metabólicas — como a dieta cetogênica — podem produzir melhorias significativas em pacientes com esquizofrenia e transtorno bipolar.

### Principais achados:
- 100% dos participantes apresentaram melhora clínica mensurável
- 43% atingiram remissão completa dos sintomas
- Melhorias simultâneas nos marcadores metabólicos (peso, insulina, triglicerídeos)

## Uma Visão Integrada

A psiquiatria metabólica não propõe abandonar os tratamentos existentes. Em vez disso, oferece uma camada adicional de compreensão e intervenção. O cérebro consome cerca de 20% da energia total do corpo — quando o metabolismo energético falha, a função cerebral é inevitavelmente comprometida.

## Conclusão

Estamos no início de uma revolução na compreensão da saúde mental. A psiquiatria metabólica representa uma ponte entre a medicina metabólica e a neurociência, oferecendo novas esperanças para milhões de pessoas que não respondem adequadamente aos tratamentos tradicionais.`,
  },
  {
    id: "integrating-bioenergetics-mental-health-care",
    title: "Metabolic Psychiatry: Integrating Bioenergetics into Mental Health Care",
    author: "Cardinal Clinic",
    source: "Cardinal Clinic",
    excerpt: "Por décadas, o modelo dominante em saúde mental focou na sinapse. Agora, pesquisadores estão investigando o papel da bioenergética celular.",
    externalUrl: "https://cardinalclinic.co.uk/blog/metabolic-psychiatry-integrating-bioenergetics-into-mental-health-care/",
    fullText: `## Além da Sinapse

O modelo sináptico da doença mental — focado em neurotransmissores e receptores — dominou a psiquiatria por mais de meio século. No entanto, uma nova perspectiva está emergindo: a bioenergética celular como fator central nos transtornos psiquiátricos.

## O Papel da Mitocôndria

As mitocôndrias são as "usinas de energia" das células. No cérebro, elas são particularmente cruciais, pois os neurônios têm demandas energéticas extremamente altas. Quando a função mitocondrial é comprometida, o resultado pode ser:

- Redução na produção de ATP (energia celular)
- Aumento do estresse oxidativo
- Comprometimento da plasticidade sináptica
- Desregulação de neurotransmissores

## Bioenergética e Transtornos Mentais

Estudos transcriptômicos revelam que pacientes com depressão, esquizofrenia e transtorno bipolar apresentam padrões consistentes de disfunção mitocondrial. Genes relacionados ao metabolismo energético mostram expressão alterada nas regiões cerebrais associadas a cada condição.

## Intervenções Metabólicas

A compreensão bioenergética abre portas para novas abordagens terapêuticas:

### Dieta Cetogênica
Os corpos cetônicos (beta-hidroxibutirato, acetoacetato) são um combustível alternativo eficiente para o cérebro, contornando disfunções na via da glicose.

### Exercício Físico
Estimula a biogênese mitocondrial e melhora a capacidade de produção energética neuronal.

### Suplementação Direcionada
Coenzima Q10, NAD+, magnésio e outros cofatores podem otimizar a função mitocondrial.

## O Futuro

A integração da bioenergética na prática psiquiátrica não é apenas uma mudança teórica — é uma mudança prática que pode transformar como tratamos e prevenimos doenças mentais.`,
  },
  {
    id: "rise-metabolic-psychiatry-game-changer",
    title: "The Rise of Metabolic Psychiatry: A Game Changer in Mental Health?",
    author: "Greenland",
    source: "LinkedIn — Greenland",
    excerpt: "Uma análise sobre como a psiquiatria metabólica está transformando o campo da saúde mental com abordagens baseadas em metabolismo.",
    externalUrl: "https://www.linkedin.com/pulse/rise-metabolic-psychiatry-game-changer-mental-health-greenland-u33le",
    fullText: `## Uma Revolução Silenciosa

Enquanto a inteligência artificial e a neuroimagem dominam as manchetes da medicina, uma revolução mais silenciosa está ocorrendo na psiquiatria. Pesquisadores estão redescobrindo que o cérebro, antes de ser um órgão de "pensamento", é fundamentalmente um órgão metabólico.

## Os Números Que Não Mentem

- O cérebro representa apenas 2% do peso corporal, mas consome 20% de toda a energia do organismo
- Pacientes psiquiátricos têm taxas significativamente mais altas de diabetes, obesidade e síndrome metabólica
- A expectativa de vida de pessoas com doenças mentais graves é 15-20 anos menor, principalmente por comorbidades metabólicas

Esses dados não são coincidência. Eles sugerem uma conexão bidirecional profunda entre metabolismo e saúde mental.

## Os Pioneiros

### Dr. Christopher Palmer (Harvard)
Autor de "Brain Energy", Palmer propõe que os transtornos mentais são fundamentalmente distúrbios do metabolismo cerebral. Sua teoria unificadora da saúde mental coloca a mitocôndria no centro da patologia psiquiátrica.

### Dra. Shebani Sethi (Stanford)
Fundadora do primeiro programa acadêmico de Psiquiatria Metabólica, Sethi conduziu estudos piloto demonstrando que intervenções dietéticas podem produzir remissão em pacientes considerados refratários.

### Dra. Georgia Ede (Harvard)
Psiquiatra nutricional que pesquisa como dietas específicas afetam a química cerebral e o risco de transtornos mentais.

## O Caminho Adiante

A psiquiatria metabólica ainda enfrenta desafios — incluindo a necessidade de ensaios clínicos randomizados de grande escala e a resistência de parte da comunidade psiquiátrica tradicional. Mas os resultados preliminares são suficientemente impressionantes para justificar atenção e investimento sério.

## Conclusão

Estamos possivelmente diante da maior mudança de paradigma na psiquiatria desde a introdução dos psicofármacos nos anos 1950. A psiquiatria metabólica oferece não apenas novos tratamentos, mas uma nova forma de entender por que adoecemos mentalmente.`,
  },
  {
    id: "defining-priorities-emerging-field",
    title: "Metabolic Psychiatry: Defining Priorities for an Emerging Field",
    author: "SciEnMag",
    source: "SciEnMag",
    excerpt: "Pesquisadores definem as prioridades para o campo emergente da psiquiatria metabólica, incluindo ensaios clínicos e biomarcadores.",
    externalUrl: "https://scienmag.com/metabolic-psychiatry-defining-priorities-for-emerging-field/",
    fullText: `## Definindo o Campo

À medida que a psiquiatria metabólica ganha momentum, líderes do campo se reuniram para estabelecer prioridades de pesquisa e prática clínica. Este artigo resume as principais recomendações.

## Prioridades de Pesquisa

### 1. Ensaios Clínicos Randomizados
A necessidade mais urgente é a realização de RCTs bem desenhados que possam estabelecer causalidade entre intervenções metabólicas e melhorias psiquiátricas. Estudos piloto são promissores, mas a medicina baseada em evidências exige padrões mais rigorosos.

### 2. Biomarcadores
Identificar biomarcadores que possam:
- Prever quais pacientes responderão melhor a intervenções metabólicas
- Monitorar a eficácia do tratamento objetivamente
- Personalizar protocolos terapêuticos

### 3. Mecanismos de Ação
Aprofundar o entendimento de como exatamente as intervenções metabólicas afetam a função cerebral:
- Estudos de neuroimagem funcional pré e pós-intervenção
- Análises transcriptômicas e proteômicas
- Modelos animais de disfunção mitocondrial

## Prioridades Clínicas

### Formação Profissional
Desenvolver programas de educação médica continuada que preparem psiquiatras, nutrólogos e outros profissionais para implementar abordagens metabólicas de forma segura.

### Protocolos Padronizados
Criar diretrizes clínicas baseadas em evidências para a implementação de intervenções como a dieta cetogênica terapêutica em contextos psiquiátricos.

### Equipes Multidisciplinares
Estabelecer modelos de cuidado que integrem psiquiatras, nutricionistas, endocrinologistas e psicólogos.

## Desafios

- Financiamento: pesquisas sobre dieta e estilo de vida recebem menos investimento do que pesquisas farmacológicas
- Resistência institucional: mudanças de paradigma são naturalmente lentas
- Complexidade: intervenções metabólicas requerem mais envolvimento do paciente do que tomar uma pílula

## Conclusão

O campo da psiquiatria metabólica está em um momento crítico. Com prioridades bem definidas e colaboração interdisciplinar, tem o potencial de redefinir fundamentalmente como entendemos e tratamos os transtornos mentais.`,
  },
];
