// AI chat assistant using Lovable AI Gateway (no auth required for demo)
const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type",
};

const SYSTEM_PROMPTS: Record<string, string> = {
  cliente: `Você é o assistente do paciente da Clínica Metabolicamente, especializada em psiquiatria metabólica.
Seja acolhedor, claro e baseado em evidências. Ajude o paciente a entender:
- como sua alimentação afeta humor, energia e sono;
- a importância dos exames metabólicos (glicemia, HbA1c, vitamina D, ômega-3, perfil inflamatório);
- estratégias práticas e simples (sem prescrever medicamentos).
Sempre lembre que ajustes clínicos devem ser discutidos com seu médico ou nutricionista. Responda em português, tom humano e curto (até 4 parágrafos).`,
  medico: `Você é assistente clínico de um psiquiatra metabólico. Ajude com:
- raciocínio clínico baseado em exames laboratoriais;
- interpretação de marcadores metabólicos e inflamatórios;
- sugestões de protocolos e diferenciais diagnósticos;
- referências da literatura quando relevante.
Use linguagem técnica precisa, em português. Sempre lembre que decisões clínicas são responsabilidade do médico.`,
  nutri: `Você é assistente da nutricionista funcional da Clínica Metabolicamente. Ajude com:
- análise de exames laboratoriais sob ótica nutricional;
- sugestões de cardápio personalizadas (baixo índice glicêmico, anti-inflamatório, ricas em ômega-3);
- estratégias de suplementação baseadas em evidências;
- adaptações culturais brasileiras nas recomendações.
Responda em português, tom profissional e prático. Lembre que prescrições devem ser validadas pela nutricionista responsável.`,
};

Deno.serve(async (req) => {
  if (req.method === "OPTIONS") return new Response(null, { headers: corsHeaders });

  try {
    const { messages, role = "cliente" } = await req.json();
    const LOVABLE_API_KEY = Deno.env.get("LOVABLE_API_KEY");
    if (!LOVABLE_API_KEY) {
      return new Response(JSON.stringify({ error: "LOVABLE_API_KEY not configured" }), {
        status: 500,
        headers: { ...corsHeaders, "Content-Type": "application/json" },
      });
    }

    const systemPrompt = SYSTEM_PROMPTS[role] ?? SYSTEM_PROMPTS.cliente;

    const response = await fetch("https://ai.gateway.lovable.dev/v1/chat/completions", {
      method: "POST",
      headers: {
        Authorization: `Bearer ${LOVABLE_API_KEY}`,
        "Content-Type": "application/json",
      },
      body: JSON.stringify({
        model: "google/gemini-2.5-flash",
        messages: [{ role: "system", content: systemPrompt }, ...messages],
        stream: true,
      }),
    });

    if (response.status === 429) {
      return new Response(JSON.stringify({ error: "rate_limit" }), {
        status: 429,
        headers: { ...corsHeaders, "Content-Type": "application/json" },
      });
    }
    if (response.status === 402) {
      return new Response(JSON.stringify({ error: "credits_exhausted" }), {
        status: 402,
        headers: { ...corsHeaders, "Content-Type": "application/json" },
      });
    }
    if (!response.ok) {
      const err = await response.text();
      return new Response(JSON.stringify({ error: err }), {
        status: response.status,
        headers: { ...corsHeaders, "Content-Type": "application/json" },
      });
    }

    return new Response(response.body, {
      headers: {
        ...corsHeaders,
        "Content-Type": "text/event-stream",
        "Cache-Control": "no-cache",
        Connection: "keep-alive",
      },
    });
  } catch (e) {
    return new Response(JSON.stringify({ error: String(e) }), {
      status: 500,
      headers: { ...corsHeaders, "Content-Type": "application/json" },
    });
  }
});
